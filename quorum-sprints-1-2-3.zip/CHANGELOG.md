# Sprints 1–3 — Changelog

7 files touched (2 new, 5 edited). All UI changes except the theme default
are gated behind `NEXT_PUBLIC_UNIFIED_SESSION_ENABLED` — flag-off behavior
is unchanged by design (verified per-change below, not just asserted).

## Sprint 1 — Default theme → light

- **`app/layout.tsx`** — `data-theme="dark"` → `data-theme="light"` on
  `<html>`. Anti-flash script is untouched: it only overrides the attribute
  when `localStorage.quorum_theme` is set, so this only changes the default
  for new/first-time sessions — anyone who already picked a theme keeps it.
- **`components/ThemeToggle.tsx`** — `getPersistedTheme()`'s innermost
  hardcoded fallback flipped from `'dark'` to `'light'` to match, so the
  default isn't defined in two disagreeing places. Comments updated to
  match.

## Sprint 2 — Progressive per-persona reveal, color classification, glanceable grid

- **`components/LeanBadge.tsx`** (new) — shared small pill component for a
  persona's proceed/wait/mixed classification (color + dot + label).
  `LEAN_LABELS` moved here from `PersonaPanel.tsx` (same wording, just
  relocated — `PersonaPanel.tsx` now imports it instead of defining its own
  copy). `LEAN_COLORS` is new: proceed=green (matches the existing
  `CouncilWeightingStrip.tsx` fallback convention), wait=`var(--gold)`
  (existing token), mixed=`var(--text-4)` (existing token) — no new color
  tokens introduced.
- **`components/CouncilGlanceStrip.tsx`** (new) — the "Tier 0" row of 6
  chips (icon + persona name + lean dot) shown above the card grid once the
  Council is revealed. Deliberately separate from
  `CouncilWeightingStrip.tsx` (that one shows top-weighted advisors by
  synthesis weight, after synthesis; this shows all 6, by lean, before the
  grid — different question, so kept as a different component rather than
  overloading one). Chips are clickable — expands and scrolls to that
  card. Uses a local copy of persona accent colors, matching the existing
  precedent of an independent copy in `CouncilWeightingStrip.tsx` (a known,
  separately-tracked cleanup item — not touched here).
- **`components/PersonaPanel.tsx`**:
  - `mobileCollapsed` now defaults to `isUnifiedSessionEnabled()` instead of
    always `false`. Flag off → unchanged (`false`, same as before).
  - The collapse toggle is no longer gated to `panelState === 'done'` —
    available once streaming starts too, so a card can be peeked at while
    still in progress.
  - The toggle button now shows a visible label ("Read full analysis" /
    "Show less") instead of an icon-only chevron.
  - Added the lean badge to the collapse-surviving summary (uses
    `initialLean`, the same frozen-at-original-response convention already
    used for `positionText`/`realCostText`, so it never disagrees with the
    verdict sentence next to it).
  - Added `onCollapseChange` (fires on every collapse-state change,
    including mount) and `expandRequestToken` (external expand+scroll
    request, consumed via a new `rootRef` + effect) props — both consumed
    by `SessionView.tsx`.
- **`app/globals.css`**:
  - New `[data-unified-session="true"]` rules generalize the existing
    mobile-only (`@media max-width:600px`) collapse mechanism to every
    viewport width. **Additive only** — the existing mobile-only block is
    untouched, so flag-off mobile behavior is byte-for-byte the same as
    before.
  - New `.persona-grid-item.persona-grid-item-expanded` rule (scoped
    `@media max-width:1279px`) makes an expanded card span the full grid
    row instead of being squeezed into a half-width column at the new
    2-column mobile breakpoint. No-op at xl+ (3-column desktop), where a
    single column is already wide enough.
- **`components/SessionView.tsx`**:
  - New `collapsedMap` + `expandRequests` state, `handleCollapseChange` /
    `handleGlanceSelect` handlers — wired to each `PersonaPanel` instance's
    new props.
  - Grid wrapper: `grid-cols-1 md:grid-cols-2 xl:grid-cols-3` →
    conditionally `grid-cols-2` at the base breakpoint **only when the flag
    is on** (`` `grid ${isUnifiedSessionEnabled() ? 'grid-cols-2' : 'grid-cols-1'} md:grid-cols-2 xl:grid-cols-3` ``)
    — flag off keeps today's single-column mobile stack, since those cards
    are never collapsed/short under the old behavior and would be unreadable
    at half-width.
  - Each grid item gets `persona-grid-item` + conditionally
    `persona-grid-item-expanded` (also flag-gated in JS, on top of the
    flag-gated CSS media query, as a second safety net).
  - `CouncilGlanceStrip` inserted above the grid, inside the same
    show/hide wrapper as the disclosure-toggle-gated grid, and only
    rendered at all when the flag is on.

## Sprint 3 — Speed

- **`components/PersonaPanel.tsx`** — the compact real-cost preview
  (`.persona-collapsed-realcost`) no longer requires `panelState === 'done'`
  to render — it shows as soon as `<realcost>` is parsed, same as
  `<position>` (which had no such gate already). Combined with Sprint 2's
  collapse-by-default, the collapsed executive summary (verdict + trade-off)
  now lands within seconds of a persona starting to respond, rather than
  after the full ~200-word response finishes streaming.
- **Opening Ceremony 3s gate** — checked before touching anything:
  `ceremonyDismissed` already initializes to `isUnifiedSessionEnabled()` in
  `SessionView.tsx`, so `ceremonyActive` is already `false` under the flag.
  **This was already shipped — no change made.**

## Deliberately not done in this batch

- **Copy audit** (FAQ, home page, methodology page, onboarding tour steps,
  etc.) — agreed as its own follow-up sprint, run *after* this ships, since
  copy should describe the calibrated, actually-shipped behavior. One
  concrete item already flagged for that pass: the `council-personas` tour
  step copy in `SessionView.tsx` currently says *"the six advisors are
  still doing the work — just collapsed here by default"*, which described
  the old fully-hidden state and will read as inaccurate once cards default
  to a visible colored summary instead of nothing.
- **Persona accent-color consolidation** (`ACCENT_COLORS` duplicated across
  `PersonaPanel.tsx`, `CouncilWeightingStrip.tsx`, and now
  `CouncilGlanceStrip.tsx`) — matched existing precedent rather than
  refactoring working files in this pass; still worth a dedicated cleanup
  sprint.

## How this was verified

No network access in this environment, so `npm install` / `next build` /
`vitest` couldn't run. Verified instead with `tsc --noEmit` against the
real project types (`@/*` paths resolve to the actual local files), with
the expected noise from missing `node_modules` (no `react`, `@types/node`,
etc.) filtered out — that noise appears symmetrically across large amounts
of pre-existing, untouched code in the same files, confirming it's
environmental. Zero syntax errors, zero type errors specific to any new
identifier introduced here (`onCollapseChange`, `expandRequestToken`,
`LeanBadge`, `CouncilGlanceStrip`, `LEAN_COLORS`, etc.). Recommend a normal
`npm run dev` smoke test — particularly the 2-column-mobile / expand-to-
full-width interaction and the glance-strip click-to-scroll — before
merging, since that's the one thing static type-checking can't confirm.
