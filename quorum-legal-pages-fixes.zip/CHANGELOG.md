# Quorum — Privacy, Security & Cookie Policy Review

3 files touched, full read-through of each against the current
codebase (not just a search-and-replace pass). Builds on top of
quorum-copy-fixes.zip and quorum-gap-and-terms-fixes.zip — no overlap
with those files.

## 6a. app/privacy/page.tsx

- **AI processors named specifically.** The generic "AI processing
  service — Hosted in the United States" row was replaced with two
  real rows: OpenAI (fast-role analysis, Free + Elite) and Anthropic
  (Council Synthesis / Mirror / pattern-reading, Elite). Matches the
  specific-naming approach already live in the in-app FAQ. Added a
  line confirming no China-based provider is used on Free/Elite, and
  that Private-tier data never leaves customer-controlled
  infrastructure.
- **Context Ingestion wasn't disclosed anywhere.** This is a real,
  live Elite feature that processes imported files/text (including
  ChatGPT/Claude exports) — arguably one of the more sensitive data
  flows in the app, and it was completely absent from the policy.
  Added a row to "Data we collect" and a matching row to "Data
  retention" describing the review-and-approve flow and that raw
  imports are never stored.
- **Sign-in method.** "Collected when you sign in via magic link" →
  now also mentions Google Sign-In, which is offered as the primary
  option today.
- **Contact section fix.** Removed the claim that the Privacy Center
  is "accessible from Settings in the app footer" — it isn't; the
  public footer links to a different page (`/privacy`), and the
  Privacy Center is reached via the in-app Settings nav instead.
  Simplified to just "in Settings."
- Effective date/version bumped to 14 August 2026 · v1.1.

## 6b. app/security/page.tsx

- **Auth bullet** updated to mention Google Sign-In alongside magic
  links (was magic-link only).
- **AI-related bullets** now name OpenAI and Anthropic specifically
  instead of "an AI service" / "the AI processing service," and note
  Private tier routes through customer-owned infrastructure instead.
- **Hosting bullet** now scoped to "Free and Elite" — Private tier
  customers deploy on infrastructure of their own choosing (AWS/GCP/
  Azure), so the blanket "US-based hosting" claim didn't hold for
  that tier.
- **Real bug found and fixed:** the page contradicted itself. The
  "Vulnerability disclosure programme" bullet correctly says to
  report issues to `security@quorumvault.org` — but the separate
  "Reporting a security concern" section further down sent people to
  the Privacy Center instead (which is a data-rights/cookie panel,
  not a security inbox). Fixed the second section to point to the
  same email + `security.txt`, matching the first.
- Effective date bumped to 14 August 2026.

## 6b (cookies). app/cookies/page.tsx — this was the biggest gap

Checked the registry against every actual `localStorage`/
`sessionStorage` call in the codebase. The page claimed to list
"every key we store" but only documented **6 of 22** keys actually in
use.

- **12 missing localStorage keys added:** onboarding/tour-seen flags,
  Mirror UI state (collapsed panels, hidden descriptions, welcome
  message), tips panel state, profile-overlay-shown, style-calibration
  dismissal, and a resubmit-notice flag. All categorized "Strictly
  Necessary" (UI-state only, no tracking) to match the existing
  pattern used for `quorum_theme`.
- **sessionStorage wasn't disclosed as a category at all** — the page
  only described "local storage." Added a new "Session storage
  registry" section (reused the existing table component) covering
  the pending-decisions banner dismissal, the email-brief prompt
  state, and the internal admin-panel access code (flagged as
  admin-only, not something regular users trigger).
  Updated the intro paragraph to mention both storage types and how
  their lifetimes differ.
- Effective date/version bumped to 14 August 2026 · v1.1.

## One thing flagged, not fixed
Found two separate keys both storing the signed-in email —
`quorum_user_email` (documented, used in most places) and a plain
`user_email` (set once, in `app/page.tsx:386`). This looks like a
leftover duplicate rather than two intentional keys. Didn't touch the
code for it since that's an application-logic decision, not a copy
fix — but worth a quick look, since documenting a probable bug as if
it were an intentional privacy disclosure isn't the right fix either
way.

## Verification
All three files run clean through `tsc --noEmit` in isolation (JSX
preserve, esModuleInterop, skipLibCheck) — no syntax errors. Same
caveat as prior batches: no node_modules here, so this is a
syntax/structure check on the edited files, not a full project
type-check.
