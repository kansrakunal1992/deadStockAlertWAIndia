# Sprint 4 — Copy Audit — Changelog

## What changed

**1 file, 1 string.** `components/SessionView.tsx` — the `council-disclosure-
toggle` onboarding tour step. Was:

> "Want the full breakdown behind the read above? This reveals all six
> advisors individually — hidden by default, never removed."

Now:

> "Want to see where each advisor landed? This reveals all six, at a
> glance — a verdict and a color for each. Tap any one for the full
> reasoning. Hidden by default, never removed."

This was the one place a specific, checkable claim ("the full breakdown")
promised something the tap it's pointing at no longer delivers immediately
— since Sprint 2, that tap now lands on the glanceable summary strip +
collapsed cards, not full text for all six. Full text per advisor is still
there, just a further tap away.

## Correction from the Sprint 1–3 changelog

That changelog flagged the *other* tour step on this same page — the
`council-personas` step's body ("The six advisors are still doing the work
— just collapsed here by default") — as something that would read as
inaccurate post-Sprint-2. Checked it properly this pass: it's actually
still correct. That sentence is about the **outer** disclosure toggle
(nothing shown until you click "See how Quorum got here" at all), which
Sprint 2 never touched — only what you see *after* that click changed. Left
it as-is rather than "fixing" something that wasn't broken. Flagging the
correction here rather than quietly dropping it.

## Checked, found accurate, left unchanged

- `components/FAQSection.tsx` — "Do I still get all six advisors, or just
  Quorum's guess?" answer ("...Want their receipts? 'See how Quorum got
  here' is one tap away, any time.") — "receipts" doesn't specifically
  promise immediate full detail; holds up.
- `app/page.tsx` — the "Challenge the advisors" home-page tip, the hero
  copy, and the "'See how Quorum got here' in any session reveals each
  one's take" line — none make an "immediately full text" claim.
- `app/methodology/page.tsx` — "'See how Quorum got here' in any session
  reveals all six individually" — same reasoning as above; "individually"
  isn't a claim about depth, just that they're not merged into one blob.
  The synthesis-weighting copy ("where the six perspectives agree...") is
  about a different mechanism entirely and was never in question.
- `components/BriefCTA.tsx`, `components/RecordExport.tsx`,
  `components/ReanalyzeDrawer.tsx` — describe the saved record and the
  re-run mechanism, neither of which changed.
- `components/MeetTheCouncil.tsx` — only rendered when
  `!isUnifiedSessionEnabled()` (`app/page.tsx`, gated at the call site) —
  invisible to anyone on the experience Sprints 1–3 touched, so its copy
  (accurate to the flag-off experience, which is unchanged) was correctly
  left alone.
- `components/AppFooter.tsx`, `components/MethodologyExplainerVideo.tsx` —
  no Council-mechanism copy in either file.

## Not done (still open)

Persona accent-color consolidation (`ACCENT_COLORS` duplicated across
`PersonaPanel.tsx` / `CouncilWeightingStrip.tsx` / `CouncilGlanceStrip.tsx`)
— unrelated to copy, flagged in the Sprint 1–3 changelog, still pending its
own pass.
