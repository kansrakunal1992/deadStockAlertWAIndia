# Quorum — Reversal Test + Evidence Strength (Council/Persona Flow)

7 files changed. This is the scoped version we discussed — a new
per-advisor Reversal Test, plus completing the existing Evidence
Strength pattern to all six personas rather than building a second,
parallel mechanism for it. Builds on top of
quorum-install-page-escape-fix.zip.

## What changed, and why it's smaller than it first sounds

Before touching anything, I read through lib/personas.ts properly and
found two things that changed the shape of this:

1. **Evidence Strength already exists as a pattern** — five of the six
   personas (Contrarian, Risk Architect, Pattern Analyst, Stakeholder
   Mirror, Elder) already close with an `<assumption>`-tagged sentence
   naming their weakest assumption, each in their own voice ("hidden
   assumption," "assumption risk," "the discriminating condition,"
   "the alignment test," "the reversibility examination"). Only
   **Competitor** was missing it. So instead of inventing a new tag
   and a new mechanism, I completed the existing one — added "The
   competitive assumption" beat to Competitor
   (lib/personas.ts), reusing the same `<assumption>` tag, matching
   its adversarial voice. Net result: all six advisors now name their
   weakest assumption, using a pattern the product already trusts,
   with zero new tag-wiring needed anywhere (since `<assumption>` was
   already fully wired everywhere it needs to be).

2. **The Reversal Test is genuinely new.** Nothing like "what fact
   would make me reverse my own recommendation" existed anywhere —
   the closest relative is Contrarian's existing "reversal scenario"
   beat, which is a different thing (a retrospective, 3-4 sentence
   regret narrative about the future, not a present-tense, one-sentence,
   fact-specific commitment from all six advisors). This one needed
   real building.

## The new `<reversal>` tag

Added as a mandatory closing tag, instructed once in the shared block
appended to every persona's prompt (`WORD_LIMIT_SUFFIX_CORE` in
lib/personas.ts) — not duplicated six times with persona-specific
wording, since the question itself doesn't change per advisor. Word-
count exempt, same as `<lean>`, so it doesn't compete with the
existing 180-200 word budget every persona is already tightly held
to.

Also mirrored into the older `WORD_LIMIT_SUFFIX` constant. That one's
dead code (not sent to the model — the file's own comment says so),
but it's the copy this codebase's automated guardrail test
(`persona-tag-wiring-guardrail.test.ts`) scans to discover which tags
are "instructed." The file's own existing convention is to keep both
copies in sync for exactly this reason — I followed it rather than
leaving the guardrail blind to a tag that's actually live.

Format instructed to the model:
`<reversal>If [specific fact], [what changes].</reversal>` — one
sentence, own line, after the advisor's final paragraph. If a
position genuinely isn't contingent on any single fact, the advisor
is instructed to say so explicitly rather than force a fake
condition.

## Wiring it through the rest of the app

This codebase has a real test that fails if a new persona-level tag
isn't handled everywhere it needs to be. Found and updated all 5 of
the files it checks:
- `components/PersonaPanel.tsx` — live rendering. Extended the
  existing assumption-highlight function to handle both tags in one
  pass (they can both appear in the same response — assumption
  mid-paragraph, reversal at the end) rather than writing a second,
  separate highlight function.
- `components/RecordExport.tsx`, the observation route, the record
  page (two spots), and the PDF brief route — all strip the tag
  markers and keep the sentence, same content-preserving treatment
  `<assumption>` already gets everywhere.

New CSS: `--reversal-highlight-bg` / `--reversal-highlight-border`,
dark and light theme, in `app/globals.css`. Violet — a genuinely new
color, not reused from assumption (orange), tension (red), or verdict
(gold), since this is a different kind of statement (a conditional
commitment, not a warning or a grade).

## What I deliberately didn't touch

Synthesis's own tags (`<counterfactual>` especially) are untouched.
`<counterfactual>` is already tightly and deliberately scoped to "a
fact the decision-maker already stated" — trying to fold the six new
`<reversal>` tags into it would blur two things this codebase has
gone out of its way to keep separate (a stated-fact sensitivity check
vs. an advisor's own not-yet-known reversal trigger). Synthesis
already receives the full text of all six advisor responses as
context, so the reversal statements are available to it either way —
I just didn't force a new required behavior into an already dense,
separately-guardrailed prompt in the same pass. Worth a follow-up
conversation if you want synthesis to explicitly reference them.

## Verification

Couldn't run vitest in this sandbox (no network, no node_modules), so
I reimplemented the guardrail test's actual logic in plain Node
against the real files and ran it directly — it passes: every
instructed tag is covered in every sink file, and the truncation-guard
consistency check (every tag stripped with a "requires closing tag"
pattern also has a fallback guard for a mid-stream truncated tag) has
no gaps. All 7 files also run clean through `tsc --noEmit` in
isolation.

Worth a real run of the actual test suite once this is deployed
somewhere with node_modules, and a manual smoke test of a live
session — check that all six advisors produce a `<reversal>` line,
that it renders as the new violet highlight, and that Competitor's
new assumption beat reads naturally in its adversarial voice rather
than sounding bolted on.
