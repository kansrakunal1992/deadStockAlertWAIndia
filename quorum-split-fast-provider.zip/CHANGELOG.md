# Split FAST_MODEL_PROVIDER into per-tier vars + add Claude as a fast-role option

## Changed
- `lib/ai-client.ts`

## What changed
1. **Split the env var.** `FAST_MODEL_PROVIDER` is now
   `FAST_MODEL_PROVIDER_FREE` and `FAST_MODEL_PROVIDER_ELITE` — Free
   (end-to-end) and Elite's fast role move independently now instead of
   together. Each falls back to the old `FAST_MODEL_PROVIDER` var if its own
   isn't set (`FAST_MODEL_PROVIDER_LEGACY`), and both ultimately default to
   `mistral` — an existing deployment that only sets the old var keeps
   working unchanged.
2. **`resolveFastCloudTarget()` now takes the tier explicitly**
   (`'free' | 'elite'`) and reads the matching var. Both call sites in
   `resolveTieredTarget` updated accordingly.
3. **Added `anthropic` as a valid value for both vars.** Per your answer,
   it resolves to the exact same `{ kind: 'anthropic-elite' }` target and
   `ELITE_PREMIUM_MODEL` (Sonnet 4.6) that Elite's premium role already
   uses — genuinely identical calls end to end, no new model constant, no
   extended-thinking config (Claude calls in this file never request
   extended thinking regardless of role, so nothing extra was needed for a
   "fast role should be fast" guarantee here).
4. **Production safety warning for the Free variant.** Per your answer,
   `FAST_MODEL_PROVIDER_FREE=anthropic` is supported for internal test
   flexibility only. Added a startup `console.warn` that fires if it's set
   while `NODE_ENV=production`, so it can't silently reach real Free traffic.
5. **`getProviderInfo()`** — renamed `fastModelProvider` to
   `fastModelProviderFree` / `fastModelProviderElite` to match. Grepped the
   rest of the codebase first: nothing else reads that field, so this is a
   clean rename with no other call sites to update.

## Rollout, per your answer
Just the new global `FAST_MODEL_PROVIDER_ELITE` var — set it to `anthropic`
in staging to trial Elite-on-Claude there. Worth remembering for later: the
existing per-user override (`modelRouteFast` → `'anthropic_elite'` via
`/api/admin/grant-mirror-access`) already resolves to this same target today
with zero further code changes, if you ever want to test on a handful of
production beta accounts before a broader `FAST_MODEL_PROVIDER_ELITE` flip.

## Verification
Isolated `tsc --noEmit` — clean aside from expected missing-`node_modules`
noise. Grepped every remaining reference to the old `FAST_MODEL_PROVIDER`
name and `resolveFastCloudTarget()` call site to confirm nothing was missed
(found and fixed one straggler in `getProviderInfo()`). Confirmed
`resolveTieredTarget`'s `'private'` branch never reaches
`resolveFastCloudTarget` (only `'free'`/`'elite'` do), matching its
`'free' | 'elite'` parameter type.
