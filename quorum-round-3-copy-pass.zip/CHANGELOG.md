# Copy Consistency Pass (round 3) — Changelog

14 files (2 new, 12 edited). **Full current state — supersedes
`quorum-round-2.zip` and everything before it.** This picks up from your
question "have we checked all copy against A" — the previous pass only
grepped for the literal phrase "See how Quorum got here"; this one did a
broader sweep (disclosure/toggle/reveal/hidden/collapsed language near any
Council/advisor/persona mention) across every `.tsx`/`.ts` file in the repo,
not just the four already touched.

## Real finding: `app/record/[id]/page.tsx`

This is the one that mattered. The record page had its own CSS-only
checkbox/label disclosure ("See how Quorum got here — all six advisors"),
and its own comment said explicitly why it existed: *"hidden by default,
one click to expand," matching the live session page.* That's a stated
intent to mirror the exact mechanism A removed — so this wasn't a copy nit,
it was the one place still doing the old behavior on purpose. Removed the
whole block (the `<style>` rule, the checkbox, the label); the six advisor
cards on the record page now render unconditionally, same as the session
page post-A. Also updated the comment above the card-rendering loop that
described the now-gone mechanism.

## Three stale dev comments fixed

Not user-facing, but worth fixing while in there — each referenced "the
disclosure toggle" or "Council is collapsed" as still existing, written
before A removed it:

- `components/SessionView.tsx` — the `make-your-decision` section comment
  ("Same synthesisDone gate as the Council disclosure toggle below") and
  the Opening Ceremony comment ("no longer happens by default... (Council
  is collapsed)", now "(each card opens collapsed to a compact summary
  instead)" — precision fix, since it's each card that's collapsed now,
  not the grid itself).
- `components/PersonaPanel.tsx` — the `mobileCollapsed` default comment,
  which referenced "the disclosure toggle that already gates the whole
  six-card grid one level up" as a still-existing thing.

## Checked and confirmed unrelated (same words, different feature)

`WhatChangedDrawer.tsx` ("Collapsed pill" — its own drawer styling),
`TensionInterstitial.tsx` ("The Council has finished/largely agrees" —
synthesis-outcome headlines, not a reveal mechanism), `OnboardingTour.tsx`
(generic tour-runner, takes step content as props — confirmed it doesn't
duplicate the tour copy already fixed in `SessionView.tsx`'s
`COUNCIL_STEPS_BASE`), `RecordTour.tsx`, `QuorumReadCard.tsx` (confirmed
still fully gated off under the flag via `quorumReadDismissed` defaulting
to `isUnifiedSessionEnabled()` — never renders, so its "old mental model"
copy is dead code, not a live inconsistency), and the home page's
"Personas — reveal after CTA click" comment (a page CTA-reveal animation,
unrelated to the Council toggle).

## How this was verified

Diffed against a fresh extraction of your original upload to confirm the
authoritative file list (14). `tsc --noEmit` against the real project
types — zero syntax errors, zero hits on the new record-page identifiers
(`rec-council-reveal`, `rec-persona-standard`) in the diagnostics. Same
missing-`node_modules` caveat as every prior round — no full build was run.
