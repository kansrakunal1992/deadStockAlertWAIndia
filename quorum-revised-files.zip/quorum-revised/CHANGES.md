# Quorum — Priority 1 & 2 fixes (this drop)

Drop these files into the existing repo at matching paths — every file here
is either new or a full replacement of the existing file at that path.
`npm install && npm test` should show 79/79 passing (68 pre-existing + 11 new).

## Priority 1 — Trust risk

**1. Pattern Analyst no longer instructed to invent named cases**
`lib/personas.ts` — the CORE MANDATE previously said: *"always attempt to
name a specific documented case or study... if no named case is available,
say so explicitly rather than describing a category."* That's what produced
the fabricated "Consultant X, 2016" style analogue flagged in review.
Rewritten to default to structural analogues (mechanism, not a named
instance) and only name a real entity when it's a well-established,
widely-documented anchor (2008 housing crisis, dot-com bubble, SPIVA/S&P
data) the model can be genuinely confident about — never an invented name,
date, or attribution assembled to sound documented.

**2. Fabrication detector + tests + live eval harness**
- `lib/fabrication-guard.ts` — heuristic detector for the *shape* of an
  invented named analogue (anonymized placeholder + year, or a specific
  proper noun tightly paired with a year, outside an allow-listed set of
  genuine macro anchors). Flags candidates for human review; does not
  confirm or deny factual accuracy — see the file's header comment for the
  scope of what it can and can't do.
- `tests/pattern-analyst-fabrication-guardrail.test.ts` — offline, runs on
  every `npm test`, zero API cost. Verifies the detector against fixtures
  including the exact pattern from the reviewed session, plus a regression
  guard asserting the old fabrication-pressuring instruction is gone from
  `lib/personas.ts`.
- `scripts/eval-pattern-analyst-fabrication.ts` — live red-team eval. Runs
  the actual shipped Pattern Analyst prompt against 6 scenarios chosen to
  invite a named analogue (career pivot, M&A, delegated investing, etc.),
  scans every response with the same detector, exits non-zero if anything
  is flagged. Requires `ANTHROPIC_API_KEY`; **not** run automatically —
  wire it into a pre-deploy gate or run on a schedule:
  `npm run eval:pattern-analyst`
  Not executed in this pass — no API key in the environment this was built
  in. Verified only that it dry-run-fails cleanly without a key and that
  all imports resolve. Run it for real before treating Priority 1 as fully
  closed.

## Priority 2 — Numeric provenance

**3. `<estimate>` tag — new global constraint, all six personas**
`lib/personas.ts` (`WORD_LIMIT_PREFIX`) — any number a persona supplies as
its own suggested benchmark (not a figure the decision-maker stated) must
now be wrapped `<estimate>...</estimate>` inline, content-preserving, same
convention as the existing `<assumption>`/`<reversal>` tags. Explicitly
forbidden from nesting inside `<assumption>`/`<reversal>` to avoid a raw-
markup rendering bug. Pattern Analyst's own numeric-threshold constraint
(#6) points back to this same rule rather than duplicating it.

**4. Rendering + all sinks wired**
- `components/PersonaPanel.tsx` — live highlight rendering; new CSS
  register (rose/pink, distinct from every existing tag color), and unlike
  `<assumption>`/`<reversal>` (single-instance), supports multiple
  `<estimate>` spans per response since a persona can cite several numbers.
- `app/globals.css` — `--estimate-highlight-bg` / `--estimate-highlight-border`,
  dark and light theme.
- `components/RecordExport.tsx`, `app/api/session/[id]/observation/route.ts`,
  `app/record/[id]/page.tsx`, `app/api/record/[id]/brief/route.ts` — content-
  preserving strip so the tag markup never leaks into the PDF export, the
  observation model's input, or the record page.
- `tests/persona-tag-wiring-guardrail.test.ts` — extended sanity check to
  assert `estimate` by name (previously would only have caught a missing
  sink by accident, the same gap the brief route had before this fix).

**Scope note:** this pass wires `<estimate>` at the persona level, where
the reviewed session's flagged numbers actually came from. Synthesis-level
tagging (`<conditions>`/`<counterfactual>` also carry numeric thresholds)
is a natural next increment using the same scaffolding, not included here
to keep this diff fully verifiable in one pass.

## What was NOT touched
No persona was added, removed, or reconceptualized. No synthesis structure
change. No provider/routing change. Scope held deliberately narrow to the
two sign-off items — see the sign-off doc for what's intentionally deferred.

## Verification performed
- `npm test` — 79/79 passing
- `npx tsc --noEmit` — zero new type errors (project already carries ~28
  pre-existing `TS2802` warnings from a codebase-wide tsconfig target
  setting, unrelated to this change; confirmed line-by-line none are new)
- Regex logic for multi-instance `<estimate>` matching sanity-checked in
  isolation against sample text
- Eval script confirmed to typecheck and dry-run-fail cleanly without an
  API key (real run against a live model not performed — see above)
