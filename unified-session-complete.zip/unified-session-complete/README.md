# Unified session — complete delivery

This supersedes `unified-session-full` and `unified-session-round3` combined —
24 files total (12 modified, 12 new), everything gated behind
`NEXT_PUBLIC_UNIFIED_SESSION_ENABLED` as before. One file from round3,
`components/QuorumLearnedSomething.tsx`, has been deleted — its job was
folded into `CalibrationRevealCard.tsx` two rounds ago and it was left as
dead code by mistake; delete it from your repo too if you applied round3.

**Run `supabase/sprint_prediction_layer.sql` before enabling the flag if you
haven't already** — everything here depends on it.

## What's new this round, mapped to what we agreed

**1. Instinct capture — untouched**, confirmed correct as originally built. No file changes for this item.

**2. Mode selector** — hidden for a first-time user's first session (`app/page.tsx`), resurfaces automatically from session 2 onward as the same optional control, unchanged otherwise.

**3. Reflection line** (the natural-language front-door question, resolved) — new isolated `generateReflectionLine()` in `lib/prediction-engine.ts`, a new tiny route `app/api/persona/reflect/route.ts`, and a new self-contained `components/ExaminerReflectionLine.tsx` mounted at the top of `ExaminerPanel.tsx`. One line, paraphrased from the decision text, shown once above Examiner's first question. Degrades silently (renders nothing) if the call fails — never blocks Examiner.

**4. Profile ("before you begin") overlay** — deferred past a user's first session in `app/page.tsx`, same reasoning as the other deferred-education items.

**5. Onboarding tour** — checked in detail, and it doesn't need the rewrite I originally assumed. Its 4 steps (textarea, voice, context, submit) teach interaction mechanics, not Council/Mirror/mode concepts — none of it references six advisors or anything now hidden. Left as-is; flagging this so it's a documented decision, not an oversight.

**FAQ + homepage copy** — finished and rewritten to sell curiosity per your last note, not explain mechanism (`components/FAQSection.tsx`, `app/page.tsx`'s methodology block). The six-advisor reference section (`MeetTheCouncil`) is now skipped on the home page under the flag.

**Decision starters** — new `components/DecisionStarters.tsx`, six categories from the brief, shown only while the decision box is empty so it never competes with actual typing.

**Record page + PDF brief** — from last round, now included in this complete package: six persona sections hidden on the record page with a new "How this decision moved" summary in their place, and a new dedicated PDF page carrying the same arc (initial lean → Quorum's hypothesis → final decision → match/surprise).

**`CalibrationRevealCard` / `QuorumLearnedSomething` overlap** — resolved (from two rounds ago, included for completeness): the richer existing card now also unlocks under the flag for free tier; the thinner duplicate is deleted.

**Mobile** — not a full audit (that's still open, see below), but every text input and textarea touched across this work is now explicitly 16px, which is the actual fix for a real, specific bug: iOS Safari auto-zooms the whole page on focus for any input under 16px. `PredictionReveal`'s textarea and date field and `SynthesisChallenge`'s textarea were all below that threshold; fixed. Also constrained `DecisionStarters`' dropdown width so it can't overflow off-screen on a narrow phone.

## Still open

- **Full mobile audit** — layout, keyboard behavior, thumb reach, bottom sheets, scrolling across the whole funnel. What's here is a real but narrow fix (input zoom, one overflow risk), not the audit itself.
- **`/methodology` page** (the dedicated "how Quorum works" page, separate from the home page block) — not checked this round.
- Reflection-line quality will need real usage to tune — it's a single small model call with no eval loop yet, same caveat as the prediction engine itself.

## Before merging

Same as every round: sanity-checked for bracket balance and diffed against the true original to confirm no drift beyond intended changes, but not run through your actual build/typecheck/test suite. Run that before deploying.
