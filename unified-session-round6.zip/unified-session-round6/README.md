# Round 6 — points 1, 2, 7 properly resolved

3 files changed. Patches are against round5 for `app/page.tsx` and the
record page, and against `unified-session-complete` for `FAQSection.tsx`
(last file it actually changed in).

**7 — found it, from your screenshot.** It's `ValidationCard.tsx`, and you
were right that it's the record-page counterpart of the one already hidden
on the session page — I'd only gated the `SessionView.tsx` instance two
rounds ago and missed that it's also rendered separately in
`app/record/[id]/page.tsx`, specifically for the case you described: a
returning user (e.g. from a validation-nudge email) who never confirmed it
during the live session. Now skipped under the flag there too. Its job —
Quorum's read plus a cross-session bias callout — is covered by the
prediction-arc summary already on that page. One explicit tradeoff, not
hidden: if someone clicks a validation-nudge email for a still-pending
validation under the flag, there's no longer a card on the record page to
answer it. Worth knowing before this ships.

**1 — FAQ reordering.** The prediction/six-advisors entries moved from
mid-list to position 2, right after "Is Quorum just a chatbot?" — the
highest-visibility slot besides the very first question.

**2 — home page prediction section.** Was a quiet left-border indent
sharing the same visual weight as a supporting example; now a full bordered
card under the flag — its own background, a labeled "Quorum's hypothesis"
line at 16px instead of folded into a paragraph, more breathing room. Flag
off keeps the original quiet treatment unchanged.

**Also checked:** swept `SessionView.tsx` and the record page for any
remaining literal persona names (Contrarian, Risk Architect, etc.) in
user-facing copy outside what's already gated — clean, only code comments
reference them.

## Next: onboarding-tour-style copy pass, then mobile audit

Doing the copy pass next — checking SessionView, record page, and anywhere
else for language that still assumes the old model, the same way this round
found the two home-page instances and the ValidationCard one. Mobile audit
after that, as agreed. Will check in with what's found before making
changes, given how much this round turned up that wasn't visible from code
search alone.
