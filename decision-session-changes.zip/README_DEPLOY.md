# Decision Session (₹299) — Deploy Package

## Files in this zip

**quorum-app/** — drop into the app repo at the matching paths, on top of the existing files (nothing here is a full replacement of an unrelated file except the two noted EDIT files below):
- `app/api/decision-session/create-order/route.ts` — NEW
- `app/api/decision-session/verify-order/route.ts` — NEW
- `lib/decision-session-cors.ts` — NEW
- `supabase/add_decision_session_payments.sql` — NEW (run once in Supabase SQL Editor)
- `app/api/payment/webhook/route.ts` — EDIT (adds a fallback branch for one-time order payments; existing subscription handling untouched)
- `env.example` — EDIT (documentation only, adds two optional new vars — see below)

**website/** — drop into the website repo root, on top of the existing files:
- `card-kunal.html` — EDIT (new CTA, payment + booking popup JS)
- `server.js` — EDIT (injects APP_URL into the page so the JS knows which origin to call)
- `env.example` — EDIT (documentation only, no new var — just a note)

## Before deploying

1. **Run the SQL migration** (`quorum-app/supabase/add_decision_session_payments.sql`) against your Supabase database via the SQL Editor.
2. **No new Razorpay credentials needed** — reuses `NEXT_PUBLIC_RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` / `RAZORPAY_WEBHOOK_SECRET`, already set on the app project.
3. **Optional env vars** (both have working defaults — only set if you want something different):
   - App project: `WEBSITE_ORIGIN` (default `https://quorumvault.org,https://www.quorumvault.org`) and `DECISION_SESSION_AMOUNT_INR` (default `299`).
4. **Razorpay Dashboard**: confirm the webhook already configured for the app has `payment.captured` enabled (it likely already is). No new webhook, no new Plan needed (one-time orders don't use Plans).
5. Deploy the app project first, then the website project (the website calls the app's new endpoints).

## QA already done here
- Full project `tsc --noEmit`: zero new type errors (only the pre-existing, unrelated 27 `downlevelIteration` warnings).
- Full existing test suite: 58/58 passing.
- New JS in card-kunal.html: syntax-checked.
- Manually traced: unpaid visitor cannot reach the booking modal (no token → click always re-triggers checkout, not booking).
