# Quorum — Install Page Escape-Sequence Fix

1 file changed. Builds on top of
quorum-context-upload-and-footer-fixes.zip — just this one file, no
other changes.

## Bug
The install page was showing literal `\u2019` / `\u2014` text instead
of apostrophes and em-dashes.

## Root cause
`\uXXXX` escapes only get interpreted inside a real JS string literal.
Everywhere else in the codebase, copy lives inside data
arrays/objects (`label: '...'`, `a: '...'`, etc.) which are proper JS
string literals, so the same escape style works fine there. The
install page was the one place I wrote prose directly as page
content — plain JSX text between tags, and a couple of bare
`note="..."` attribute strings — and neither of those is a JS string
literal, so the escapes were never interpreted; they just printed as
literal backslash-u-sequences.

Checked every other file touched across this whole thread for the
same pattern — this was the only place it happened.

## Fix
Replaced the five broken instances with the actual characters (’ and
—) directly in the source, instead of escape sequences, since those
spots aren't JS string-literal contexts. Left the one `\u201c`/`\u201d`
pair inside the `steps={[...]}` array untouched — that's a real
array-of-strings prop, so it was already rendering correctly (you can
see it did in your screenshot — "Confirm the name ("Quorum")..." came
through fine).

## Verification
Runs clean through `tsc --noEmit` in isolation. Also re-scanned every
file changed earlier in this thread for the same class of bug —
none found; the rest of the copy already lived inside real JS string
literals (data arrays), which is why nothing else was affected.
