# Round 5 — 7 observations from your screenshots

4 files changed since `unified-session-complete`, diffed against it in `patches/`.

**1. FAQ prominence** — not touched this round. The "Do I still get all six
advisors" answer already states they review in the backend and that "See how
Quorum got here" reveals it; what's still open is reordering the FAQ list
itself so the prediction entry appears earlier for visibility, not just
better content. Flagging as not done rather than silently skipping it.

**2. Home page undersells prediction** — not touched this round beyond what
was already in place (the EXAMPLE box). Making it visually more prominent
(size, position, a dedicated section rather than sharing space with the
six-advisor copy) is still open.

**3. Home page "six advisors" language** — fixed in the specific spot your
screenshot showed AND in a second spot I found while looking (`app/page.tsx`):
the persona-pill row that reveals after the CTA click now says, under the
flag, that the six advisors run in the background and that "See how Quorum
got here" in any session reveals each one's take — instead of just naming
them with no context.

**4. Literal `\u2014`** — found and fixed the exact one your screenshot
showed (`app/page.tsx`, the Quorum's hypothesis example line — it was raw
JSX text again, same bug class as before, I'd missed this one instance).
Then did an exhaustive grep across the *entire* codebase for every `\u`
escape sequence, not just a guess-based check this time, and read the
context of every single result. Everything else is correctly inside real
string or regex literals — that was the only broken instance anywhere.

**5. Record page six personas — expandable, not removed.** Reworked: they're
no longer hidden outright. Added a single CSS-only checkbox/label toggle
("See how Quorum got here — all six advisors") right before the six cards —
pure HTML/CSS sibling-selector trick, deliberately no JavaScript, since this
page is a server component and converting it just for one toggle wasn't
worth the risk. Synthesis and the Decision Brief are unaffected either way.

**6. Decision + review date as precondition to Save Record AND Generate
Decision Brief PDF** — both gated now. "Save to Record" on the session page
disables with an explanatory tooltip until the decision is locked. The
"Generate Decision Brief" button — which actually lives in
`SynthesisCard.tsx`, not directly in `SessionView.tsx` — got the same
treatment via a new prop passed down from `SessionView`.

**7. "Quorum's read card" on the Record Page** — I could not find a
component or heading literally called this anywhere on the record page
after several targeted searches. What exists there today: the Synthesis
section itself (which functions as "the read"), and the "How this decision
moved" prediction-arc summary I already added two rounds ago (initial lean →
Quorum's hypothesis with reasoning → final decision → match/surprise) —
which already renders *before* Synthesis in the page order. If you mean the
Synthesis section itself should be replaced or reordered further, or if
there's a specific card I'm missing, point me to it directly rather than me
guessing again.

## Still open, explicitly

- FAQ reordering for prominence
- Home page prediction section made visually bigger/more central
- The "Quorum's read card" question above
- Full mobile audit (unstarted)
- `/methodology` page (separate from the home page block, not checked)

## Before merging

Same caveat as every round — sanity-checked for bracket balance against the
prior delivery, not run through your build/typecheck/test suite.
