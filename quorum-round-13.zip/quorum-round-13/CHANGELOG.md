# Round 13 — highlight fix + action plan always visible

Builds on round 12 (assumed deployed). Only the 4 files that changed since v12.
SessionView.tsx and CouncilGlanceStrip.tsx are unchanged from the v12 zip.

## 1. Highlight rendering (screenshot feedback)
Cause: the marker was a gradient over only the lower ~40% of the line, which
read as a coloured spell-check underline (red on the Contrarian) and, on
wrapped lines, as a smudge. Separately, emphasis phrases were allowed to run
up to 14 words, so Risk Architect highlighted a two-line clause, and Pattern
Analyst (comma+because lead of 16 words) got no emphasis at all.
- app/globals.css: .persona-mark is now a full-height, rounded highlighter fill
  (15% accent light / 38% dark) instead of a bottom band.
- lib/persona-highlight.ts: emphasis capped at 8 words (contrast punchline: 10);
  new conditional breaks — "only if / only when / only after / unless / until /
  but" — so "Take the job | only if …" emphasises "Take the job".
  Checked against the three sentences in the screenshot: Contrarian ->
  "Don't take the job yet"; Risk Architect and Pattern Analyst -> "Take the job".
- components/PersonaPanel.tsx: the non-emphasised rest of the line is back to
  full text colour (weight 500) instead of a dimmer tone.

## 2. What to do next — always visible
- components/SynthesisCard.tsx: the action plan (with nested "Before you act")
  is back outside any toggle, directly under the prose.
- The toggle now only holds Conditional on + If different, relabelled
  "Show what this depends on" (sub-line: "conditions, what would change this").
  Hidden entirely when neither exists.
- Order: verdict -> trade-offs paragraph -> What to do next -> toggle ->
  "Disagree…" line -> challenge box.

## Verification
- tsc --noEmit (stubbed React types): zero new errors vs. original upload.
- Chromium render, light + dark, of the REAL SynthesisCard (collapsed, from
  tagged initialContent: action plan visible, toggle present) and the real
  card summary markup with the sentences from your screenshot.
- Not rendered: the toggle's expanded state (unchanged JSX from v12, typechecks).
- Fonts were fallback in the render environment; check weight in Cormorant.

## Found, NOT changed (your call)
SynthesisCard.renderProse does `.trimStart()` on the text after </tension>,
which drops the space (or paragraph break) right after the highlighted tension
sentence — in a test it rendered "…control costswhile the Pattern…". Pre-existing;
only shows if the model doesn't put a newline after the tag. One-line fix:
`.replace(/^[\r\n]+/, '')` instead of `.trimStart()`. Say the word.
