# Round 2 — Changelog

13 files (2 new, 11 edited). **This zip is the full current state of every
file it touches — supersedes `quorum-sprints-1-2-3.zip` and
`quorum-sprint-4-copy-audit.zip` wherever they overlap.** Deploy this one.

## A — Outer Council disclosure toggle removed

- **`components/SessionView.tsx`** — `councilExpanded` state, the "See how
  Quorum got here" button, and its `display:none` gate are gone. The glance
  strip + card grid now render automatically the moment
  `synthesisDone && predictionAcknowledged` — the exact condition the old
  button itself waited on before it would even appear, just without the
  extra click. Flag off: unchanged, always visible, as before.

## B — Copy updated to match (no more "tap to reveal")

- **`components/SessionView.tsx`** — `council-personas` tour step body
  rewritten: was "...just collapsed here by default" (implying nothing
  visible), now describes the summary as visible immediately, full
  reasoning a tap away. The separate `council-disclosure-toggle` tour step
  is deleted outright — its target no longer exists.
- **`components/FAQSection.tsx`**, **`app/page.tsx`**,
  **`app/methodology/page.tsx`** — all three "See how Quorum got here ..."
  lines rewritten to describe automatic visibility instead of a tap-to-reveal
  action.
- **Found, deliberately not touched:** `app/record/[id]/page.tsx` has its
  own, separate "See how Quorum got here — all six advisors" checkbox
  toggle — different page, different mechanism (pure CSS, unrelated to
  `councilExpanded`), out of scope unless you want that one changed too.

## C — Persona accent colors consolidated

- **`lib/types.ts`** — added `accentColor?: string` to `PersonaMeta`.
- **`lib/personas.ts`** — the six values added to each advisor's `PERSONAS`
  entry (values unchanged from all three prior copies — pure move, not a
  decision).
- **`components/PersonaPanel.tsx`**, **`components/CouncilWeightingStrip.tsx`**,
  **`components/CouncilGlanceStrip.tsx`** — each of the three local
  `ACCENT_COLORS`/`ACCENTS`/`personaAccent` maps deleted; all three now read
  `persona.accentColor` (or `PERSONAS[key]?.accentColor`). Visually a no-op
  — same six hex values, one home instead of three.
- **Not touched:** `LABELS` in `CouncilWeightingStrip.tsx` is a separate,
  pre-existing duplicate of `PERSONAS[key].label` — out of scope, colors
  only this pass.

## D1 — 2-column mobile header overflow (from your screenshot)

- **`components/PersonaPanel.tsx`** — root cause wasn't really font size:
  the toggle button ("Read full analysis") was sharing a flex row with the
  icon, persona name, and status checkmark, which only had enough width at
  3-column desktop. At half a phone screen, longer names ("The Stakeholder
  Mirror") left the toggle nowhere to go but overflow past the card edge —
  what you saw in the screenshot. Fix: shrunk the header icon/text sizes a
  notch (28→24px icon, 12.5→11.5px name, 11→10.5px lens caption), **and**
  moved the toggle to its own full-width row below the header, so it never
  competes for horizontal space regardless of persona name length. Also a
  bigger, easier tap target on mobile as a side effect.

## D2 — Save Record buttons now redirect to the lock section instead of just being disabled

- **`components/SessionView.tsx`**:
  - Both Save Record buttons (navbar + footer tray) had
    `disabled={... && synthesisDone && !decisionLocked}` — correct in
    principle, but a disabled button gives zero feedback on tap, and
    doesn't fire `onClick` at all, so there was no way to *act* on the
    tooltip explaining why. Removed that clause from both `disabled` props
    — they're now only disabled while actually saving or while the Council
    is still settling.
  - `handleSaveRecord` now checks the same condition itself: if not locked
    yet, it scrolls to `[data-tour-id="council-make-decision"]` (the
    existing wrapper around `PredictionReveal`, the lock-decision
    component) and returns — no save attempt. If already locked (or flag
    off), it proceeds exactly as before.
  - Added a brief highlight (`lockSectionPulse` state, a 1.6s gold ring)
    on that section when redirected there, since a scroll alone can be easy
    to miss if the section was already partly in view.
  - **No separate "Generate Decision Brief PDF" button exists on this
    page** — checked. The PDF download (`BriefCTA.tsx`, "Download PDF →")
    lives on the *record* page, reached only via Save Record. For
    flag-on users, that route was already gated by `decisionLocked`
    transitively (you can't save without locking, so you can't reach the
    PDF button without locking either) — so no separate change was needed
    there. Flag off has no lock requirement to begin with, same as before.
  - **Known minor edge case, not fixed:** if `synthesisDone` is true but
    `predictionAcknowledged` is still false, the lock section
    (`PredictionReveal`) isn't rendered yet, so the scroll target won't
    exist and the click will silently no-op — same (lack of) feedback as
    the old disabled state gave in that situation, not a regression, just
    not fully solved either.

## How this was verified

Same approach as prior rounds: no network access, so verified with
`tsc --noEmit` against the real project types rather than a full build.
Diffed the full working tree against a fresh extraction of your original
upload to get an authoritative list of every touched file (13 — matched
expectations exactly). Zero syntax errors; specifically checked for type
errors on every new identifier from this round (`lockSectionPulse`,
`handleSaveRecord`'s new branch, `accentColor`, the `council-make-decision`
selector, `onCollapseChange`, `expandRequestToken`) — none found. The
remaining diagnostics are the same missing-`node_modules` noise as prior
rounds (confirmed by symmetry with large amounts of untouched code showing
identical errors). Recommend a real `npm run dev` smoke test before
merging — particularly D1 (2-column card at real phone width) and D2 (tap
Save before locking, confirm it scrolls and highlights, then lock and
confirm it saves normally).
