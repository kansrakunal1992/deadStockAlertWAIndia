'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import { isUnifiedSessionEnabled } from '@/lib/feature-flags'
import RateLimitBanner, { parseRateLimit, type RateLimitInfo } from '@/components/RateLimitBanner'
import { useTTSContext } from '@/context/TTSContext'
import type { PersonaMeta, Message } from '@/lib/types'
import type { Lean } from './TensionInterstitial'
import { PERSONAS_WITH_STRUCTURAL_CONTEXT } from '@/lib/structural-dims'
import LeanBadge, { LEAN_LABELS } from './LeanBadge'

// LEAN_LABELS above now lives in LeanBadge.tsx (Council redesign, Sprint 2)
// — same wording as before ("Shifted after pushback → now leaning
// {LEAN_LABELS[currentLean]}" below), and also as WhatChangedDrawer's own
// copy, so a lean shift reads the same way wherever it's shown.

// Unified session, Tier 3 — "Challenge Quorum" structured reasons. Purely a
// prefill helper for the free-form pushback textarea below (see product doc
// item 7: "provide structured disagreement... then allow free-form
// explanation"). Never sent as-is without the user reviewing/editing the
// textarea, so this needs no backend changes — handlePushback's submission
// path is untouched.
const CHALLENGE_REASONS: { value: string; label: string; prefill: string }[] = [
  { value: 'priorities', label: 'Misread my priorities',      prefill: 'You misunderstood what actually matters to me here: ' },
  { value: 'risk',       label: 'Missed a risk',              prefill: 'You missed a risk that matters: ' },
  { value: 'situation',  label: 'Misread the situation',      prefill: 'You misunderstood the actual situation: ' },
  { value: 'disagree',   label: 'I disagree with the take',   prefill: 'I disagree with this because: ' },
  { value: 'missing',    label: 'You\u2019re missing information', prefill: 'There\u2019s information you don\u2019t have: ' },
]

const ICONS: Record<string, React.ReactNode> = {
  contrarian: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>
    </svg>
  ),
  risk_architect: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    </svg>
  ),
  pattern_analyst: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
    </svg>
  ),
  stakeholder_mirror: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  elder: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 22h14M5 2h14M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>
    </svg>
  ),
  competitor: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/>
      <line x1="13" y1="19" x2="19" y2="13"/>
      <line x1="16" y1="16" x2="20" y2="20"/>
      <line x1="19" y1="21" x2="21" y2="19"/>
    </svg>
  ),
}

// ACCENT_COLORS consolidated into PersonaMeta.accentColor (lib/types.ts /
// lib/personas.ts) — was one of three independent copies of the same six
// values; see accentColor's doc comment for the other two.

interface Props {
  persona: PersonaMeta
  sessionId: string
  decisionText: string
  contextText?: string
  registerMode?: 'analytical' | 'clarification'
  /** Bug fix (Aug 2026): every /api/persona fetch below was missing this
   *  entirely, so middleware.ts never saw a Bearer token, never set
   *  x-product-tier, and lib/ai-client.ts's resolveProvider() fell back to
   *  FREE_TIER for every persona call regardless of the user's actual tier —
   *  this, not any Supabase/header-forwarding issue, was the real cause of
   *  Elite-tier calls silently landing on Mistral instead of Claude. Passed
   *  down from SessionView's authTokenSV; undefined/null is fine — it just
   *  means an unauthenticated session, same as before, and the fetch omits
   *  the header exactly like today. */
  authToken?: string | null
  onComplete?: (personaKey: string, content: string) => void
  /** When set, triggers a supplemental stream showing updated analysis with examiner answers */
  examinerContext?: string
  /** Sprint 5: structural context from past sessions — injected for Pattern Analyst, Risk Architect, Elder */
  structuralContext?: string
  /** Automatic percolation: fires the moment a challenge is submitted (not
   *  after the reply completes) — fans the raw challenge text out to all
   *  other advisors as new evidence for independent reassessment. */
  onShareContext?: (text: string) => void
  /** Called both when a broadcast-received update finishes AND when this
   *  advisor's own pushback reply finishes (if it's part of an active
   *  broadcast batch) — used to fold everyone's completion into exactly one
   *  downstream synthesis re-run instead of one per advisor. */
  onExaminerUpdateComplete?: (personaKey: string, content: string) => void
  /** Pre-loaded content from DB — skips the AI call entirely (used on Back to Council navigation) */
  initialContent?: string
  /** Gate: personas don't stream until examiner has been submitted or skipped (new flow) */
  canStream?: boolean
  /** C0 + rule answers baked into the initial persona call — set by SessionView after examiner submit */
  initialExaminerContext?: string
  /** S1-02: fires when this persona transitions to 'done' — used by SessionView for sequential streaming */
  onPersonaComplete?: () => void
  /** R6: ISO date string of the best structural match — session-wide, reused across every
      eligible persona. The citation badge itself is gated on this persona's own
      structuralCitationText (parsed from its <structural> tag), not on this flag. */
  structuralMatchDate?: string | null
  /** (d): matched past session's id — lets the echo badge link to that decision's record page */
  structuralMatchSessionId?: string | null
  /** P1 fix: fires when a pushback reply carries a fresh <lean> classification
   *  that differs from the persona's original one — previously this was always
   *  discarded (stripHeaderTags stripped <lean> from every non-initial reply,
   *  by design, so "what did this advisor originally lean" stayed stable). Now
   *  surfaced separately so SessionView can track it as a genuine *change*
   *  (see Gap #3 — advisor position evolution) without touching the original
   *  lens/position/realcost header, which still intentionally stays frozen. */
  onLeanUpdate?: (personaKey: string, lean: 'proceed' | 'wait' | 'mixed') => void
  /** Vet-fix (b): SessionView's live personaLeans[key] for this persona, passed
   *  back down so the card can compare "what it leaned initially" against
   *  "what it leans now" and show a small shift badge — without touching the
   *  frozen lens/position/realcost header above. This is the same value this
   *  card feeds SessionView via onLeanUpdate; it just comes back down once
   *  SessionView has committed it, so the card and the rest of the session
   *  (synthesis weighting, What Changed drawer, Tension interstitial) are
   *  reading the same number instead of the card silently lagging behind. */
  currentLean?: Lean
  /** Challenge-discoverability pass: true once ANY card in this session has had
   *  a completed pushback exchange — drives the ambient "You can challenge this
   *  one too." hint on cards that haven't been challenged yet. */
  anyCardChallenged?: boolean
  /** Fires the first time THIS card's pushback completes — SessionView uses this
   *  to flip anyCardChallenged to true for the rest of the session. */
  onFirstChallengeUsed?: () => void
  /** Council redesign (Sprint 2): fires whenever this card's collapsed state
   *  changes (including once on mount) — SessionView uses this to know
   *  which grid item should span the full row width at the 2-column
   *  breakpoint (see .persona-grid-item-expanded in globals.css) instead of
   *  squeezing a full analysis into a half-width column. */
  onCollapseChange?: (collapsed: boolean) => void
  /** Council redesign (Sprint 2): bumped by CouncilGlanceStrip when this
   *  card's chip is clicked — expands the card (if collapsed) and scrolls
   *  it into view. A counter rather than a boolean so clicking the same
   *  chip twice in a row (e.g. after manually re-collapsing) still fires. */
  expandRequestToken?: number
}

type PanelState = 'idle' | 'streaming' | 'done' | 'error'

export default function PersonaPanel({ persona, sessionId, decisionText, contextText, registerMode, authToken, onComplete, examinerContext, structuralContext, onShareContext, onExaminerUpdateComplete, initialContent, canStream, initialExaminerContext, onPersonaComplete, structuralMatchDate, structuralMatchSessionId, onLeanUpdate, currentLean, anyCardChallenged, onFirstChallengeUsed, onCollapseChange, expandRequestToken }: Props) {
  const [response, setResponse]           = useState(initialContent ?? '')
  const [panelState, setPanelState]       = useState<PanelState>(initialContent ? 'done' : 'idle')
  const [messages, setMessages]           = useState<Message[]>([])
  const [pushback, setPushback]           = useState('')
  const [showPushback, setShowPushback]   = useState(false)
  // Unified session, Tier 3: structured challenge reason. Purely a text-
  // prefill helper — handlePushback still just sends whatever's in
  // `pushback`, so this needs no change to the submission path below.
  const [challengeReason, setChallengeReason] = useState<string | null>(null)
  const [isPushingBack, setIsPushingBack] = useState(false)
  const [exchanges, setExchanges]         = useState<{ user: string; reply: string }[]>([])

  // Header block — parsed from <lens>, <position>, <realcost>, <lean> tags in streamed output
  const [lensText,     setLensText]     = useState('')
  const [positionText, setPositionText] = useState('')
  const [realCostText, setRealCostText] = useState('')
  // S3-01: machine-readable lean classification — never rendered directly (no
  // proceed/wait/mixed pill on the card), used by SessionView to build the
  // pre-synthesis tension interstitial. Surfaced via onComplete's raw content.
  // Vet-fix (b): also captured here, once, from the persona's ORIGINAL
  // response — purely so this card can compare it against `currentLean`
  // (SessionView's live value, which onLeanUpdate keeps current through
  // pushback) and show a small "shifted" badge. Never overwritten after the
  // initial response settles, same convergence behavior as lensText/
  // positionText/realCostText above.
  const [initialLean, setInitialLean] = useState<Lean | ''>('')

  // R6: per-persona structural citation — parsed from <structural> tag. Empty means
  // this specific persona did not find the structural record relevant to its angle;
  // the citation badge only ever renders when this is non-empty.
  const [structuralCitationText, setStructuralCitationText] = useState('')

  // Item #9 (revised), then Council redesign (Sprint 2) — collapse for this
  // persona card. Originally mobile-only (sub-600px), default OPEN,
  // reasoning being that this card's analysis IS the core product value so
  // collapsing by default would hide the thing someone opened the session
  // to read. Under isUnifiedSessionEnabled(), that reasoning flips: the
  // position/realcost header (which survives collapse below, unaffected by
  // this state) now carries the "core value read" job, at every viewport —
  // so the default becomes collapsed there. (The six-card grid one level up
  // used to also be collapsed behind its own disclosure toggle — that's
  // since been removed; the grid is visible automatically now, and this
  // per-card collapse is the only remaining tier.) Flag OFF: unchanged —
  // default open, still only visually enforced under 600px (see the plain
  // .persona-body-mobile rule in globals.css; the new
  // [data-unified-session="true"] rules next to it are what make this class
  // apply at every width, only when the flag is on).
  const [mobileCollapsed, setMobileCollapsed] = useState(isUnifiedSessionEnabled())

  // Item #14 — synthesized one-line rationale, tucked behind a small "why"
  // toggle, hidden by default so it never competes with the analysis itself.
  // Reuses the existing structural-citation text (already computed,
  // already safe to show — no raw scores/rule IDs) rather than a new signal.
  const [showWhy, setShowWhy] = useState(true)

  // Examiner update — supplemental stream, does not overwrite original
  const [examinerUpdate,    setExaminerUpdate]    = useState('')
  const [examinerUpdateState, setExaminerUpdateState] = useState<'idle' | 'streaming' | 'done'>('idle')
  const [rateLimitInfo, setRateLimitInfo] = useState<RateLimitInfo | null>(null)
  // Ref to streamResponse (defined further down), kept current via the
  // useEffect near it — same stale-closure-avoidance pattern already used
  // for onCompleteRef/onLeanUpdateRef/etc. above. Needed here because
  // clearRateLimit is defined before streamResponse exists.
  const streamResponseRef = useRef<((msgs: Message[], isFirst: boolean, examinerCtx?: string) => Promise<void>) | null>(null)
  // Bug fix: this used to only clear the banner when the countdown expired —
  // nothing then re-issued the call, so a rate-limited persona just sat idle
  // forever (invisible once the banner disappeared) until the user manually
  // reloaded. Now it clears the banner AND re-fires the same call that got
  // rate-limited, same recovery path as the manual Retry button.
  const clearRateLimit = useCallback(() => {
    setRateLimitInfo(null)
    const args = lastCallArgsRef.current
    if (args) streamResponseRef.current?.(args.msgs, args.isFirst, args.examinerCtx)
  }, [])

  const responseRef   = useRef(initialContent ?? '')
  // Bug fix: rebuilding `fullContent` for persistence after any pushback or
  // examiner-update previously reused `responseRef.current` — which by that
  // point already holds the STRIPPED prose (see the `isFirst` streaming loop
  // below, which overwrites responseRef.current with tag-stripped text on
  // every chunk, for display purposes). That stripped text is what got saved
  // as the new "original response" segment going forward, permanently
  // erasing <lens>/<position>/<realcost>/<lean> from what's persisted after
  // the FIRST save. On a later reload, extractHeaderTags(initialContent)
  // then found no <lean> tag anywhere in that persona's stored content, so
  // initialLean never got set — which silently breaks the "Shifted after
  // pushback" badge (initialLean && currentLean && currentLean !== initialLean
  // requires initialLean to be truthy) for exactly the personas that had
  // already been challenged before the page was reloaded, and only becomes
  // visible on that reload — matching the "vanishes sometimes, only for some
  // personas" symptom. This ref tracks the RAW (tag-intact) original response
  // separately, so it — not the display-cleaned responseRef — is what gets
  // reused when reconstructing fullContent for every subsequent save.
  const rawInitialRef = useRef(
    initialContent ? initialContent.split(/\n\n\[(?:Pushback|Updated after Examiner)/)[0] : '',
  )
  // Bug fix ("Contrarian missing its lens/position/lean header block, card
  // looks broken, only on some runs, gone on re-run"): lib/personas.ts
  // mandates <lens>/<position>/<realcost>/<lean> as the first thing every
  // persona response emits, but this has been observed to occasionally come
  // back malformed or entirely absent for one persona's initial response —
  // see extractHeaderTags' "Second bug fix" comment below for a previously
  // documented instance of this (the model emitting a bare <wait> instead of
  // <lean>wait</lean>). When that happens, lensText/positionText/realCostText
  // all stay empty, the card silently falls back to the persona's generic
  // static tagline instead of its lens for this decision, and the Position/
  // Trade-off sections don't render at all (they're gated on `{positionText &&
  // ...}` etc.) — which is what "looks very bad" here: a card with none of the
  // structured framing every other persona has. Rather than requiring a full
  // manual Reanalyze (which re-runs all 6 personas + resynthesizes) just to
  // reroll the one persona that had a bad draw, this retries ONLY that
  // persona's initial call, once, silently, if its response comes back
  // without a parseable <lens> tag — self-healing the exact symptom reported
  // whether the cause is a transient stream hiccup (e.g. right after a cold
  // start) or the model occasionally not following the mandatory format.
  const headerRetryRef = useRef(0)
  // Bug fix ("some personas never fired at all"): streamResponse used to go
  // straight to panelState 'error' on the FIRST non-OK response or network
  // exception, with no retry and no way to recover short of a full page
  // reload/Reanalyze. Combined with the old sequential gate (SessionView),
  // one persona hitting a transient provider hiccup silently blocked every
  // persona after it. The gate is now removed (SessionView fires all six in
  // parallel), but a transient failure should still recover on its own
  // rather than dead-ending the card. This tracks bounded auto-retries for
  // non-OK/network failures, separate from headerRetryRef above (which
  // retries a different failure mode — a malformed/missing header block on
  // an otherwise-successful response).
  const transientRetryRef = useRef(0)
  const MAX_TRANSIENT_RETRIES = 2
  const TRANSIENT_RETRY_DELAYS_MS = [1500, 4000]
  // Stored so the manual "Retry" button (shown once auto-retries are
  // exhausted) can re-issue the exact same call the user was waiting on.
  const lastCallArgsRef = useRef<{ msgs: Message[]; isFirst: boolean; examinerCtx?: string } | null>(null)
  const exchangesRef  = useRef(exchanges)
  const onCompleteRef = useRef(onComplete)
  const onLeanUpdateRef = useRef(onLeanUpdate)
  const onPersonaCompleteRef = useRef(onPersonaComplete)
  // QC fix: onExaminerUpdateComplete was previously called directly (not via ref),
  // unlike its sibling onComplete/onPersonaComplete above — same stale-closure risk
  // those refs exist to prevent, just missed on this one. Same pattern applied here.
  const onExaminerUpdateCompleteRef = useRef(onExaminerUpdateComplete)

  useEffect(() => { exchangesRef.current        = exchanges       }, [exchanges])
  useEffect(() => { onCompleteRef.current       = onComplete      }, [onComplete])
  useEffect(() => { onLeanUpdateRef.current     = onLeanUpdate    }, [onLeanUpdate])
  useEffect(() => { onPersonaCompleteRef.current = onPersonaComplete }, [onPersonaComplete])
  useEffect(() => { onExaminerUpdateCompleteRef.current = onExaminerUpdateComplete }, [onExaminerUpdateComplete])

  // Council redesign (Sprint 2): tell SessionView whenever this card's
  // collapsed state changes, including the very first render — that's how
  // it knows which grid item should span the full row at the 2-column
  // breakpoint. Runs on mount too (mount IS a "change" from the parent's
  // point of view, since it starts with no entry for this key at all).
  useEffect(() => {
    onCollapseChange?.(mobileCollapsed)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mobileCollapsed])

  // Council redesign (Sprint 2): a click on this persona's CouncilGlanceStrip
  // chip bumps expandRequestToken — expand (if currently collapsed) and
  // scroll into view. Guarded on the token being truthy so this doesn't fire
  // on mount (token starts undefined/0 for every card).
  const rootRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!expandRequestToken) return
    setMobileCollapsed(false)
    rootRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandRequestToken])

  // S1-02: Sequential streaming — fire when this persona transitions to done
  useEffect(() => {
    if (panelState === 'done') onPersonaCompleteRef.current?.()
  }, [panelState])

  const accentColor = persona.accentColor ?? '#1c2b4a'
  const icon = ICONS[persona.key]

  // ── Header tag extractor ───────────────────────────────────────────────────
  // Strips <lens>, <position>, <realcost>, <lean>, <structural> tags from streamed output and returns clean prose
  const extractHeaderTags = useCallback((raw: string): string => {
    // Bug fix (visible tag leak): <estimate>/<assumption>/<reversal> are
    // legitimate INLINE display tags the model can place anywhere in its
    // prose per the Numeric Provenance / Reversibility Examination rules in
    // lib/personas.ts — including, it turns out, inside the <realcost> or
    // <position> sentence itself (e.g. "...for the next
    // <estimate>12-18 months</estimate>."). The main body paragraph handles
    // these correctly further down (they get parsed into highlighted spans),
    // but these four header fields are rendered as plain text and never went
    // through that pipeline, so a nested tag rendered raw on screen — this is
    // the tag leak reported from the collapsed-card summary. Fix: strip just
    // the tag markers (keep the inner text) from whatever this captures,
    // before it's ever set as state. Covers a stray/unclosed marker too
    // (e.g. model drops the closing tag) since the regex matches the marker
    // itself, not a paired span — nothing here can delete real content, only
    // markup.
    const stripInlineDisplayTags = (s: string) =>
      s
        .replace(/<\/?estimate>/g, '')
        .replace(/<\/?assumption>/g, '')
        .replace(/<\/?reversal>/g, '')
    const get = (tag: string) => {
      const m = raw.match(new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`))
      return m ? stripInlineDisplayTags(m[1].trim()) : ''
    }
    const lens     = get('lens')
    const position = get('position')
    const realcost = get('realcost')
    const lean     = get('lean').toLowerCase()
    const structural = get('structural')
    if (lens)     setLensText(lens)
    if (position) setPositionText(position)
    if (realcost) setRealCostText(realcost)
    if (structural) setStructuralCitationText(structural)
    if (lean === 'proceed' || lean === 'wait' || lean === 'mixed') {
      setInitialLean(prev => prev || lean)
    }
    // Strip all four tag blocks + any leading blank line from prose.
    // <lean> is a machine-readable classification only — never state, never displayed.
    //
    // Bug fix: this runs on every streamed chunk (accumulated so far), not just on
    // the final response. The four regexes below only match a FULLY CLOSED tag —
    // while a chunk boundary lands between an opening tag (e.g. "<lean>") and its
    // closing tag, the dangling open tag + partial content (e.g. "<lean>proc")
    // doesn't match any of them and briefly renders raw on screen. <lean> is the
    // last of the four header tags, so it's the one most exposed to this window.
    // The trailing guard below strips any still-open header tag (and everything
    // after it) the same way the <verdict> "guard: open tag without close" pattern
    // already does elsewhere in the codebase (SynthesisCard, RecordExport, etc).
    //
    // Second bug fix (observed live, July 2026): the model has been seen emitting a
    // bare, malformed tag using the <lean> ENUM VALUE as the tag name itself — e.g.
    // literal "<wait>" sitting in the prose — instead of correctly closing
    // <lean>wait</lean>. This isn't a tag our schema defines, so none of the regexes
    // above (which only know the tag NAMES lens/position/realcost/lean) ever match
    // it, and it leaked straight into the visible card. Since <lean>'s only valid
    // values are proceed/wait/mixed, strip any bare occurrence of those three as a
    // targeted defense — this is not a generic "strip all tags" rule, only the exact
    // vocabulary this one field draws from.
    return raw
      .replace(/<lens>[\s\S]*?<\/lens>/g, '')
      .replace(/<position>[\s\S]*?<\/position>/g, '')
      .replace(/<realcost>[\s\S]*?<\/realcost>/g, '')
      .replace(/<lean>[\s\S]*?<\/lean>/g, '')
      .replace(/<structural>[\s\S]*?<\/structural>/g, '')
      // Bug fix (hydration leak, July 2026): this function rebuilds initialContent
      // on reload by concatenating every raw assistant row for a persona — initial
      // response + every pushback reply. Pushback replies carry <pushback_classification>,
      // which this function never stripped (unlike stripHeaderTags on the live path),
      // so the raw tag rendered on every reload of a session with pushback history.
      // Tolerant close: model sometimes closes with </pushback> instead of the full
      // </pushback_classification> — same drift pattern as <lean>/<structural> above.
      .replace(/<pushback_classification>[\s\S]*?<\/(?:pushback_classification|pushback)>/g, '')
      .replace(/<(?:lens|position|realcost|lean|structural|pushback_classification)>[\s\S]*$/, '') // guard: open tag without close
      .replace(/<\/?(?:proceed|wait|mixed)>\s*/gi, '')          // guard: stray malformed lean-value tag
      // Third bug fix (GPT-5-mini, Aug 2026): unlike Claude/DeepSeek, gpt-5-mini has
      // been observed dropping the <lean> tag markup entirely — two new shapes, neither
      // caught by the guard above (which only matches the value wrapped in ITS OWN
      // brackets, e.g. "<wait>"). Shape 1: the bare enum word with no tag characters at
      // all, glued straight onto the capitalized first word of the actual analysis
      // (e.g. "mixedThis is a concentration..."). Shape 2: a truncated open tag that
      // lost "lean>" after the "<", so only the value + a normal close tag survive
      // (e.g. "<mixed</lean>" instead of "<lean>mixed</lean>"). Since the header block
      // is contractually the first thing emitted, a leaked lean value can only ever be
      // sitting at position 0 once lens/position/realcost are already stripped above —
      // anchoring to the start keeps this from ever matching the word "wait" or "mixed"
      // if a persona's prose genuinely opened with it.
      //
      // Shape 3 (observed in PUSHBACK replies specifically, Aug 2026): the bare value
      // with no leading "<" but WITH the closing tag attached — e.g. "mixed</lean>" —
      // different from shape 2 (which has the leading "<" but not this one). Safe to
      // match case-insensitively like shape 2: the literal "</lean>" fragment can't
      // occur in genuine prose either way.
      .replace(/^(?:proceed|wait|mixed)\s*(?=[A-Z])/, '')
      .replace(/^<(?:proceed|wait|mixed)<\/lean>\s*/i, '')
      .replace(/^(?:proceed|wait|mixed)<\/lean>\s*/i, '')
      .replace(/^\s+/, '')
  }, [])

  // Strips header tags from pushback replies WITHOUT updating header state
  // (we keep the original lens/position/realcost from the first analysis)
  const stripHeaderTags = useCallback((raw: string): string => {
    return raw
      .replace(/<lens>[\s\S]*?<\/lens>/g, '')
      .replace(/<position>[\s\S]*?<\/position>/g, '')
      .replace(/<realcost>[\s\S]*?<\/realcost>/g, '')
      .replace(/<lean>[\s\S]*?<\/lean>/g, '')
      .replace(/<structural>[\s\S]*?<\/structural>/g, '')
      // Same treatment as <lean> — machine-only value, never shown, full removal.
      // Tolerant close: model sometimes closes with </pushback> instead of the
      // full </pushback_classification> (same drift pattern as verdict_lean/
      // </verdict> below) — without this, the tag leaks straight into the UI.
      .replace(/<pushback_classification>[\s\S]*?<\/(?:pushback_classification|pushback)>/g, '')
      .replace(/<(?:lens|position|realcost|lean|structural|pushback_classification)>[\s\S]*$/, '') // guard: open tag without close
      // Sprint 2 follow-on: <assumption> is content-preserving here, unlike the
      // tags above — it wraps substantive prose (the actual "hidden assumption"
      // sentences), not a machine-only value or a citation meant to live
      // elsewhere. Pushback exchanges aren't covered by renderAssumption's
      // highlight (deliberately scoped to the first response only), so this
      // just strips the tag markers and keeps the sentences in place, same as
      // stray-tag guards elsewhere in this file.
      .replace(/<\/?assumption>/g, '')
      // Reversal Test (all six personas' <reversal> closing tag) — same
      // content-preserving treatment as <assumption> just above, and same
      // reasoning: it's instructed as part of the initial-response structure,
      // not the pushback protocol, so it shouldn't appear here in practice —
      // this is a defensive strip in case it does.
      .replace(/<\/?reversal>/g, '')
      // <estimate> (Numeric Provenance, WORD_LIMIT_PREFIX #6) — same
      // content-preserving defensive strip; not part of the pushback
      // protocol's own instructions, but a pushback reply can still restate
      // a numeric threshold, so this guards against the tag leaking raw.
      .replace(/<\/?estimate>/g, '')
      .replace(/<\/?(?:proceed|wait|mixed)>\s*/gi, '')          // guard: stray malformed lean-value tag
      // Third bug fix (GPT-5-mini, Aug 2026) — same leaked-lean shapes as
      // extractHeaderTags above; see that function's comment for the full explanation.
      // Shape 3 is the one specifically seen leaking in pushback replies.
      .replace(/^(?:proceed|wait|mixed)\s*(?=[A-Z])/, '')
      .replace(/^<(?:proceed|wait|mixed)<\/lean>\s*/i, '')
      .replace(/^(?:proceed|wait|mixed)<\/lean>\s*/i, '')
      .replace(/^\s+/, '')
  }, [])

  // Sprint 2 (Feature #2, "Evidence Confidence Weighting" — cheap version).
  // Contrarian and Risk Architect already write a "hidden assumption" /
  // "assumption risk" beat in every response (lib/personas.ts) — this makes
  // it visually distinct from the surrounding prose instead of leaving it
  // unmarked. Deliberately NOT extracted into a separate panel/ledger: the
  // design intent is a subtle highlight inside the text the person is
  // already reading, not a new list to parse. <assumption> is intentionally
  // NOT added to extractHeaderTags/stripHeaderTags above — unlike
  // lens/position/realcost/lean, it isn't a header tag that moves
  // elsewhere; it stays exactly where it falls in the paragraph, so
  // `response` naturally still contains it start to finish.
  //
  // Reversal Test addition: all six personas now also close with a
  // <reversal> tag (lib/personas.ts) — the single fact that would flip
  // that advisor's own recommendation. Same content-preserving, stays-
  // in-place treatment as <assumption>, just a different highlight colour
  // (--reversal-highlight-*, a new violet register — see globals.css) and
  // a different position (end of the response, not mid-paragraph). Both
  // can appear in the same response, so this finds both spans and renders
  // them in one pass rather than composing two separate render calls.
  //
  // Same two-track approach SynthesisCard's renderProse uses for
  // <tension>: while streaming, any highlight markup (including a
  // still-open tag mid-stream) is stripped from what's shown, so raw tag
  // text never flashes on screen; once done, the now-guaranteed-closed
  // tags are used to slice out their exact spans and wrap each in its own
  // highlight.
  const stripHighlightMarkup = (text: string): string => {
    return text
      .replace(/<\/?assumption>/g, '').replace(/<assumption>[\s\S]*$/, '')
      .replace(/<\/?reversal>/g, '').replace(/<reversal>[\s\S]*$/, '')
      // <estimate> (Numeric Provenance constraint, lib/personas.ts
      // WORD_LIMIT_PREFIX #6) — same content-preserving, stays-in-place
      // treatment as <assumption>/<reversal>. Unlike those two, a response
      // can contain several <estimate> spans (one per suggested numeric
      // threshold), so it's handled separately below in renderAssumption
      // rather than as a single indexOf pair — this strip is only the
      // streaming-safe fallback shown before the response is done.
      .replace(/<\/?estimate>/g, '').replace(/<estimate>[\s\S]*$/, '')
  }

  const renderAssumption = (text: string, isDone: boolean): React.ReactNode => {
    if (!isDone) {
      return <>{stripHighlightMarkup(text)}</>
    }
    const assumptionStart = text.indexOf('<assumption>')
    const assumptionEnd   = text.indexOf('</assumption>')
    const hasAssumption   = assumptionStart !== -1 && assumptionEnd !== -1 && assumptionEnd > assumptionStart

    const reversalStart = text.indexOf('<reversal>')
    const reversalEnd   = text.indexOf('</reversal>')
    const hasReversal    = reversalStart !== -1 && reversalEnd !== -1 && reversalEnd > reversalStart

    // <estimate> can appear multiple times per response (one per suggested
    // numeric threshold) — find every closed occurrence, unlike the single
    // indexOf pair used for <assumption>/<reversal> above. isEstimate flags
    // these for the trailing "estimate" marker below — color alone doesn't
    // tell a user what a highlight means, so <estimate> spans get an
    // explicit inline label, unlike the other two tags which read fine
    // from their surrounding sentence.
    const estimateSpans = [...text.matchAll(/<estimate>([\s\S]*?)<\/estimate>/g)].map(m => ({
      start: m.index!,
      end:   m.index! + m[0].length,
      tagLen: '<estimate>'.length,
      closeLen: '</estimate>'.length,
      bgVar: '--estimate-highlight-bg',
      borderVar: '--estimate-highlight-border',
      isEstimate: true,
    }))

    if (!hasAssumption && !hasReversal && estimateSpans.length === 0) {
      // No tag found (a rare miss, or a persona/response with none) —
      // render as-is, still guarding against any stray/unclosed tag.
      return <>{stripHighlightMarkup(text)}</>
    }

    // <assumption> falls mid-paragraph; <reversal> is instructed to close
    // the response, after it — so in practice assumptionStart < reversalStart
    // whenever both are present. Handle both orders anyway rather than
    // assume it, since nothing prevents a model from writing them the other
    // way round. <estimate> spans can fall anywhere relative to both —
    // sorting by start below handles all orderings.
    const spans = [
      hasAssumption && { start: assumptionStart, end: assumptionEnd + '</assumption>'.length, tagLen: '<assumption>'.length, closeLen: '</assumption>'.length, bgVar: '--assumption-highlight-bg', borderVar: '--assumption-highlight-border', isEstimate: false },
      hasReversal    && { start: reversalStart,   end: reversalEnd   + '</reversal>'.length,   tagLen: '<reversal>'.length,   closeLen: '</reversal>'.length,   bgVar: '--reversal-highlight-bg',   borderVar: '--reversal-highlight-border',   isEstimate: false },
      ...estimateSpans,
    ].filter((s): s is { start: number; end: number; tagLen: number; closeLen: number; bgVar: string; borderVar: string; isEstimate: boolean } => !!s)
      .sort((a, b) => a.start - b.start)

    const nodes: React.ReactNode[] = []
    let cursor = 0
    spans.forEach((s, i) => {
      nodes.push(text.slice(cursor, s.start))
      nodes.push(
        <span
          key={i}
          title={s.isEstimate ? 'Council-suggested estimate — not a fact you stated' : undefined}
          style={{
            background:    `var(${s.bgVar})`,
            borderBottom:  `1px solid var(${s.borderVar})`,
            paddingBottom: 1,
            borderRadius:  2,
            cursor:        s.isEstimate ? 'help' : undefined,
          }}
        >{text.slice(s.start + s.tagLen, s.end - s.closeLen)}</span>
      )
      // <estimate> gets an explicit trailing label — the highlight color
      // alone doesn't tell a first-time user what it means, and unlike
      // <assumption>/<reversal>, this needs to work without a hover (most
      // usage here is mobile). "estimate" is spelled out rather than
      // abbreviated for the same reason the color-only approach wasn't
      // enough on its own: don't trade one unexplained signal for another.
      if (s.isEstimate) {
        nodes.push(
          <sup
            key={`${i}-marker`}
            className="estimate-marker"
            title="Council-suggested estimate — not a fact you stated"
          >estimate</sup>
        )
      }
      cursor = s.end
    })
    nodes.push(text.slice(cursor))
    return <>{nodes}</>
  }

  // ── TTS ────────────────────────────────────────────────────────────────────────────────
  const { speak, stop, pause, resume, isSpeaking, isPaused, isLoading, activeSpeakerId, rate, setRate, countdown } = useTTSContext()
  const isThisSpeaking = activeSpeakerId === persona.key

  const streamResponse = useCallback(async (msgs: Message[], isFirst: boolean, examinerCtx?: string) => {
    lastCallArgsRef.current = { msgs, isFirst, examinerCtx }
    setPanelState('streaming')
    if (isFirst) setResponse('')

    // Bounded auto-retry for a non-OK response or a network exception (the
    // rate-limit case is handled separately below and is NOT auto-retried
    // here — it has its own countdown/expiry path). Same call, same args,
    // after a short backoff. Only after MAX_TRANSIENT_RETRIES is exhausted
    // does this fall through to panelState 'error' with a manual Retry button.
    const retryOrFail = (message: string) => {
      if (transientRetryRef.current < MAX_TRANSIENT_RETRIES) {
        const delay = TRANSIENT_RETRY_DELAYS_MS[transientRetryRef.current] ?? 4000
        transientRetryRef.current += 1
        setTimeout(() => streamResponse(msgs, isFirst, examinerCtx), delay)
        return
      }
      setPanelState('error')
      setResponse(message)
    }

    try {
      const res = await fetch('/api/persona', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Bug fix (Aug 2026): this header was missing entirely — see the
          // authToken doc comment on this component's Props for why that
          // silently forced every persona call onto FREE_TIER routing.
          ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
        },
        body: JSON.stringify({ sessionId, personaKey: persona.key, messages: msgs, decisionText, contextText, registerMode: registerMode ?? 'analytical', structuralContext, examinerContext: isFirst ? examinerCtx : undefined }),
      })
      if (!res.ok || !res.body) {
        const rl = await parseRateLimit(res)
        if (rl) { setRateLimitInfo(rl); setPanelState('idle'); return }
        retryOrFail('Failed to load. Check API key.')
        return
      }

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let acc = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        acc += decoder.decode(value, { stream: true })

        if (isFirst) {
          const prose = extractHeaderTags(acc)
          setResponse(prose)
          responseRef.current = prose
        }
      }

      if (isFirst) {
        // See headerRetryRef's definition above. Checking for <lens> alone is
        // sufficient — it's the first of the four mandatory tags, so if it's
        // missing/malformed the rest are either also missing or, having lost
        // their anchor, not worth trusting either. Checked before
        // setPanelState('done') so a silent retry doesn't visibly flash
        // "done" first — the card should just keep looking like it's still
        // thinking.
        const hasLens = /<lens>[\s\S]*?<\/lens>/.test(acc)
        if (!hasLens && headerRetryRef.current < 1) {
          headerRetryRef.current += 1
          streamResponse(msgs, isFirst, examinerCtx)
          return
        }
      }

      setPanelState('done')
      transientRetryRef.current = 0

      if (isFirst) {
        rawInitialRef.current = acc   // preserve tag-intact original response for future saves
        onCompleteRef.current?.(persona.key, acc)
      } else {
        const userText = msgs[msgs.length - 1]?.content ?? ''
        // P1 fix: capture the pushback reply's <lean> BEFORE stripping it —
        // the model re-emits this on every call (it's baked into the base
        // persona prompt), but it was previously discarded unconditionally.
        // Surfaced via a separate callback rather than folded into onComplete
        // so the original lens/position/realcost header — deliberately frozen
        // at the initial response — is untouched by this.
        const leanMatch = acc.match(/<lean>([\s\S]*?)<\/lean>/)
        if (leanMatch) {
          const lean = leanMatch[1].trim().toLowerCase()
          if (lean === 'proceed' || lean === 'wait' || lean === 'mixed') {
            onLeanUpdateRef.current?.(persona.key, lean)
          }
        }
        // Persistence layer for cross-session "what changes your mind" tracking.
        // The model already computes this classification internally every
        // pushback (Step 1, lib/personas.ts) — it was previously discarded the
        // instant this reply finished streaming. Same extract-before-strip
        // pattern as leanMatch above, fire-and-forget POST (non-blocking —
        // a failure here should never affect the pushback reply itself).
        // Tolerant close here too — same drift as the strip regex above. If this
        // stays strict while the strip regex is tolerant, a drifted response
        // would have its tag correctly hidden from the user but silently never
        // recorded for mind-change tracking (data loss with no visible symptom).
        const classificationMatch = acc.match(/<pushback_classification>([\s\S]*?)<\/(?:pushback_classification|pushback)>/)
        if (classificationMatch) {
          const classification = classificationMatch[1].trim().toLowerCase()
          const validClassifications = ['weak', 'partially_valid', 'materially_valid', 'recommendation_changing']
          if (validClassifications.includes(classification) && sessionId) {
            fetch(`/api/session/${sessionId}/pushback-classification`, {
              method:  'POST',
              headers: { 'Content-Type': 'application/json' },
              body:    JSON.stringify({ personaKey: persona.key, classification }),
            }).catch(() => { /* non-blocking, silent */ })
          }
        }
        // Strip lens/position/realcost tags from pushback reply (keep original header state)
        const cleanReply = stripHeaderTags(acc)
        const newExchanges = [...exchangesRef.current, { user: userText, reply: cleanReply }]
        setExchanges(newExchanges)
        setIsPushingBack(false)
        const fullContent = [rawInitialRef.current || responseRef.current, ...newExchanges.map(e => `[Pushback: "${e.user}"]\n${e.reply}`)].join('\n\n')
        onCompleteRef.current?.(persona.key, fullContent)
        // Automatic percolation: this advisor's own completion is now part of
        // the same "whole council reassessing this new information" batch as
        // the other 5 (see handleShareContext / handleExaminerUpdateComplete
        // in SessionView) — notify so the batch can close and fire exactly
        // one synthesis re-run once everyone (including this advisor) has
        // landed, instead of one bump here plus a second one after the other
        // five finish. No-ops harmlessly if this key isn't part of an active
        // batch (e.g. onShareContext wasn't wired for this card).
        onExaminerUpdateCompleteRef.current?.(persona.key, fullContent)
      }
    } catch {
      retryOrFail('Connection error.')
    }
  }, [sessionId, persona.key, decisionText, contextText, registerMode, structuralContext, extractHeaderTags, stripHeaderTags])

  useEffect(() => { streamResponseRef.current = streamResponse }, [streamResponse])

  // Manual retry — shown once auto-retries are exhausted. Resets both retry
  // counters and re-issues the exact call that was in flight when it failed.
  const retryNow = useCallback(() => {
    transientRetryRef.current = 0
    headerRetryRef.current = 0
    const args = lastCallArgsRef.current
    if (args) streamResponse(args.msgs, args.isFirst, args.examinerCtx)
    else streamResponse([], true, initialExaminerContext)
  }, [streamResponse, initialExaminerContext])

  // Parse header tags from initialContent so Lens/Position/Trade-off render on Back to Council
  useEffect(() => {
    if (!initialContent) return
    const prose = extractHeaderTags(initialContent)
    setResponse(prose)
    responseRef.current = prose
    // Keep the raw (tag-intact) original-response segment current too — see
    // rawInitialRef's definition above for why this must stay separate from
    // responseRef.current.
    rawInitialRef.current = initialContent.split(/\n\n\[(?:Pushback|Updated after Examiner)/)[0]
  }, [initialContent, extractHeaderTags])

  useEffect(() => {
    if (initialContent) return   // already hydrated from DB — no re-fetch
    if (canStream === false) return  // wait for examiner to submit/skip
    if (panelState !== 'idle') return // guard: only fire once (canStream or initialExaminerContext re-rendering)
    streamResponse([], true, initialExaminerContext)
  }, [streamResponse, initialContent, canStream, initialExaminerContext]) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Examiner supplemental update ────────────────────────────────────────
  // Fires when examinerContext is set (non-empty) after the initial analysis is done
  const examinerContextRef = useRef<string | undefined>(undefined)
  useEffect(() => {
    if (!examinerContext || examinerContext === examinerContextRef.current) return
    examinerContextRef.current = examinerContext
    // Only fire if we have the original response to build on
    if (!responseRef.current) return

    const runExaminerUpdate = async () => {
      setExaminerUpdateState('streaming')
      setExaminerUpdate('')
      try {
        const examinerMessages = [
          { role: 'assistant' as const, content: responseRef.current },
          { role: 'user' as const, content: examinerContext },
        ]
        const res = await fetch('/api/persona', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
          },
          body: JSON.stringify({
            sessionId,
            personaKey: persona.key,
            messages: examinerMessages,
            decisionText,
            contextText,
            registerMode: registerMode ?? 'analytical',
            isExaminerContextCall: true,  // suppresses pushbackProtocol injection + DB saves
          }),
        })
        if (!res.ok || !res.body) { setExaminerUpdateState('done'); return }

        const reader = res.body.getReader()
        const decoder = new TextDecoder()
        let acc = ''
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          acc += decoder.decode(value, { stream: true })
          setExaminerUpdate(stripHeaderTags(acc))
        }
        setExaminerUpdateState('done')
        // Update completedResponses in SessionView with the full combined content
        if (acc) {
          const cleanAcc = stripHeaderTags(acc)
          // P1 fix: this stream loop never parsed <lean> before stripping it —
          // only the individual-pushback branch in streamResponse() did. Share
          // to All Advisors goes through THIS function, not that one, so a
          // lean shift triggered by this path was silently discarded, which
          // meant leanShifts computed in SynthesisCard was always empty for
          // anyone using Share to All Advisors instead of per-persona Challenge
          // — i.e. the weight-delta boost (Gap #2) never actually fired.
          const leanMatch = acc.match(/<lean>([\s\S]*?)<\/lean>/)
          if (leanMatch) {
            const lean = leanMatch[1].trim().toLowerCase()
            if (lean === 'proceed' || lean === 'wait' || lean === 'mixed') {
              onLeanUpdateRef.current?.(persona.key, lean)
            }
          }
          const fullContent = [rawInitialRef.current || responseRef.current, `[Updated after Examiner answers]\n${cleanAcc}`,
            ...exchangesRef.current.map(e => `[Pushback: "${e.user}"]\n${e.reply}`)
          ].join('\n\n')
          onCompleteRef.current?.(persona.key, fullContent)
          // Sprint 16b Fix 4b: notify SessionView this update is done — used to count share-context completions
          onExaminerUpdateCompleteRef.current?.(persona.key, fullContent)
        }
      } catch {
        setExaminerUpdateState('done')
      }
    }

    runExaminerUpdate()
  }, [examinerContext, sessionId, persona.key, decisionText, contextText, registerMode, stripHeaderTags])

  // ── Structural echo — retroactive enrichment (2026-08-08) ─────────────────
  // structuralContext (prop, from SessionView) depends on a whole ontology-
  // tagging + scoring pipeline that this persona's own initial call never
  // waits for — see app/api/persona/structural-enrich/route.ts's doc comment
  // for the full timing explanation. This effect is what catches the case
  // where structuralContext arrives after this persona's initial response is
  // already 'done' with no <structural> tag: it makes exactly one
  // best-effort call to ask, retroactively, whether the now-available match
  // applies. `attemptedRef` guards against firing more than once per mount —
  // this effect legitimately re-runs when structuralContext transitions from
  // undefined to a real string (it's a dependency), and must not re-fire
  // again after that on every subsequent unrelated re-render.
  const structuralEnrichAttemptedRef = useRef(false)
  useEffect(() => {
    if (structuralEnrichAttemptedRef.current) return
    if (panelState !== 'done') return
    if (!structuralContext) return
    if (!PERSONAS_WITH_STRUCTURAL_CONTEXT.has(persona.key)) return
    const currentRaw = rawInitialRef.current || responseRef.current
    if (!currentRaw) return
    if (/<structural>[\s\S]*?<\/structural>/.test(currentRaw)) return  // already has one — nothing to add

    structuralEnrichAttemptedRef.current = true

    fetch('/api/persona/structural-enrich', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        sessionId,
        personaKey:        persona.key,
        originalResponse:  currentRaw,
        structuralContext,
      }),
    })
      .then(r => r.json())
      .then((data: { structuralTag?: string | null }) => {
        if (!data.structuralTag) return  // no applicable match, or something failed server-side — no-op by design
        const structuralMatch = data.structuralTag.match(/<structural>([\s\S]*?)<\/structural>/)
        if (!structuralMatch) return
        setStructuralCitationText(structuralMatch[1].trim())
        // Append to the raw tag-intact record (same field every other
        // supplemental update reads from and writes back to — pushback,
        // examiner updates — so a reload still shows this citation).
        rawInitialRef.current = `${currentRaw}\n\n${data.structuralTag}`
        const fullContent = [rawInitialRef.current,
          ...exchangesRef.current.map(e => `[Pushback: "${e.user}"]\n${e.reply}`),
        ].join('\n\n')
        onCompleteRef.current?.(persona.key, fullContent)
      })
      .catch(() => { /* additive-only feature — silent failure is correct here */ })
  }, [structuralContext, panelState, sessionId, persona.key])

  const handlePushback = async () => {
    if (!pushback.trim()) return
    const challengeText = pushback
    const updated: Message[] = [
      ...messages,
      { id: Date.now().toString(), session_id: sessionId, persona: persona.key, role: 'user', content: challengeText, created_at: new Date().toISOString() },
    ]
    setMessages(updated)
    setPushback('')
    setShowPushback(false)
    setIsPushingBack(true)
    onFirstChallengeUsed?.()
    // Automatic percolation: a challenge is new evidence, not reasoning
    // specific to this one advisor — broadcast it to the rest of the council
    // immediately, in parallel with this advisor's own detailed reply below,
    // rather than waiting for a manual "Share to all advisors" click. Each of
    // the other advisors reassesses independently through its own lens (see
    // the examinerMsg wording in handleShareContext, SessionView.tsx) — this
    // call shares the raw new information only, never this advisor's take on
    // it. See handleShareContext / handleExaminerUpdateComplete in
    // SessionView for how this advisor's own completion below and the other
    // five's are folded into exactly one downstream synthesis re-run.
    onShareContext?.(challengeText)
    await streamResponse(updated, false)
  }

  const StatusBadge = () => {
    if (isPushingBack) return (
      <span style={{ fontSize: 11, color: 'var(--gold)', display: 'flex', alignItems: 'center', gap: 5 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold)', display: 'inline-block', animation: 'blink 1s step-end infinite' }} />
        Reading your challenge…
      </span>
    )
    if (panelState === 'streaming' && !isPushingBack) return (
      <span style={{ fontSize: 11, color: 'var(--gold)', display: 'flex', alignItems: 'center', gap: 5 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold)', display: 'inline-block', animation: 'blink 1s step-end infinite' }} />
        Reading
      </span>
    )
    if (examinerUpdateState === 'streaming') return (
      <span style={{ fontSize: 11, color: 'var(--info-text)', display: 'flex', alignItems: 'center', gap: 5 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--info-text)', display: 'inline-block', animation: 'blink 1s step-end infinite' }} />
        Updating
      </span>
    )
    // Sprint 16b Fix 3: show "Responded" once a pushback exchange has completed
    if (panelState === 'done' && exchanges.length > 0) return (
      <span style={{ fontSize: 11, color: 'var(--success-text)', display: 'flex', alignItems: 'center', gap: 4 }}>
        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="9 14 4 9 9 4"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/></svg>
        Responded
      </span>
    )
    if (panelState === 'done') return <span style={{ fontSize: 11, color: 'var(--success-text)' }}>✓</span>
    if (panelState === 'error') return (
      <span style={{ fontSize: 11, color: '#e05050', display: 'flex', alignItems: 'center', gap: 8 }}>
        ✗ error
        <button
          onClick={retryNow}
          style={{
            fontSize:     11,
            fontWeight:   600,
            color:        '#e05050',
            background:   'transparent',
            border:       '1px solid #e05050',
            borderRadius: 4,
            padding:      '1px 7px',
            cursor:       'pointer',
          }}
        >
          Retry
        </button>
      </span>
    )
    return null
  }

  // R6: structural citation badge — renders ONLY when THIS persona's own output
  // contained a <structural> tag. structuralMatchDate/structuralMatchSessionId
  // are session-wide (which past decision matched), reused across every eligible
  // persona; structuralCitationText is persona-specific (what THIS advisor
  // actually observed) and is the true gate — precise instead of a stand-in flag.
  const structuralCitationBlock = (structuralCitationText && panelState === 'done') ? (
    <div style={{
      marginTop:    16,
      padding:      '10px 12px',
      borderRadius: 8,
      background:   'var(--success-bg)',
      border:       '1px solid var(--success-border)',
    }}>
      <p style={{
        fontSize:      10,
        fontWeight:    700,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        color:         'var(--success-text)',
        margin:        '0 0 5px',
        display:       'flex',
        alignItems:    'center',
        gap:           5,
      }}>
        <span aria-hidden="true">↺</span> Structural echo
      </p>
      <p style={{
        fontSize:   12,
        color:      'var(--success-text)',
        lineHeight: 1.6,
        margin:     structuralMatchDate ? '0 0 6px' : 0,
      }}>
        {structuralCitationText}
      </p>
      {structuralMatchDate && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <span style={{ fontSize: 11, color: 'var(--success-text)', opacity: 0.85 }}>
            From a decision you brought in{' '}
            {new Date(structuralMatchDate).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
          </span>
          {structuralMatchSessionId && (
            <a
              href={`/record/${structuralMatchSessionId}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                fontSize:       11,
                fontWeight:     600,
                color:          'var(--success-text)',
                textDecoration: 'underline',
                whiteSpace:     'nowrap',
                flexShrink:     0,
              }}
            >
              View that decision →
            </a>
          )}
        </div>
      )}
    </div>
  ) : null

  return (
    <div ref={rootRef} className={`persona-card ${panelState === 'streaming' ? 'streaming' : panelState === 'done' ? 'done' : ''}`} style={{ minHeight: 280, borderLeft: `3px solid ${accentColor}` }}>
      {/* S5-01: Rate limit banner — shown when 429 is returned from /api/persona */}
      {rateLimitInfo && (
        <div style={{ padding: '8px 12px 4px' }}>
          <RateLimitBanner
            message={rateLimitInfo.message}
            resetAt={rateLimitInfo.resetAt}
            onExpired={clearRateLimit}
          />
        </div>
      )}

      {/* R6: the old top-of-card banner here was gated on a session-wide flag AND
          hardcoded to pattern_analyst, with copy that named the persona directly —
          it could show even when this persona's own output never referenced the
          past decision, and never showed on the other 4 eligible personas at all.
          Replaced by a citation badge anchored at the end of the analysis (see
          "Structural echo" block below), driven entirely by whether THIS persona's
          own <structural> tag is present — no hardcoded persona list, no
          disconnect between what's claimed and what was actually said. */}

      {/* Header */}
      <div style={{ padding: '12px 16px 10px', borderBottom: '1px solid var(--border-dim)', background: 'var(--bg-card-alt)', borderRadius: '14px 14px 0 0' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 6 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
            <div style={{ width: 24, height: 24, borderRadius: 6, background: `${accentColor}22`, border: `1px solid ${accentColor}55`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: accentColor, flexShrink: 0 }}>
              {icon}
            </div>
            <div style={{ minWidth: 0 }}>
              {/* Fix (2-col mobile grid): was 12.5/11px in a row that also had
                  to fit StatusBadge + the "Read full analysis" toggle at
                  half phone-screen width — the longer persona names
                  ("The Stakeholder Mirror") left the toggle's label with
                  nowhere to go but overflow/clip past the card edge.
                  Trimmed a notch here, and moved the toggle to its own row
                  below (see after this closing div) so it no longer
                  competes with this row for width at all — the font size
                  alone couldn't have fixed that regardless of how small. */}
              <p style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--text-1)', lineHeight: 1.25 }}>{persona.label}</p>
              {/* Show lens caption when available (replaces static tagline) — keeps header compact */}
              <p style={{ fontSize: 10.5, color: 'var(--text-3)', lineHeight: 1.3, marginTop: 2, maxWidth: 220 }}>
                {lensText || persona.tagline}
              </p>
            </div>
          </div>
          <div style={{ flexShrink: 0 }}>
            <StatusBadge />
          </div>
        </div>  {/* close justify-between */}
        {/* Item #9 (revised), then Council redesign (Sprint 2 and round 2):
            was mobile-only + done-only + icon-only, then given a visible
            label but left in the icon+label+StatusBadge row above — fine at
            3-column desktop width, broke at the new 2-column mobile width
            (see fix note above). Its own row now, full width, so the label
            always has the whole card to lay out in regardless of persona
            name length. */}
        {(panelState === 'streaming' || panelState === 'done') && (
          <button
            className="persona-mobile-toggle"
            onClick={() => setMobileCollapsed(c => !c)}
            aria-expanded={!mobileCollapsed}
            aria-label={mobileCollapsed ? 'Read full analysis' : 'Show less'}
            style={{
              width: '100%', marginTop: 8, background: 'transparent', border: 'none', cursor: 'pointer',
              color: 'var(--text-4)', padding: '2px 0', display: 'none',
              alignItems: 'center', justifyContent: 'center', gap: 4, font: 'inherit', fontSize: 11, fontWeight: 500,
            }}
          >
            <span>{mobileCollapsed ? 'Read full analysis' : 'Show less'}</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
              style={{ transform: mobileCollapsed ? 'none' : 'rotate(180deg)', transition: 'transform 0.2s' }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
        )}
      </div>

      {/* Body — Item #33/#34 §2.2: split into an always-visible summary
          (position + a compact real-cost preview while collapsed) and a
          collapsible detail block. Previously `.persona-body-mobile` wrapped
          the entire body, so collapsing on mobile hid the stance too — a
          glance at a collapsed card told you nothing. The summary below sits
          outside that class so it survives collapse; the detail block below
          it keeps the exact same className/is-collapsed behavior as before. */}
      <div style={{ padding: '14px 16px 0' }}>
        {positionText && (
          <div style={{ marginBottom: mobileCollapsed && realCostText ? 10 : 14 }}>
            {/* Council redesign (Sprint 2), point B — "color classification".
                initialLean (frozen, same convention as positionText/
                realCostText above) rather than the live-updating currentLean,
                so this badge never disagrees with the frozen verdict sentence
                sitting right below it; a post-pushback shift already has its
                own "Shifted after pushback" line just underneath. */}
            {initialLean && (
              <div style={{ marginBottom: 8 }}>
                <LeanBadge lean={initialLean} />
              </div>
            )}
            <p style={{
              fontSize:   15,
              fontWeight: 600,
              fontFamily: 'var(--font-display)',
              color:      'var(--text-1)',
              lineHeight: 1.5,
              margin:     '0',
            }}>
              {positionText}
            </p>
            {/* Vet-fix (b): positionText/realCostText above are deliberately
                frozen at the original response — kept that way so "what did
                this advisor originally think" stays a stable reference point
                while the pushback thread below shows the prose evolution.
                But this persona's <lean> classification does keep updating
                on pushback (onLeanUpdate → SessionView's personaLeans →
                fed back in as currentLean), and that updated value already
                drives synthesis weighting and the What Changed drawer
                elsewhere in the session — so leaving this card with no
                visible sign of it meant the card could visibly say
                "Proceed" while the system had already moved this advisor to
                "Wait". This badge doesn't rewrite the header; it just makes
                the shift the system already knows about visible here too. */}
            {initialLean && currentLean && currentLean !== initialLean && (
              <p style={{
                margin:     '6px 0 0',
                fontSize:   11.5,
                fontWeight: 500,
                color:      'var(--gold)',
              }}>
                Shifted after pushback → now leaning {LEAN_LABELS[currentLean]}
              </p>
            )}
            <div style={{ marginTop: 12, borderTop: '1px solid var(--border-dim)' }} />
          </div>
        )}

        {/* Compact real-cost preview — collapsed-mobile only. Item #33/#34
            bugfix: this used to be gated only on the mobileCollapsed JS
            boolean, which can stay true on a desktop-width viewport (e.g.
            the card was collapsed at a narrow width, then the window was
            widened without a reload) — the state doesn't know the CSS
            media query no longer hides the detail block below, so both
            copies of "The real cost" showed at once. Now always rendered
            in the tree; visibility is entirely CSS-driven via
            .persona-collapsed-realcost, which only resolves to visible
            inside the same @media(max-width:600px) block (or, under the
            unified-session flag, the [data-unified-session="true"] rules
            beside it) that hides the detail block — the two can no longer
            disagree.
            Council redesign (Sprint 3, speed): previously also required
            panelState === 'done', which meant this line waited for the
            entire ~200-word response to finish streaming even though
            <realcost> — like <position> above, which has no such gate —
            is already fully parsed the moment the header block lands, near
            the very start of the stream. Dropped that requirement so the
            collapsed executive summary (position + this line) finishes
            within a couple of seconds of a persona starting to respond,
            not only once it's completely done. */}
        {realCostText && (
          <p
            className={`persona-collapsed-realcost${mobileCollapsed ? ' is-collapsed' : ''}`}
            style={{
              fontSize:   12,
              fontStyle:  'italic',
              color:      'var(--text-4)',
              lineHeight: 1.6,
              margin:     '0 0 14px',
            }}
          >
            {realCostText}
          </p>
        )}
      </div>

      <div
        className={`persona-body-mobile${mobileCollapsed ? ' is-collapsed' : ''}`}
        style={{ flex: 1, padding: '0 16px 14px', overflowY: 'auto', maxHeight: 380 }}
      >

        {/* Original response — never mutated */}
        {response && (
          <p className={`persona-response ${panelState === 'streaming' && !isPushingBack ? 'cursor' : ''}`}>
            {renderAssumption(response, panelState === 'done')}
          </p>
        )}

        {/* Real cost — closing beat, shown once prose is complete.
            Sits below exchanges (or below analysis if no pushback) as a persistent conclusion.
            S3-05: labelled — this is the advisor's closing statement, previously
            unmarked italic text indistinguishable from a stray aside. */}
        {realCostText && panelState === 'done' && exchanges.length === 0 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ borderTop: '1px solid var(--border-dim)', marginBottom: 10 }} />
            <p style={{
              fontSize:      10,
              fontWeight:    700,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color:         'var(--text-4)',
              margin:        '0 0 4px',
            }}>
              The real cost
            </p>
            <p style={{
              fontSize: 12,
              fontStyle: 'italic',
              color: 'var(--text-4)',
              lineHeight: 1.7,
              margin: 0,
            }}>
              {realCostText}
            </p>
          </div>
        )}

        {/* Pushback exchanges */}
        {exchanges.map((ex, i) => (
          <div key={i} style={{ marginTop: 18 }}>
            <div style={{ borderRadius: 8, padding: '8px 12px', background: 'var(--bg-inset)', border: '1px solid var(--border-dim)', marginBottom: 10, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 11, color: 'var(--gold)', flexShrink: 0, marginTop: 1 }}>↩</span>
              <div>
                <p style={{ fontSize: 11, color: 'var(--text-4)', marginBottom: 2 }}>Your pushback</p>
                <p style={{ fontSize: 12.5, color: 'var(--text-3)', lineHeight: 1.5 }}>{ex.user}</p>
              </div>
            </div>
            <p className="persona-response">{ex.reply}</p>
          </div>
        ))}

        {/* Real cost — persists below pushback exchanges too */}
        {realCostText && panelState === 'done' && exchanges.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ borderTop: '1px solid var(--border-dim)', marginBottom: 10 }} />
            <p style={{
              fontSize:      10,
              fontWeight:    700,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color:         'var(--text-4)',
              margin:        '0 0 4px',
            }}>
              The real cost
            </p>
            <p style={{
              fontSize: 12,
              fontStyle: 'italic',
              color: 'var(--text-4)',
              lineHeight: 1.7,
              margin: 0,
            }}>
              {realCostText}
            </p>
          </div>
        )}

        {/* Item #14 — synthesized rationale, hidden by default behind a
            small toggle so it never competes with the analysis itself.
            Only shown at all when there's something to show. */}
        {structuralCitationText && panelState === 'done' && (
          <div style={{ marginTop: 16 }}>
            <button
              onClick={() => setShowWhy(w => !w)}
              aria-expanded={showWhy}
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                background: 'transparent', border: 'none', cursor: 'pointer',
                padding: 0, fontFamily: 'inherit',
                fontSize: 11, fontWeight: 600, color: 'var(--text-4)', letterSpacing: '0.03em',
              }}
            >
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                style={{ transform: showWhy ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
                <polyline points="6 9 12 15 18 9" />
              </svg>
              Why
            </button>
            {showWhy && structuralCitationBlock}
          </div>
        )}

        {isPushingBack && (
          <p style={{ fontSize: 12, color: 'var(--gold)', marginTop: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--gold)', display: 'inline-block', animation: 'blink 1s step-end infinite' }} />
            Responding…
          </p>
        )}

        {/* Automatic percolation: challenging this advisor now shares that new
            information with the rest of the council automatically, fired the
            moment the challenge was submitted (see handlePushback) — well
            before this reply even finished streaming. Purely informational;
            there's nothing left to click. Each advisor reassesses
            independently through its own lens (they may keep, strengthen,
            weaken, or reverse their stance) — this note doesn't imply they
            reached the same conclusion, only that they saw the same new
            information. */}
        {panelState === 'done' && !isPushingBack && exchanges.length > 0 && onShareContext && (
          <div style={{
            marginTop: 16, display: 'flex', alignItems: 'center', gap: 6,
            fontSize: 11.5, fontWeight: 600, color: 'var(--gold)', letterSpacing: '0.02em',
          }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
            </svg>
            Shared with the full council — each advisor is reassessing independently
          </div>
        )}

        {/* Examiner update — shown below original, never overwrites */}
        {(examinerUpdate || examinerUpdateState === 'streaming') && (
          <div style={{ marginTop: 16, borderRadius: 8, border: '1px solid var(--info-border)', background: 'var(--info-bg)', padding: '10px 14px', animation: 'examinerFadeIn 0.35s ease-out both' }}>
            <p style={{ fontSize: 10.5, color: 'var(--info-text)', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <polyline points="1 4 1 10 7 10"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10"/>
              </svg>
              Updated with your answers
            </p>
            <p className={`persona-response ${examinerUpdateState === 'streaming' ? 'cursor' : ''}`} style={{ fontSize: 13 }}>
              {examinerUpdate}
            </p>
          </div>
        )}

        {/* Challenge discoverability pass: the disagree control now lives at the
            end of the card's content — where a disagreement actually forms —
            instead of a small pill in the header before the analysis is even
            read. Full-width, primary visual weight, impossible to miss on a
            finished card. Same showPushback/handlePushback state as before,
            just relocated + relabeled + restyled. */}
        {panelState === 'done' && !isPushingBack && examinerUpdateState !== 'streaming' && !showPushback && (
          <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--border-dim)' }}>
            {/* Ambient hint — only on cards that haven't themselves been
                challenged yet, once at least one other card has been. */}
            {anyCardChallenged && exchanges.length === 0 && (
              <p style={{ fontSize: 11, color: 'var(--gold)', opacity: 0.85, margin: '0 0 8px', fontStyle: 'italic' }}>
                You can challenge this one too.
              </p>
            )}
            <button
              data-tour-id="council-challenge"
              title="Disagree with this analysis, add new information, or ask a follow-up"
              onClick={() => setShowPushback(true)}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                width: '100%',
                background: 'rgba(201,168,76,0.12)', border: '1px solid var(--gold-dim)',
                borderRadius: 8, padding: '11px 14px', fontSize: 13, fontWeight: 600,
                color: 'var(--gold)', cursor: 'pointer', transition: 'all 0.2s',
                fontFamily: 'inherit', letterSpacing: '0.02em',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLButtonElement).style.background = 'rgba(201,168,76,0.22)'
                ;(e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--gold)'
                ;(e.currentTarget as HTMLButtonElement).style.boxShadow = '0 0 8px rgba(201,168,76,0.35)'
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLButtonElement).style.background = 'rgba(201,168,76,0.12)'
                ;(e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--gold-dim)'
                ;(e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'
              }}
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 14 4 9 9 4"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/>
              </svg>
              Disagree or ask a follow-up
            </button>
          </div>
        )}

        {panelState === 'idle' && (
          <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 50 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--border-mid)', animation: 'blink 1.2s ease-in-out infinite' }} />
          </div>
        )}
      </div>

      {/* Pushback input — shown below content when triggered from the
          bottom-of-card "Disagree or ask a follow-up" control */}
      {panelState === 'done' && !isPushingBack && examinerUpdateState !== 'streaming' && showPushback && (
        <div style={{ padding: '10px 16px 14px', borderTop: '1px solid var(--border-dim)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <p style={{ fontSize: 11, color: 'var(--text-4)', margin: 0 }}>
              Disagree, add new information, or ask a follow-up
            </p>
            {isUnifiedSessionEnabled() && (
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 2 }}>
                {CHALLENGE_REASONS.map(r => (
                  <button
                    key={r.value}
                    type="button"
                    onClick={() => {
                      setChallengeReason(r.value)
                      // Prefill only — never overwrites something the user
                      // already started typing.
                      if (!pushback.trim()) setPushback(r.prefill)
                    }}
                    style={{
                      padding:      '7px 12px',
                      fontSize:     11.5,
                      borderRadius: 999,
                      border:       `1px solid ${challengeReason === r.value ? 'var(--gold)' : 'var(--border-dim)'}`,
                      background:   challengeReason === r.value ? 'rgba(201,168,76,0.12)' : 'transparent',
                      color:        challengeReason === r.value ? 'var(--gold)' : 'var(--text-4)',
                      cursor:       'pointer',
                    }}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            )}
            <textarea
              rows={2}
              style={{ fontSize: 13, padding: '8px 12px' }}
              placeholder="e.g. But I already have diversified exposure… / What if the timeline is shorter?"
              value={pushback}
              onChange={(e) => setPushback(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handlePushback() }}
              autoFocus
            />
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn-primary" style={{ padding: '7px 18px', fontSize: 12 }} onClick={handlePushback}>
                Send ↵
              </button>
              <button className="btn-ghost" onClick={() => { setShowPushback(false); setPushback(''); setChallengeReason(null) }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── TTS strip — Sprint 23c — bottom of card, accent bg matches header ── */}
      {panelState === 'done' && !showPushback && (
        <div style={{
          borderTop:    '1px solid var(--border-dim)',
          padding:      '7px 14px',
          display:      'flex',
          alignItems:   'center',
          justifyContent: 'space-between',
          background:   'var(--bg-card-alt)',
          borderRadius: '0 0 14px 14px',
        }}>
          {/* Read aloud / Stop */}
          <button
            onClick={() => {
              if (isThisSpeaking && isPaused) { resume(); return }
              if (isThisSpeaking) { pause(); return }
              speak(response, persona.key)
            }}
            title={isThisSpeaking && isPaused ? 'Resume' : isThisSpeaking ? 'Pause' : 'Read aloud'}
            style={{
              display:       'flex',
              alignItems:    'center',
              gap:           5,
              padding:       '4px 10px',
              borderRadius:  5,
              border:        isThisSpeaking
                               ? '1px solid rgba(201,168,76,0.5)'
                               : '1px solid var(--tts-btn-border)',
              background:    isThisSpeaking
                               ? 'rgba(201,168,76,0.15)'
                               : 'var(--tts-btn-bg)',
              color:         isThisSpeaking
                               ? 'var(--gold)'
                               : 'var(--tts-btn-color)',
              fontSize:      11,
              fontWeight:    500,
              cursor:        'pointer',
              fontFamily:    'inherit',
              transition:    'all 0.18s',
              letterSpacing: '0.01em',
            }}
          >
            {isThisSpeaking && isLoading ? (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"
                style={{ animation: 'spin 0.9s linear infinite' }}>
                <path d="M21 12a9 9 0 1 1-6.22-8.56"/>
              </svg>
            ) : isThisSpeaking && isPaused ? (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                <polygon points="5 3 19 12 5 21 5 3"/>
              </svg>
            ) : isThisSpeaking ? (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                <rect x="5" y="4" width="4" height="16" rx="1"/><rect x="15" y="4" width="4" height="16" rx="1"/>
              </svg>
            ) : (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                <polygon points="5 3 19 12 5 21 5 3"/>
              </svg>
            )}
            <span>{isThisSpeaking && isLoading ? (countdown !== null && countdown > 0 ? `~${countdown}s` : 'Starting…') : isThisSpeaking && isPaused ? 'Resume' : isThisSpeaking ? 'Pause' : 'Read aloud'}</span>
          </button>

          {/* Stop button — shown while speaking or paused */}
          {isThisSpeaking && (
            <button
              onClick={() => stop()}
              title="Stop"
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                padding: '4px 8px', borderRadius: 5,
                border: '1px solid var(--tts-btn-border)',
                background: 'var(--tts-btn-bg)',
                color: 'var(--tts-stop-color)',
                fontSize: 11, fontWeight: 500, cursor: 'pointer',
                fontFamily: 'inherit', transition: 'all 0.18s',
              }}
            >
              <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor">
                <rect x="4" y="4" width="16" height="16" rx="2"/>
              </svg>
              <span>Stop</span>
            </button>
          )}

          {/* Pace cycle button — pre-set or change mid-play */}
          <button
            onClick={() => {
              const rates = [1, 1.5, 2]
              const next = rates[(rates.indexOf(rate) + 1) % rates.length]
              setRate(next)
            }}
            title="Playback speed"
            style={{
              padding:       '4px 9px',
              borderRadius:  5,
              border:        rate !== 1
                               ? '1px solid rgba(201,168,76,0.5)'
                               : '1px solid var(--tts-btn-border)',
              background:    rate !== 1
                               ? 'rgba(201,168,76,0.15)'
                               : 'var(--tts-btn-bg)',
              color:         rate !== 1
                               ? 'var(--gold)'
                               : 'var(--tts-btn-color)',
              fontSize:      11,
              fontWeight:    600,
              cursor:        'pointer',
              fontFamily:    'inherit',
              transition:    'all 0.18s',
              letterSpacing: '0.03em',
            }}
          >
            {rate === 1 ? '1×' : rate === 1.5 ? '1.5×' : '2×'}
          </button>
        </div>
      )}
    </div>
  )
}
