# Round 4 — Changelog

20 files (2 new, 18 edited). **Full current state — supersedes everything
before it.**

## Copy pass completion (tour steps + FAQ)

Read every onboarding tour step in full — `COUNCIL_STEPS_BASE` in
`SessionView.tsx`, `RecordTour.tsx`, the home page's own steps, and
`OnboardingTour.tsx`'s PWA-install step builder — and the entire
`FAQSection.tsx` file end to end. Nothing further needed fixing beyond
round 3; cleaned up a few more stale dev comments still referencing removed
mechanisms, and one precision edit to a dev comment ("collapsed-Council" →
"compact-summary Council").

## E1 — "See Quorum's full read" click requirement removed

`predictionAcknowledged` used to default `false` and only flip via that
button's `onContinue`. **Turned out it gated three things at once**, not
just synthesis: the synthesis card, the six-card Council section, and the
lock-decision section were all waiting on it. Changed the default to
`true` — all three now become visible automatically, each on its own
`synthesisDone`-style condition, no click anywhere in the chain. The button
in `QuorumPrediction.tsx` stops rendering on its own (it was already
conditioned on `!alreadyAcknowledged`) rather than being separately
removed. Simplified the three now-redundant `&& predictionAcknowledged`
conditions and their comments instead of leaving dead logic in place.

## E2 — `<estimate>`/`<assumption>`/`<reversal>` tag leak fixed

Root cause, confirmed against your screenshot: these are legitimate inline
tags the model can place inside a `<realcost>` or `<position>` sentence.
Each file's *body paragraph* already stripped them correctly — but the
*header-field extraction* (the short summary/realcost line) never did, in
**four separate places that each independently reimplement tag
extraction** (found via a pre-existing guardrail test,
`tests/persona-tag-wiring-guardrail.test.ts`, which documents exactly
this "five independent sinks" pattern):

- `components/PersonaPanel.tsx` — live session page (your screenshot)
- `app/record/[id]/page.tsx` — record page
- `components/RecordExport.tsx` — PDF export
- `app/api/record/[id]/brief/route.ts` — server-side PDF generation

Checked the fifth sink the test names
(`app/api/session/[id]/observation/route.ts`) — doesn't need the fix, it
deletes header tags outright rather than extracting+displaying them, so
there's nothing to leak. Also checked `synthesis-summary/route.ts`
(powers the Reanalyze drawer) — confirmed the synthesis prompt never
instructs `<estimate>`/`<reversal>` at all (they're defined only inside
`WORD_LIMIT_PREFIX`, concatenated exclusively with the six persona
prompts), so that route was safe by construction, not by luck.
Cross-checked the fix against the guardrail test's own assertions — my
additions use a simple standalone-marker strip
(`.replace(/<\/?estimate>/g, '')`), not the "requires a closing tag" idiom
the test's truncation-guard check scrutinizes, so it doesn't trip that
assertion; manually confirmed all four files still contain every
instructed tag name (the test's other assertion).

## New bug 1 — Record page "Back" was landing on the instinct-capture step

`BackButton` used `router.back()` (browser history) everywhere, including
on the record page — worked correctly for its original use ("back to
Council" from within an active session, where a fresh server refetch is
wanted) but from the record page it went to whatever route was previously
in history, which turned out to be the session page's initial
instinct-capture render (`SessionView` fully remounts across that route
boundary and has no "resume where I left off" to land on). Added an opt-in
`href` prop to `BackButton` — when provided, navigates straight there via
`router.push` instead of using history at all. Default behavior (no `href`)
is unchanged everywhere else `BackButton` might be used. Both "← Back"
instances on the record page (top header, bottom tray) now pass `href="/"`.

## New bug 2 — Transparent button backgrounds, checked across the codebase

Root cause for `.btn-ghost` (used by "New Decision", "Back", and anything
else using that class) and `.btn-pushback`: `background: transparent` in
`globals.css`. Looked fine against the dark theme's higher-contrast
border; against light theme (now the default) with `--border-dim`'s lower
contrast, it reads as barely-there. Fixed both classes at the source —
`background: var(--bg-card)` instead of `transparent` — theme-aware,
visually secondary to `.btn-primary`'s gold fill, but now looks like an
actual button in both themes.

Then swept the whole codebase for the same pattern rather than stopping at
the shared classes, since plenty of buttons use bespoke inline styles
instead of `.btn-ghost`/`.btn-pushback`. Checked every `background:
'transparent'` / `background: 'none'` hit individually — most turned out
to be a different, intentional pattern (borderless inline text-actions
like "Cancel"/"Remove"/"Done", or icon buttons that are meant to be
invisible until hover) and were left alone; fixed the ones that were
genuinely styled as real bordered buttons with no fill:

- `components/CaseStudyReviewPanel.tsx` — reject button, sitting right
  next to an approve button that already has a solid fill.
- `components/VoiceInput.tsx` — all four (stop-recording, start "Voice
  input," "Try again," and the dismiss icon button).
- `components/StyleCalibration.tsx` — found something worse than
  transparency here: the whole card, its progress bar, and its answer
  option buttons were built on `var(--border)` and `var(--surface)`,
  **neither of which is defined anywhere in `globals.css`** — an
  independent, pre-existing bug (likely written against different token
  names than the rest of the app uses), meaning this component has
  probably been rendering without any real border or background this
  whole time, not just a transparent one. Fixed to `--border-dim` /
  `--bg-card`, matching the rest of the app. Swept the codebase for the
  same undefined-variable mistake elsewhere — this was the only file.

## How this was verified

Diffed against a fresh extraction of your original upload — 20 files,
matches expectations. `tsc --noEmit` against the real project types —
zero syntax errors, zero hits on any new identifier from this round.
Manually simulated the guardrail test's tag-presence assertion against
all four E2-fixed files (all pass). Same caveat as every prior round: no
network access here, so no full build/dev-server/vitest run — worth a
real smoke test before merging, particularly the Back button's new
destination and the button-background changes in both themes.
