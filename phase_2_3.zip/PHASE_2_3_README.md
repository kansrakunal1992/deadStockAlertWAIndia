# Quorum — Phase 2 + Phase 3 (retention work)

**Apply AFTER `phase_0_1.zip`.** Unzip over the repo root. 15 files changed, 15 new (plus this README).
Several files here (e.g. `ChatIntake.tsx`, `NextDecisionPrompt.tsx`, `ConnectCard.tsx`) were already in the Phase 0/1 zip; these are the complete current versions, so they replace those.
`tsconfig.json` is not included (`next build` rewrites it locally).

## Deploy order
1. Run `supabase/phase2_3_notifications.sql` (new `user_preferences` columns, widened `notification_log` source check, `pattern_notice_log`). Safe to re-run. **Run it before deploying** — the new crons and the habit route read these columns.
2. Deploy the code. Everything user-facing in Phase 3 is **off by default** (`NEXT_PUBLIC_AUTH_GATE_MODE=off`).
3. Add two cron jobs (same pattern as the others, `Authorization: Bearer <CRON_SECRET>`, POST):
   - `/api/cron/weekly-brief` — suggested `0 4 * * 0` (Sundays 04:00 UTC)
   - `/api/cron/pattern-notice` — suggested daily, after the other nudge crons (e.g. `0 5 * * *`)
4. Optional, when you are ready to test the gate: set `NEXT_PUBLIC_AUTH_GATE_MODE` (see below) and redeploy (it is a build-time public var).

## Phase 2
| Item | What it does | Files |
|---|---|---|
| 2.1 anonymous D2 callback | The "you've made a structurally similar choice N times" count now also looks at rows that share the session's `device_id`, so anonymous people (and signed-in people's pre-fix chat sessions) get it. `device_id` is read from the DB row, never from the caller. | `lib/decision-history.ts` (new), `app/api/session/[id]/decide/route.ts` |
| 2.2 D2 ending | Under the second decision: a small **"Across your two decisions"** card, then the usual field + button, then a one-time habit card (where will you bring the next one? / how should Quorum bring decisions back?), then the earned connect card. Anonymous choices wait in localStorage and are filed after sign-in. | `components/NextDecisionPrompt.tsx`, `components/HabitSetupCard.tsx`, `lib/habit-prefs.ts`, `app/api/preferences/habit/route.ts`, `app/auth/callback/page.tsx`, `components/ConnectCard.tsx` (mode `d2_earned`) |
| 2.3 Watchlist | Already mounted in Phase 1; weekly brief now lists open items. | — |
| 2.4 weekly brief | Cron. Goes only to people who chose **Weekly**, have not opted out, are not mid-streak (no decision in the last 3 days), and have not had one in 6 days; respects the shared 3-day nudge gate. Parked text is plain text in the email, never in a URL. CTA → `/q`. | `app/api/cron/weekly-brief/route.ts`, `lib/cron-email.ts` |
| 2.5 progress | `EarlyEchoCard` now shows pips toward the **next** milestone (3, then 5) and one consistent story; its echo-hint and cross-device count correction are untouched. (Deviation from the plan: modified the existing card instead of adding a parallel component, to keep that logic.) | `components/EarlyEchoCard.tsx` |
| 2.6 variable one-liner | `/api/session/[id]/cross-decision` returns one deterministic, counts-only line (priority repeated, instinct followed/overridden). Rotates by decision count + session id; says "No overlap yet" rather than inventing a pattern. No model-written text, so no fabrication guard needed. | `lib/cross-decision-observations.ts`, `app/api/session/[id]/cross-decision/route.ts` |
| 2.7 push | `PushEnablePrompt` mounted in the chat front door for signed-in people with 2+ decisions. | `components/ChatIntake.tsx` |
| 2.8 review email | One quiet line under the button: "Got another one on your mind? Bring it to Quorum." (link, not a second button). | `app/api/cron/reanalyze-email/route.ts` |

## Phase 3
| Item | What it does | Files |
|---|---|---|
| 3.1 gate (experiment) | `NEXT_PUBLIC_AUTH_GATE_MODE`: `off` (default) / `d3` (gate at 2 decisions) / `d4` (at 3) / `experiment` (each device hashed into `gate_d3`, `gate_d4`, or `soft_only` control). Gated = the chat input is replaced by a **non-skippable** connect card; existing records stay open. Enforced on the client **and** in `POST /api/chat-intake` (returns 403 `auth_required`; the client rolls back the typed message and shows the card). Arm is logged once per device as `gate_arm_assigned`. People with no device id (no cookie consent) are never gated. | `lib/auth-gate.ts`, `app/api/chat-intake/route.ts`, `components/ChatIntake.tsx`, `components/ConnectCard.tsx` (mode `d3_gate`) |
| 3.2 home screen + `/q` | Install prompt from the 2nd decision (Android/desktop via `beforeinstallprompt`; iOS tip only for people `PushEnablePrompt` does not already cover). `/q` opens the app with the input focused. The manifest and service worker already existed. | `components/AddToHomeScreenPrompt.tsx`, `app/q/page.tsx`, `ChatIntake.tsx` |
| 3.3 "Quorum noticed something" | Cron. Looks only at people with a decision in the last 2 days; sends only a **new** finding (priority repeated in ≥3 of last ≥4, or instinct followed/overridden ≥75% / ≤25% of ≥4), once per finding (unique key), max one per 14 days, shared nudge gate, one-click unsubscribe. The finding is claimed in `pattern_notice_log` **before** sending and released if the send fails. | `app/api/cron/pattern-notice/route.ts` |
| unsubscribe | New `weekly` and `pattern` token types and opt-out columns. | `lib/nudge-token.ts`, `app/api/cron/unsubscribe/route.ts`, `lib/notification-throttle.ts` |
| events | Added `gate_arm_assigned`, `observation_seen`, `habit_saved`, `install_prompt_seen`, `install_prompt_accepted`. | `lib/track.ts`, `app/api/events/route.ts` |

## One primary button per screen (unchanged rule)
The D2 additions are all outline-style: the observation card has no button, the habit card uses chips + an outline Save, the connect cards are outline-only, and the install prompt is outline-only. The gate screen has no other action on it.

## Running the gate experiment
- Set `NEXT_PUBLIC_AUTH_GATE_MODE=experiment`. Report **D4 reach within 30 days of D1, by arm** (join `events.gate_arm_assigned.props.arm` on `device_id` to `v_actor_decisions`). Do not compare authenticated vs anonymous directly — that is selection-biased; the arms are the control.
- Watch D2→D3 (gate_d3 arm) against `soft_only` as the cost side of the trade.

## Things to know
- **Observation lines need priority/instinct data.** `optimization_priority` and `initial_instinct` come from the lean chips, which exist only when `NEXT_PUBLIC_UNIFIED_SESSION_ENABLED` is on. With it off the second-decision card will mostly show "No overlap yet" (or nothing), and the pattern-notice cron will rarely find anything.
- Only **Weekly** triggers email. "Only when I'm stuck" and "Only for big decisions" are recorded but send nothing.
- The record page does not show the observation / habit card (`showExplainer={false}` there, to avoid stacking on the brief CTA and progress card).
- Gate counting is by `sessions.device_id`; it is as strong as the device id (clearing storage resets it).

## Mistake caught during the build (transparency)
I first put the cross-decision route at `app/api/session/[id]/observation/route.ts` — a path that **already existed** (the Mirror observation-feed route) — and overwrote it. The repo's own tag-wiring guardrail test failed and caught it. I restored the original byte-for-byte (verified with `cmp`) and moved my route to `.../cross-decision`. The original route is **not** in this zip and is unchanged. I also diffed every changed file against your original upload to confirm no other file was overwritten unintentionally.

## Verified vs not
- Verified: `tsc` (no new errors; only the pre-existing TS2802 target noise), **113 tests pass** (95 existing + 18 new for the observation logic and the gate), `next build` succeeds (same single pre-existing Edge-runtime warning).
- NOT verified: SQL against a real database; the crons have never been run; Resend/push delivery; the gate against real devices; mobile visuals. Run the checklist on staging.

## Staging checklist
1. Run the SQL, then call both crons manually with the secret (empty `{ok:true,sent:0,…}` is fine with no eligible users).
2. Two anonymous decisions with the unified flag on → the second shows "Across your two decisions", the habit card (once), and the connect card; choosing Weekly while anonymous changes the connect line.
3. Sign in → habit choice appears in `user_preferences` (`brief_cadence`, `next_decision_cue`).
4. Set a test user to `brief_cadence='weekly'` with their last session > 3 days old → `weekly-brief` sends one email; run it again → skipped (6-day rule).
5. Gate: set `NEXT_PUBLIC_AUTH_GATE_MODE=d3`, redeploy, make 2 anonymous decisions on one device → the input is replaced by the connect card; type nothing, try the API directly without a token → 403 `auth_required`; sign in → input returns.
6. `/q` opens with the input focused and the URL tidied; mode `off` → nothing changes anywhere.

## Still not built
Home-screen install analytics beyond the two events, per-user send-time, a unsubscribe/preferences page for the new emails beyond the one-click link, and cadence-specific `when_stuck` sending.
