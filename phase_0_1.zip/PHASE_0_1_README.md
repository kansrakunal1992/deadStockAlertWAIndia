# Quorum — Phase 0 + Phase 1 (retention work)

Unzip over the repo root (paths match the repo). 16 files changed, 13 new (plus this README).
`tsconfig.json` is NOT included — `next build` rewrites it locally; ignore that diff.

## Deploy order
1. Run `supabase/phase0_events.sql` (events table). Safe to run late: `/api/events` answers 204 even if the table is missing.
2. Deploy the code.
3. Set `NEXT_PUBLIC_WATCHLIST_ENABLED=true` (and make sure `supabase/sprint_w1_add_watchlist.sql` is applied) if you want "Park it for later" and the Watchlist in the chat front door. With the flag off, the Park button and Watchlist simply do not render.
4. Review `supabase/phase0_backfill_chat_user_ids.sql` — run the PREVIEW query first; the apply step is inside a transaction and only links devices that map to exactly one user. Do not run it unreviewed.
5. Create the funnel views from `supabase/phase0_funnel_views.sql` (works today from `sessions`, no events needed).

## Phase 0
| Item | What changed | Files |
|---|---|---|
| 0.1 user_id fix | Chat flow now sends the bearer token on `/api/chat-intake` and `/api/chat-intake/checkpoint`, so `chat_intakes` and `sessions` get `user_id` for signed-in people. Token is read fresh at call time. | `lib/auth-headers.ts` (new), `components/ChatIntake.tsx`, `components/DecisionCheckpoint.tsx` |
| 0.1b | "I'm done" sessions never reached local history (only `/session/[id]` wrote it). Now added via `pushSessionId` (consent-gated). | `components/DecisionCheckpoint.tsx` |
| 0.2 backfill | Preview-first SQL for rows already saved with `user_id = null`. | `supabase/phase0_backfill_chat_user_ids.sql` |
| 0.3 events | `events` table, `POST /api/events` (identity resolved server-side from the token; allow-listed event names; sanitised props), `track()` helper, `LIMITS.events`. | `supabase/phase0_events.sql`, `app/api/events/route.ts`, `lib/track.ts`, `lib/rate-limit.ts` |
| 0.3 funnel | `v_actor_decisions` + `v_retention_funnel` (D1→D5+, anonymous vs linked, 14d/30d windows) from `sessions`. | `supabase/phase0_funnel_views.sql` |
| 0.4 fixes | Home session count no longer reads 0 for anonymous users with decisions; top-bar label "Keep my record" instead of "Sign in"; local id cap 20→100 in `SessionView`; sign-in returns to the page you were on (`?rt=` for magic links incl. other browsers, localStorage for Google). Same-origin paths only. | `ChatIntake.tsx`, `SessionView.tsx`, `lib/return-to.ts` (new), `lib/google-auth.ts`, `components/GoogleSignInButton.tsx`, `app/api/auth/route.ts`, `app/auth/callback/page.tsx` |

## Phase 1
| Item | What changed | Files |
|---|---|---|
| 1.1 positioning | "high-stakes" removed from free surfaces: "For the big calls, and the smaller ones you keep circling." No speed promise. Paid/Mirror/methodology copy untouched. | `app/layout.tsx`, `app/page.tsx`, `app/HomeClient.tsx`, `ChatIntake.tsx` |
| 1.2 starters | Chat hero shows Career, Business, Money, Personal, Relationships, **Small calls**. Classic HomeClient strip unchanged. | `components/DecisionStarters.tsx` |
| 1.3 endings | One continuity block on the "I'm done" screen, the Council page (once locked), and the record page. Replaces the faint reload link and the "New Decision" ghost buttons. Record page buttons: "Another decision" (header) and "Bring me another decision →" (footer). | `components/NextDecisionPrompt.tsx` (new), `DecisionCheckpoint.tsx`, `SessionView.tsx`, `app/record/[id]/page.tsx`, `app/NaturalIntakeClient.tsx` |
| 1.4 elicit + park | "Anything else you're going back and forth on?" → **Bring this one now** (prefills the chat) or **Park it for later** (Watchlist). Anonymous parks wait in localStorage and are filed in `/auth/callback` after sign-in. Watchlist is mounted in the chat hero for signed-in people so parked items have a visible home. | `NextDecisionPrompt.tsx`, `lib/pending-park.ts`, `lib/prefill.ts` (new), `ChatIntake.tsx`, `app/auth/callback/page.tsx` |
| 1.5 tally | "Quorum has guessed right 1 of 2 so far." Aggregate-only endpoint over `prediction_matched_final`; hidden until one outcome exists. | `components/PredictionTally.tsx`, `app/api/prediction-tally/route.ts` (new) |
| 1.6 soft connect | `ConnectCard` (skippable, collapsed by default, hides if linked, "Not now" = 72h). Copy tied to the parked item or the review date. Replaces `EmailCaptureCard` on the record page (that file is untouched, now unused). | `components/ConnectCard.tsx` (new), `app/record/[id]/page.tsx` |
| 1.7 review date | Chips: In 3 days / 1 week / 1 month. Default 7 days when `stakes_reversibility` says reversible/low, else 30 (unchanged). A late-arriving default never overrides a choice the person already made. Still required. | `components/PredictionReveal.tsx`, `SessionView.tsx` |
| copy lock | Phase 1 copy recorded per the doc's own convention. | `docs/COPY_AND_STRUCTURE_LOCK_v1.md` |

## One primary button per screen (what you will see)
- "I'm done" screen: **Convene the Council** is the only primary. The continuity button and the connect card are outline-style.
- Council page: **Save to Record** (tray) is the only primary. The continuity button is outline-style.
- Record page: the brief CTA stays the primary. The continuity field only shows a button once something is typed, outline-style. Footer button is ghost.
- `ConnectCard` never renders a primary button (Google = neutral, "Email me a link" = ghost).
- `NextDecisionPrompt` defaults to `emphasis="secondary"`; pass `"primary"` only on a screen with no other primary action.

## Events emitted (to `events`)
`landing_view`, `decision_started`, `decision_checkpointed`, `decision_completed` (props.path = done | council), `another_decision_clicked`, `park_started`, `park_saved`, `tally_seen`, `auth_prompt_seen`, `auth_started`, `magic_link_requested`, `auth_skipped`, `auth_completed`, `review_date_chosen`.
`decision_index` on each row = decisions already in this browser's local history; use the SQL views for true D1…D5 numbers.

## Verified vs not
- Verified: `tsc` shows no new errors (the only errors are pre-existing TS2802 target-config noise in files like `lib/rate-limit.ts`); all 95 existing tests pass; `next build` succeeds (its one warning, supabase-js in the Edge middleware, is pre-existing).
- NOT verified: runtime behaviour against a real Supabase project, mobile visuals, the magic-link round trip, Watchlist writes. Please run the checklist below on staging.

## Staging checklist
1. Signed in → run a chat → confirm `sessions.user_id` and `chat_intakes.user_id` are set.
2. Anonymous → "I'm done" → confirm the id is in `quorum_session_ids` (needs cookie consent) and the home count/label update after "Bring me another decision".
3. Anonymous → type text → Park it → connect card opens → magic link → after callback the item appears on the Watchlist.
4. Sign in from `/record/<id>` via Google and via magic link (ideally opened in another browser) → you land back on that record.
5. Lock a decision → tally line appears; choose a review-date chip → `review_date_chosen` row appears.
6. Flag off (`NEXT_PUBLIC_WATCHLIST_ENABLED` unset) → no Park button, no Watchlist, nothing else breaks.

## Judgment calls you may want to flip
- "I'm done" ids are pushed only with cookie consent, while `SessionView`'s existing write ignores consent. Left as-is.
- Six starter chips may crowd small phones; drop Relationships first.
- 7-day default review date depends on `stakes_reversibility` being filled by the time the lock card mounts.

## Not in this zip (Phases 2–3)
D2 anonymous pattern callback, D2 earned-connect + cue + cadence, weekly brief, progress strip, variable one-liner, push prompt, D3 auth gate, home-screen prompt.
