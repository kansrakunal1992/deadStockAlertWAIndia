// components/DecisionStarters.tsx
// ── Strategy doc: "decision starters" ───────────────────────────────────────
// Solves "I don't know what decision to bring" — the blank-page problem that
// blocks activation before Quorum ever sees a real decision. Deliberately
// not called "templates" in the UI (per the brief: that reads as software).
// Clicking a starter fills the textarea as an editable draft, not a
// submission — the user still writes the real decision, this just removes
// the standing-in-front-of-a-blank-page moment.

'use client'

import { useState } from 'react'

interface Props {
  onPick: (text: string) => void
  // Natural Intake (v1): a tiny, three-chip version for the chat hero —
  // "not a big product tour," just Career / Business / Money. Defaults to
  // false so HomeClient's existing six-category strip is untouched.
  compact?: boolean
  // Overrides the "Or start with a decision" label — the chat hero doesn't
  // want that copy repeated under its own headline.
  label?: string
}

const CATEGORIES: { label: string; items: string[] }[] = [
  { label: 'Career',   items: [
    'Should I take this job offer?',
    'Should I leave my current job?',
    'Should I ask for a promotion?',
    'Should I switch to a completely different field?',
  ] },
  { label: 'Business', items: [
    'Should I hire this person?',
    'Should I start this company?',
    'Should I raise money right now?',
    'Should I fire this person?',
    'Should I bring on a co-founder?',
  ] },
  { label: 'Money',    items: [
    'Should I make this investment?',
    'Should I buy this house?',
    'Should I pay off debt or invest instead?',
    'Should I take on this financial risk?',
  ] },
  { label: 'Personal', items: [
    'Should I move to a new city?',
    'Should I go back to school?',
    'Should I make this major lifestyle change?',
    'Should I take a career break?',
  ] },
  { label: 'Relationships', items: [
    'Should I have this difficult conversation?',
    'Should I end this relationship?',
    'Should I set this boundary?',
  ] },
  { label: 'Everyday', items: [
    'Should I buy this?',
    'Should I commit to this?',
    'Should I say yes to this commitment?',
  ] },
]

// Phase 1 (retention work): decision supply is the retention limit -- people
// assume Quorum is only for life-changing decisions, so they have nothing to
// bring on a second visit. This chip is the explicit "smaller calls are
// welcome" signal. Only the compact (chat hero) strip shows it; the classic
// HomeClient six-category strip above is unchanged. Items are phrased so the
// normal chat -> checkpoint -> Council path still fits them (no promise of a
// shortcut).
const SMALL_CALLS: { label: string; items: string[] } = {
  label: 'Small calls',
  items: [
    'Should I reply to this today?',
    'Which of these two should I do first?',
    'Should I keep this or return it?',
    'Should I say yes to this invite?',
    'Should I raise this with them or let it go?',
  ],
}

export default function DecisionStarters({ onPick, compact = false, label = 'Or start with a decision' }: Props) {
  const [open, setOpen] = useState<string | null>(null)
  // Compact mode (the chat hero) used to show only Career / Business / Money /
  // Personal -- which hid Relationships and Everyday and told every visitor
  // this was for big decisions only. Phase 1: Relationships comes back and
  // "Small calls" replaces Everyday. Six chips wrap to two rows on a phone; if
  // that feels crowded, drop Relationships first.
  const categories = compact ? [...CATEGORIES.slice(0, 5), SMALL_CALLS] : CATEGORIES

  return (
    <div style={{ margin: compact ? '0' : '10px 0 16px' }}>
      {label && (
        <p style={{
          fontFamily: 'var(--font-mono)', fontSize: 10.5, letterSpacing: '0.08em',
          textTransform: 'uppercase', color: 'var(--text-4)', margin: '0 0 8px',
          textAlign: compact ? 'center' : 'left',
        }}>
          {label}
        </p>
      )}
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: compact ? 'center' : 'flex-start' }}>
        {categories.map(cat => (
          <div key={cat.label} style={{ position: 'relative' }}>
            <button
              type="button"
              onClick={() => setOpen(o => (o === cat.label ? null : cat.label))}
              style={{
                padding: '9px 14px', fontSize: 13, borderRadius: 999,
                border: `1px solid ${open === cat.label ? 'var(--gold)' : 'var(--border-dim)'}`,
                background: open === cat.label ? 'rgba(201,168,76,0.1)' : 'var(--bg-card)',
                color: open === cat.label ? 'var(--gold)' : 'var(--text-3)',
                cursor: 'pointer',
              }}
            >
              {cat.label}
            </button>
            {open === cat.label && (
              <div style={{
                position: 'absolute', top: '110%', left: 0, zIndex: 20,
                width: 'min(280px, calc(100vw - 48px))',
                border: '1px solid var(--border-mid)', borderRadius: 10,
                background: 'var(--bg-card)', boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                padding: 6,
              }}>
                {cat.items.map(item => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => { onPick(item); setOpen(null) }}
                    style={{
                      display: 'block', width: '100%', textAlign: 'left',
                      padding: '10px 10px', fontSize: 13, color: 'var(--text-2)',
                      background: 'transparent', border: 'none', borderRadius: 6,
                      cursor: 'pointer',
                    }}
                  >
                    {item}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
