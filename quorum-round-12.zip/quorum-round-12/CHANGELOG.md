# Round 12 — synthesis progressive disclosure + Council card visual pass

Drop-in files (paths relative to project root). Built on the quorum_clean.zip
uploaded this session; only 5 modified + 1 new file.

## #3 Synthesis: fewer things visible by default — components/SynthesisCard.tsx
- Visible by default: Council verdict, Worth confirming, the trade-offs paragraph.
- Behind a new "Show full breakdown" toggle (closed by default): Conditional on,
  If different, What to do next, Before you act. Same JSX/labels/styling as
  before; the Conditional on / If different pair gets its own gold left rule
  since it no longer sits inside the verdict box.
- Toggle sub-line lists only sections that exist for that synthesis
  ("next steps, conditions, what would change this"); no toggle at all when none exist.
- Unchanged: tag generation/parsing, record page, PDF, share message, TTS
  (reads synthesis prose only), focus mode (still shows everything).
- "Disagree with something?" line moved to after the toggle (stays next to the
  challenge box); copy "any advisor above" -> "below" (cards render below).
- Open state is kept across pushback re-syntheses.

## #5 Council card visuals
- lib/persona-highlight.ts (new): splitHighlight() — pure client-side split of
  the existing <position> sentence. Verdict-first lines emphasise the verdict
  clause; "X isn't the problem — it's Y" lines emphasise Y. Returns null (line
  renders as before) when no clean break. before+emphasis+after === original.
  No new tag, no prompt change.
- components/PersonaPanel.tsx: emphasised phrase = bold + accent marker
  (.persona-mark), rest of the line steps down a weight/tone. Collapsed real-cost
  line: upright, darker, with a "Real cost" run-in label (was faint italic, unlabeled).
  Card-header icon now PersonaIcon (was a separate generic icon set that
  disagreed with the glance strip); local ICONS map removed.
- app/globals.css: .persona-mark (marker strength 26% light / 60% dark — the
  advisors' accents vanish on the dark card at light-theme strength);
  .council-stagger entrance rules; reduced-motion respected.
- components/SessionView.tsx + CouncilGlanceStrip.tsx: chips and card summaries
  arrive ~110ms apart, ONCE, the first time the Council section scrolls into
  view (IntersectionObserver). The old cosmetic stagger could never be seen:
  the section is display:none until synthesis completes. States
  pending -> playing -> seen; never replays on pushback re-synthesis. Flag off:
  no data attribute rendered, CSS never matches.

## Verification
- tsc --noEmit on the 4 touched components against stubbed React types: zero
  new errors vs. the original upload (baseline noise identical).
- splitHighlight run over sample sentences incl. contrast, colon, semicolon,
  because-clauses, too-short, no-break: never alters text.
- Chromium render of the real CouncilGlanceStrip/PersonaIcon/LeanBadge + real
  globals.css at 390px, light and dark; stagger opacity sampled over time
  (all six settle by ~1.2s). Fonts were fallback (no network), so re-check
  weight contrast in Cormorant on a device.
- NOT visually rendered: the SynthesisCard breakdown toggle/expanded area.
- vitest not runnable here; no tags added, so persona-tag-wiring guardrail is unaffected.

## Notes
- Moving the action plan behind the toggle is a product call: to keep it always
  visible, render the "What to do next" block outside the {breakdownOpen && …}
  and drop 'next steps' from breakdownParts.
- Emphasis is heuristic: if a model writes a position with no clause break, it
  renders plain (as before).
