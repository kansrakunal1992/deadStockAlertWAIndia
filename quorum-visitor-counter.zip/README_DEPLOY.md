# Visitor Counter — Deploy Notes

Small "N people already here" social-proof pill, fixed bottom-left on every
page. Starts at **150** and climbs for real as unique browsers visit.

## What's in this zip

```
quorum-app/
  supabase/add_visitor_counter.sql   NEW  — migration (run this first)
  app/api/visitor-count/route.ts     NEW  — GET (read) / POST (increment)
  components/VisitorCounter.tsx      NEW  — the pill itself
  app/layout.tsx                     CHANGED — mounts VisitorCounter globally
  app/globals.css                    CHANGED — .visitor-counter styles
```

Copy these into the matching paths in your `quorum` repo, overwriting
`app/layout.tsx` and `app/globals.css`.

## Pre-deploy steps

1. **Run the migration once**, in the Supabase SQL Editor:
   `supabase/add_visitor_counter.sql`
   - Creates a single-row table seeded at `150`.
   - Adds `increment_visitor_counter()`, an atomic Postgres function so
     concurrent visitors can't race each other into a lost update.
   - RLS enabled, no public policies — service-role only, same convention as
     `decision_session_payments` / `ai_request_log`.
2. **No new env vars, no new Razorpay setup, no new dependencies.** The API
   route reuses the existing `createServiceClient()` from `lib/supabase.ts`.
3. Deploy as usual (Railway will pick up the new route + component on the
   next build).

## How it works

- On first-ever load in a browser, the pill fires `POST /api/visitor-count`,
  which atomically bumps the shared counter and returns the new total. A
  `localStorage` flag (`quorum_visitor_counted`) means that browser never
  increments it again — every later visit just does a read-only `GET`.
- If the API call fails for any reason (offline, DB hiccup, migration not
  yet run), the pill fails soft: either shows the seed value `150` or, on a
  network error, renders nothing at all — it never shows a wrong or stale
  number, and never breaks the page.

## Placement — why it won't conflict with anything

- **Bottom-left**, fixed. `.theme-toggle` already owns top-right; `UnlockNotice`
  already owns bottom-right — this is the one fixed corner nothing else uses.
- **z-index 500** — above ordinary page content/nav, but below *every* modal,
  drawer, and overlay already in the app (cookie consent, onboarding tour,
  session drawers, etc. are all z-index ≥ 9000), so those correctly render on
  top of it, never the other way round.
- **`pointer-events: none`** — it's purely informational and can never
  intercept a tap or click, even if it happens to sit near something else.
- **Auto-hides over the footer.** The footer (`<AppFooter />`) is in-flow, not
  fixed, so on short pages it can scroll up into the same bottom-left corner.
  The pill watches for that with an `IntersectionObserver` and fades to
  `opacity: 0` whenever the footer is in view, so it never visually overlaps
  a legal link — on any screen size, without hardcoding a footer height that
  would drift out of sync later.
- Verified with a full project `tsc --noEmit` (same 29 pre-existing,
  unrelated `downlevelIteration` errors — zero new ones) and the existing
  `vitest` suite (58/58 still passing).

## If you ever want to change the copy or starting number

- Pill text: `components/VisitorCounter.tsx`, the `{count.toLocaleString(...)}
  people already here` line.
- Starting number: change the `DEFAULT 150` in the migration **before**
  running it (it only applies on first insert — editing the file after
  deploy won't retroactively change an already-seeded row; update the row
  directly in Supabase instead if you need to change it later).
