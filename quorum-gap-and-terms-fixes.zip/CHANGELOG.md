# Quorum — Home Page Gap Fix + Terms Page Review

2 files touched. Builds on top of quorum-copy-fixes.zip (app/page.tsx
here includes both the earlier copy fixes AND the new item-2 fix —
this file fully replaces the one from that zip, don't apply both).

## 2. app/page.tsx — mobile gap before "Your judgment record"

Root cause found: the decision-entry form ("FRONT FACE" div) had no
`position` property set. So even while collapsed and invisible
(opacity: 0), it stayed in normal document flow and took up its full
height — roughly 500–700px of dead space — pushing everything below
it down. That's the empty gap you were seeing, worse on mobile where
it's a bigger share of the screen.

Fix, two parts:
1. Gave the front face the same (inverted) absolute/relative
   positioning logic the back (collapsed) face already uses, so it's
   properly removed from layout when hidden instead of just going
   invisible in place.
2. Added back a small intentional gap using `clamp(16px, 4vw, 56px)`
   on the wrapper — scales with viewport width, so it stays small on
   narrow phone screens (visible in the first screenful) and opens up
   into real breathing room on wider desktop screens. Same clamp()
   technique already used elsewhere in this file for the card's
   height.

Net effect: no more accidental dead space, but the "breathing room"
concept you liked on desktop is preserved intentionally instead of by
accident. Worth a quick look on both a phone and desktop after
deploy since I couldn't render it here.

## 5. app/terms/page.tsx — full review

Fixed the domain typo plus two more things a full read-through turned
up that weren't in the original ask but are real inaccuracies:

- **Domain:** `app.quorumvault.xyz` → `app.quorumvault.org` (every
  other file in the app already uses `.org`; Terms was the only
  holdout).
- **Section 2 (Your account):** Was written as if magic-link email is
  the only way to sign in. Google Sign-In is now offered as the
  primary option (with magic link as the alternative) — updated to
  describe both.
- **Section 13 (Contact):** Was pointing to `/settings/privacy`
  ("Privacy Center"), described as "accessible from the footer of any
  page." Neither part is true: the footer doesn't link to
  `/settings/privacy` (it links to `/privacy`, a different page), and
  that settings page is a data-rights/cookie control panel, not a
  contact form. Replaced with the real support inbox
  (`support@quorumvault.org`), which is already used elsewhere in the
  app (subscription cancellation flow).
- **Effective date / version:** Bumped to 14 August 2026 · Version 1.1
  since this changes substantive terms, not just a typo. Change this
  if you'd rather set your own effective date.

Everything else in Terms (subscriptions, liability cap, IP, governing
law, acceptable use) checked out against the current app and pricing
structure — no other stale references found.

## Not checked in this pass
Privacy Policy, Security page, and Cookie Policy are queued as their
own items (6 and 6b) — not touched here.

## Verification
Both files run clean through `tsc --noEmit` in isolation (JSX
preserve, esModuleInterop, skipLibCheck) — no syntax errors. Same
caveat as last time: no node_modules here, so this isn't a full
project-wide type-check, just a syntax/structure check on the edited
files.
