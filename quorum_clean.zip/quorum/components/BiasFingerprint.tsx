'use client'

// components/BiasFingerprint.tsx
// ── Mirror Module: Bias Fingerprint Section (Sprint 7b, updated Sprint 20 + Sprint BT) ────
//
// Sprint 20: passes authToken down to PatternTile so each tile can open
// a source-session drawer. signalType and sessionIds are now in FingerprintTile
// (populated by mirror-fingerprint.ts) and flow through automatically.
// Sprint BT: renders Personal Trigger Patterns section beneath the tile grid.

import { useState, useEffect } from 'react'
import { formatShortDate } from '@/lib/dates'
import PatternTile              from '@/components/PatternTile'
import Link                     from 'next/link'
import type { FingerprintData } from '@/lib/types'
import type { PersonalBiasTrigger, BiasTriggerEvidence } from '@/lib/bias-trigger-engine'
import { DIMENSION_EVERYDAY_PHRASE, CALIBRATION_ACTION_HINTS, FLAG_EVERYDAY_PHRASE, FLAG_ACTION_HINTS, CATEGORY_ACTION_HINTS, CATEGORY_VALUE_LABELS } from '@/lib/calibration-copy'
import PendingOutcomesCTA from '@/components/PendingOutcomesCTA'

// ── Personal Trigger Patterns (Sprint BT) ─────────────────────────────────────
function TriggerEvidenceRow({ evidence }: { evidence: BiasTriggerEvidence }) {
  return (
    <Link
      href={`/record/${evidence.session_id}`}
      style={{ display: 'block', textDecoration: 'none', padding: '8px 10px', marginTop: 5, background: 'var(--bg-inset)', border: '1px solid var(--border-dim)', borderRadius: 7 }}
    >
      <p style={{ fontSize: 12, color: 'var(--text-2)', margin: '0 0 4px', lineHeight: 1.4 }}>
        "{evidence.decision_text}{evidence.decision_text.length >= 140 ? '…' : ''}"
      </p>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <span style={{ fontSize: 9.5, color: 'var(--text-4)' }}>{formatShortDate(evidence.created_at)}</span>
        <span style={{ fontSize: 9.5, color: '#f87171', fontWeight: 600 }}>Worse than expected</span>
        <span style={{ fontSize: 9.5, color: 'var(--gold)', marginLeft: 'auto' }}>View →</span>
      </div>
    </Link>
  )
}

function TriggerCard({ trigger }: { trigger: PersonalBiasTrigger }) {
  // Phase 2b: trigger is a 3-way union (dimension | flag | category). Each
  // type needs its own opening clause — "When you have {noun phrase}," fits
  // dimension copy (a noun phrase) but NOT flag or category copy (both full
  // clauses, e.g. "there is real or perceived time pressure") — forcing them
  // through the same template produced broken grammar in the original
  // Phase 2a build ("When you have there is real or perceived time
  // pressure"). Fixed here by branching the whole opening clause per type.
  let whenClause: string
  let hint: string | undefined

  if (trigger.triggerType === 'dimension') {
    whenClause = `you're facing ${DIMENSION_EVERYDAY_PHRASE[trigger.triggerDim]}`
    hint       = CALIBRATION_ACTION_HINTS[trigger.triggerDim]?.overconfident
  } else if (trigger.triggerType === 'flag') {
    whenClause = FLAG_EVERYDAY_PHRASE[trigger.triggerFlag]
    hint       = FLAG_ACTION_HINTS[trigger.triggerFlag]
  } else {
    whenClause = CATEGORY_VALUE_LABELS[trigger.categoryField][trigger.categoryValue] ?? trigger.categoryValueLabel
    hint       = CATEGORY_ACTION_HINTS[trigger.categoryField]?.[trigger.categoryValue]
  }

  const highPct = Math.round(trigger.badRateHigh * 100)
  const lowPct  = Math.round(trigger.badRateLow * 100)
  const totalN  = trigger.sampleSize.high + trigger.sampleSize.low

  return (
    <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 10, padding: '14px 14px 12px', marginTop: 10 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}>
        <p style={{ fontSize: 13, color: 'var(--text-1)', margin: 0, fontWeight: 600, lineHeight: 1.4 }}>
          {trigger.biasLabel}
        </p>
        <span style={{ fontSize: 10, fontWeight: 700, color: '#f87171', whiteSpace: 'nowrap' }}>
          Danger zone ↑
        </span>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--text-4)', margin: '4px 0 0', lineHeight: 1.5 }}>
        When <strong style={{ color: 'var(--text-2)', fontWeight: 600 }}>{whenClause}</strong>,
        this pattern has preceded a worse-than-expected outcome{' '}
        <strong style={{ color: '#f87171' }}>{highPct}% of the time</strong> — vs. {lowPct}% otherwise.
        Across {totalN} decisions where this pattern was active and you later logged how it went.
      </p>

      {hint && (
        <div style={{ marginTop: 10, padding: '8px 10px', background: 'var(--bg-inset)', borderLeft: '2px solid var(--gold)', borderRadius: '0 5px 5px 0' }}>
          <p style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--gold)', textTransform: 'uppercase', letterSpacing: '0.06em', margin: '0 0 3px' }}>Try this next time</p>
          <p style={{ fontSize: 11.5, color: 'var(--text-2)', margin: 0, lineHeight: 1.45 }}>{hint}</p>
        </div>
      )}

      <p style={{ fontSize: 9.5, fontWeight: 700, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '12px 0 0' }}>
        When it went wrong — {trigger.evidence.length} example{trigger.evidence.length !== 1 ? 's' : ''}
      </p>
      {trigger.evidence.map(e => <TriggerEvidenceRow key={e.session_id} evidence={e} />)}
    </div>
  )
}

function PersonalTriggerSection({
  triggers,
  confirmedBiasLabels,
  authToken,
}: {
  triggers:             PersonalBiasTrigger[]
  confirmedBiasLabels:  string[]
  authToken:            string
}) {
  if (triggers.length > 0) {
    return (
      <div style={{ marginTop: 20 }}>
        <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-4)', letterSpacing: '0.1em', textTransform: 'uppercase', margin: '0 0 2px' }}>
          When these patterns become costly
        </p>
        <p style={{ fontSize: 11.5, color: 'var(--text-4)', margin: '0 0 4px', lineHeight: 1.5 }}>
          Based on your own decisions that didn't land as expected.
        </p>
        {triggers.map(t => {
          const subKey = t.triggerType === 'dimension' ? t.triggerDim
            : t.triggerType === 'flag' ? t.triggerFlag
            : `${t.categoryField}:${t.categoryValue}`
          return <TriggerCard key={t.biasKey + t.triggerType + subKey} trigger={t} />
        })}
      </div>
    )
  }

  // No triggers discovered yet. Only worth a CTA if there's actually
  // something to eventually correlate — i.e. at least one confirmed bias.
  // With zero confirmed biases, this section staying silent is correct;
  // there's nothing personal to point at yet.
  if (confirmedBiasLabels.length === 0) return null

  const namedBiases = confirmedBiasLabels.slice(0, 2).join(' and ')
  return (
    <div style={{ marginTop: 20, background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 10, padding: '14px 16px' }}>
      <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-4)', letterSpacing: '0.1em', textTransform: 'uppercase', margin: '0 0 6px' }}>
        When these patterns become costly
      </p>
      <p style={{ fontSize: 12.5, color: 'var(--text-2)', margin: '0 0 10px', lineHeight: 1.55 }}>
        We can already see {namedBiases} showing up in how you decide. What we can't tell yet is
        when it actually costs you — that takes outcomes logged on the decisions where it fired.
      </p>
      <PendingOutcomesCTA authToken={authToken} introText="Start with one of these:" />
    </div>
  )
}

// ── Main component ─────────────────────────────────────────────────────────────

function FingerprintSkeleton() {
  const bar = (w: string, h = 8) => (
    <div style={{ height: h, width: w, background: 'var(--border-dim)', borderRadius: 4, animation: 'fp-pulse 1.8s ease-in-out infinite' }} />
  )
  return (
    <>
      <style>{`@keyframes fp-pulse { 0%,100%{opacity:0.3} 50%{opacity:0.7} }`}</style>
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 12, padding: '20px 22px', marginBottom: 20, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {bar('95%', 9)}{bar('88%', 9)}{bar('72%', 9)}{bar('60%', 9)}
      </div>
      <div className="mirror-bias-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 10, padding: '15px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {bar('50%', 7)}{bar('90%', 7)}{bar('75%', 7)}{bar('55%', 7)}
          </div>
        ))}
      </div>
    </>
  )
}

// ── Narrative block ───────────────────────────────────────────────────────────

function NarrativeBlock({ narrative, sessionCount }: { narrative: string | null; sessionCount: number }) {
  if (!narrative) {
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 12, padding: '18px 20px', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold-dim)', border: '1.5px solid var(--gold)', animation: 'blink 2s ease-in-out infinite' }} />
          <span style={{ fontSize: 11.5, color: 'var(--text-3)', fontWeight: 600 }}>Profile forming</span>
        </div>
        <p style={{ fontSize: 12.5, color: 'var(--text-4)', margin: '0 0 12px', lineHeight: 1.65 }}>
          Your personal decision narrative compiles once three or more patterns are confirmed across your sessions.
          {sessionCount > 0 && <> You have {sessionCount} session{sessionCount !== 1 ? 's' : ''} logged so far.</>}
        </p>
        <a href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12.5, color: 'var(--gold)', fontWeight: 600, textDecoration: 'none' }}
          onMouseEnter={e => ((e.currentTarget as HTMLAnchorElement).style.opacity = '0.75')}
          onMouseLeave={e => ((e.currentTarget as HTMLAnchorElement).style.opacity = '1')}>
          Run your next decision →
        </a>
      </div>
    )
  }

  return (
    <div style={{ background: 'linear-gradient(160deg, rgba(201,168,76,0.045) 0%, var(--bg-card) 55%)', border: '1px solid rgba(201,168,76,0.18)', borderRadius: 12, padding: '20px 22px', marginBottom: 20, position: 'relative', overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,0.45), inset 0 1px 0 rgba(201,168,76,0.08)', backdropFilter: 'blur(4px)' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: 2, background: 'linear-gradient(90deg, var(--gold) 0%, var(--gold-dim) 40%, transparent 80%)' }} />
      <p style={{ fontSize: 14, color: 'var(--text-2)', lineHeight: 1.75, margin: 0, fontStyle: 'italic' }}>
        &ldquo;{narrative}&rdquo;
      </p>
    </div>
  )
}

// ── Section expand button ─────────────────────────────────────────────────────

function SectionToggle({ count, expanded, label, onToggle }: { count: number; expanded: boolean; label: string; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      style={{
        display: 'flex', alignItems: 'center', gap: 7, marginTop: 10, marginBottom: expanded ? 10 : 0,
        padding: '7px 12px', background: 'var(--bg-card-alt)', border: '1px solid var(--border-dim)',
        borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit', fontSize: 12,
        color: 'var(--text-4)', letterSpacing: '0.03em', transition: 'color 0.15s',
      }}
      onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-2)' }}
      onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-4)' }}
    >
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
        style={{ transform: expanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
        <polyline points="6 9 12 15 18 9"/>
      </svg>
      {expanded ? `Hide ${label}` : `Show ${count} more ${label}`}
    </button>
  )
}

// ── Main component ────────────────────────────────────────────────────────────

interface Props { authToken: string }

const CONFIRMED_INITIAL = 3

export default function BiasFingerprint({ authToken }: Props) {
  const [data,              setData]              = useState<FingerprintData | null>(null)
  const [loading,           setLoading]           = useState(true)
  const [error,             setError]             = useState(false)
  const [confirmedExpanded, setConfirmedExpanded] = useState(false)
  const [formingExpanded,   setFormingExpanded]   = useState(false)

  useEffect(() => {
    let cancelled = false
    const fetchFingerprint = async () => {
      try {
        const res = await fetch('/api/mirror/fingerprint', { headers: { Authorization: `Bearer ${authToken}` } })
        if (!res.ok) { setError(true); return }
        const json = await res.json() as FingerprintData
        if (!cancelled) setData(json)
      } catch {
        if (!cancelled) setError(true)
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    fetchFingerprint()
    return () => { cancelled = true }
  }, [authToken])

  if (loading) return <FingerprintSkeleton />

  if (error) {
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 12, padding: '18px 20px' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-4)', margin: 0, lineHeight: 1.6 }}>
          Pattern analysis temporarily unavailable. Your data is intact — try refreshing in a moment.
        </p>
      </div>
    )
  }

  const totalTiles = (data?.confirmedTiles.length ?? 0) + (data?.formingTiles.length ?? 0)

  if (!data || totalTiles === 0) {
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 12, padding: '20px 22px' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-4)', margin: '0 0 12px', lineHeight: 1.65 }}>
          No patterns detected yet. Answer the follow-up questions in your next session —
          those answers are what Mirror uses to build your fingerprint.
        </p>
        <a href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12.5, color: 'var(--gold)', fontWeight: 600, textDecoration: 'none' }}
          onMouseEnter={e => ((e.currentTarget as HTMLAnchorElement).style.opacity = '0.75')}
          onMouseLeave={e => ((e.currentTarget as HTMLAnchorElement).style.opacity = '1')}>
          Run a decision →
        </a>
      </div>
    )
  }

  const confirmedVisible = confirmedExpanded
    ? data.confirmedTiles
    : data.confirmedTiles.slice(0, CONFIRMED_INITIAL)
  const confirmedHidden = Math.max(0, data.confirmedTiles.length - CONFIRMED_INITIAL)

  return (
    <div>
      <NarrativeBlock narrative={data.narrative} sessionCount={data.sessionCount} />

      {/* Confirmed tiles — authToken passed for source drawer */}
      {data.confirmedTiles.length > 0 && (
        <>
          <div className="mirror-bias-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
            {confirmedVisible.map(tile => (
              <PatternTile key={tile.biasKey} tile={tile} authToken={authToken} />
            ))}
          </div>

          {confirmedHidden > 0 && (
            <SectionToggle
              count={confirmedHidden}
              expanded={confirmedExpanded}
              label={`confirmed pattern${confirmedHidden !== 1 ? 's' : ''}`}
              onToggle={() => setConfirmedExpanded(e => !e)}
            />
          )}
        </>
      )}

      {/* Forming tiles */}
      {data.formingTiles.length > 0 && (
        <div style={{ marginTop: confirmedHidden > 0 && !confirmedExpanded ? 14 : 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, flexWrap: 'wrap', gap: 8 }}>
            <p style={{ fontSize: 11, color: 'var(--text-4)', margin: 0, fontStyle: 'italic' }}>
              {data.formingTiles.length} pattern{data.formingTiles.length !== 1 ? 's' : ''} forming — building confidence
            </p>
            <button
              onClick={() => setFormingExpanded(e => !e)}
              style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 10px', background: 'transparent', border: '1px solid var(--border-dim)', borderRadius: 6, cursor: 'pointer', fontFamily: 'inherit', fontSize: 11, color: 'var(--text-4)', transition: 'color 0.15s' }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--gold)' }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-4)' }}
            >
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                style={{ transform: formingExpanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
                <polyline points="6 9 12 15 18 9"/>
              </svg>
              {formingExpanded ? 'Hide' : 'Peek'}
            </button>
          </div>

          {formingExpanded && (
            <div className="mirror-bias-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
              {data.formingTiles.map(tile => (
                <PatternTile key={tile.biasKey} tile={tile} authToken={authToken} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Personal Trigger Patterns (Sprint BT) */}
      <PersonalTriggerSection
        triggers={data.personalBiasTriggers ?? []}
        confirmedBiasLabels={data.confirmedTiles.map(t => t.biasLabel)}
        authToken={authToken}
      />

      {/* Footer */}
      <p style={{ fontSize: 10, color: 'var(--text-4)', margin: '14px 0 0', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
        Analysis from {data.sessionCount} session{data.sessionCount !== 1 ? 's' : ''}
        {' · '}
        {formatShortDate(data.generatedAt)}
      </p>
    </div>
  )
}
