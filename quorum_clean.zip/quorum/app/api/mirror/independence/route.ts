// app/api/mirror/independence/route.ts
// ── Mirror Module: Independence Score Route (Sprint 7c) ───────────────────────
//
// GET  /api/mirror/independence
//   Auth-gated (Bearer token). Returns latest stored score for this user.
//   If no score exists yet, returns { score: null } — not an error.
//   Also requires mirror_access (score is a paid feature).
//
// POST /api/mirror/independence
//   Internal-only (no Bearer token check — called server-to-server from
//   /api/examiner POST as a fire-and-forget). Calculates score for the
//   user who owns the sessionId, stores in independence_score_log.
//   Idempotent per session: upserts on session_id.
//
// Storage: independence_score_log table (created in sprint7a_mirror_schema.sql)
//   One row per session calculated. Always appends; never overwrites history.
// ─────────────────────────────────────────────────────────────────────────────

import { NextResponse }         from 'next/server'
import { createServiceClient }   from '@/lib/supabase'
import { createClient as createSupabaseClient } from '@supabase/supabase-js'
import { calculateIndependenceScore, getScoreBand } from '@/lib/independence-score'
import { getMirrorAccessState } from '@/lib/mirror-access'
import { decrypt } from '@/lib/encryption'

// ── Auth helper (shared with fingerprint route) ───────────────────────────────

async function resolveUserId(req: Request): Promise<string | null> {
  const authHeader = req.headers.get('authorization')
  if (!authHeader?.startsWith('Bearer ')) return null
  const token = authHeader.slice(7)
  try {
    const anonClient = createSupabaseClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    )
    const { data: { user } } = await anonClient.auth.getUser(token)
    return user?.id ?? null
  } catch {
    return null
  }
}

// ── GET — return latest score for authenticated user ──────────────────────────

export async function GET(req: Request) {
  const userId = await resolveUserId(req)
  if (!userId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const supabase = createServiceClient()

  // Require mirror access — Independence Score is part of the paid tier
  const accessState = await getMirrorAccessState(userId, supabase)
  if (accessState !== 'unlocked') {
    return NextResponse.json({ error: 'Mirror access required' }, { status: 403 })
  }

  // Fetch the most recent score entry for this user
  const { data: latestEntry } = await supabase
    .from('independence_score_log')
    .select('score, delta, calculated_at, signals, session_id')
    .eq('user_id', userId)
    .order('calculated_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (!latestEntry) {
    // No sessions scored yet — not an error
    return NextResponse.json({
      score:         null,
      delta:         null,
      band:          null,
      interpretation: null,
      sessionCount:  0,
      calculatedAt:  null,
    })
  }

  const band = getScoreBand(latestEntry.score)

  // Session count from signals jsonb (stored there for display)
  const sessionCount = (latestEntry.signals as Record<string, unknown> | null)?.scoredCount as number
    ?? (latestEntry.signals as Record<string, unknown> | null)?.sessionCount as number
    ?? 0

  // ── Fetch examiner quote from the most recent scored session ───────────────
  // Pick the most substantive answer (longest response_text) from that session.
  // Capped at 180 chars — used as a contextual anchor in the score display.
  let examinerQuote: string | null = null
  if (latestEntry.session_id) {
    const { data: examinerRows } = await supabase
      .from('examiner_responses')
      .select('response_text, question_order')
      .eq('session_id', latestEntry.session_id)
      .not('response_text', 'is', null)
      .order('question_order', { ascending: true })
      .limit(6)

    if (examinerRows && examinerRows.length > 0) {
      const longest = examinerRows.reduce((best, row) =>
        (row.response_text?.trim().length ?? 0) > (best.response_text?.trim().length ?? 0)
          ? row : best
      )
      const raw = (decrypt(longest.response_text) ?? '').trim()
      examinerQuote = raw.length > 180 ? raw.slice(0, 177) + '…' : raw || null
    }
  }

  return NextResponse.json({
    score:          latestEntry.score,
    delta:          latestEntry.delta,
    band:           band.label,
    interpretation: band.interpretation,
    sessionCount,
    calculatedAt:   latestEntry.calculated_at,
    examinerQuote,
  })
}

// ── POST — calculate + store score (called internally from examiner route) ────

export async function POST(req: Request) {
  let sessionId: string | undefined

  try {
    const body = await req.json()
    sessionId = body.sessionId
  } catch {
    return NextResponse.json({ error: 'Invalid body' }, { status: 400 })
  }

  if (!sessionId) {
    return NextResponse.json({ error: 'sessionId required' }, { status: 400 })
  }

  const supabase = createServiceClient()

  // ── Resolve user_id from session ───────────────────────────────────────────
  const { data: session } = await supabase
    .from('sessions')
    .select('user_id, user_email')
    .eq('id', sessionId)
    .maybeSingle()

  if (!session?.user_id) {
    // Can't score without a user_id — independence score is longitudinal,
    // requires auth to accumulate across sessions
    return NextResponse.json({ ok: false, reason: 'no_user_id' })
  }

  const userId    = session.user_id
  const userEmail = session.user_email

  // ── Calculate score ────────────────────────────────────────────────────────
  const result = await calculateIndependenceScore(userId)

  if (!result) {
    return NextResponse.json({ ok: false, reason: 'no_sessions' })
  }

  // ── Store in independence_score_log ────────────────────────────────────────
  // One row per session. If this session was already scored (re-trigger),
  // update it rather than inserting a duplicate.
  const { error } = await supabase
    .from('independence_score_log')
    .upsert(
      {
        user_id:       userId,
        user_email:    userEmail,
        session_id:    sessionId,
        score:         result.score,
        delta:         result.delta,
        calculated_at: result.calculatedAt,
        signals: {
          sessionCount:  result.sessionCount,
          scoredCount:   result.scoredCount,
          sessionScores: result.sessionScores,
          band:          result.band.label,
        },
      },
      { onConflict: 'session_id' },
    )

  if (error) {
    // 42P10 = missing unique constraint — fall back to plain insert
    // (idempotency lost but data still written; fix by running sprint7c_independence_constraint.sql)
    if (error.code === '42P10') {
      console.warn('[independence] Missing unique constraint on session_id — falling back to insert. Run sprint7c_independence_constraint.sql to fix.')
      const { error: insertError } = await supabase
        .from('independence_score_log')
        .insert({
          user_id:       userId,
          user_email:    userEmail,
          session_id:    sessionId,
          score:         result.score,
          delta:         result.delta,
          calculated_at: result.calculatedAt,
          signals: {
            sessionCount:  result.sessionCount,
            sessionScores: result.sessionScores,
            band:          result.band.label,
          },
        })
      if (insertError) {
        console.error('[independence] Insert fallback also failed:', insertError)
        return NextResponse.json({ ok: false, error: 'DB error' }, { status: 500 })
      }
    } else {
      console.error('[independence] Supabase upsert error:', error)
      return NextResponse.json({ ok: false, error: 'DB error' }, { status: 500 })
    }
  }

  return NextResponse.json({
    ok:    true,
    score: result.score,
    delta: result.delta,
    band:  result.band.label,
  })
}
