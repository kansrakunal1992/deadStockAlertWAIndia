// app/api/session/[id]/observation/route.ts
// O3: Surfaces the Decision Brief's "Decision-Maker Observation" line automatically
// below the synthesis card for Mirror subscribers, without requiring them to first
// click "Generate Decision Brief". Cached on the session row after first generation
// so repeat views (and repeat page loads) don't re-bill the LLM call.
//
// Gated on Mirror access being 'unlocked' — this is a Mirror-only surface, not a
// teaser. Locked/teaser-tier users get { observation: null } and the client renders
// nothing (no upsell nudge here; SynthesisCard already carries the Mirror nudge row).

import { NextResponse }         from 'next/server'
import { createServiceClient }  from '@/lib/supabase'
import { decrypt }              from '@/lib/encryption'
import { getMirrorAccessState } from '@/lib/mirror-access'
import { createCompletion }     from '@/lib/ai-client'
import { DECISION_OBSERVATION_PROMPT } from '@/lib/personas'

interface Params { params: Promise<{ id: string }> }

const ADVISOR_KEYS = [
  'contrarian', 'risk_architect', 'pattern_analyst',
  'stakeholder_mirror', 'elder', 'competitor',
] as const

function stripHeaderTags(raw: string): string {
  return raw
    .replace(/<lens>[\s\S]*?<\/lens>/g, '')
    .replace(/<position>[\s\S]*?<\/position>/g, '')
    .replace(/<realcost>[\s\S]*?<\/realcost>/g, '')
    .replace(/<lean>[\s\S]*?<\/lean>/g, '')
    // Bug fix: <structural> was never stripped here — this feeds into an LLM
    // prompt (not direct display), but a raw citation tag in the input is
    // still noise the observation model has to parse around for no reason.
    .replace(/<structural>[\s\S]*?<\/structural>/g, '')
    .replace(/<(?:lens|position|realcost|lean|structural)>[\s\S]*$/, '') // guard: open tag without close
    .replace(/<\/?(?:proceed|wait|mixed)>\s*/gi, '')          // guard: stray malformed lean-value tag (see PersonaPanel.tsx)
    // Third bug fix (GPT-5-mini, Aug 2026) — see PersonaPanel.tsx's extractHeaderTags
    // for the full explanation. Two leaked-lean shapes gpt-5-mini produces that the
    // guard above doesn't catch: a bare enum word glued to the next capitalized
    // sentence ("mixedThis is..."), and a truncated open tag ("<mixed</lean>").
    .replace(/^(?:proceed|wait|mixed)\s*(?=[A-Z])/, '')
    .replace(/^<(?:proceed|wait|mixed)<\/lean>\s*/i, '')
    // Shape 3 (seen leaking specifically in pushback replies, Aug 2026): bare value,
    // no leading "<", but WITH the closing tag attached — e.g. "mixed</lean>".
    .replace(/^(?:proceed|wait|mixed)<\/lean>\s*/i, '')
    // Sprint 2 follow-on: content-preserving — this wraps substantive prose
    // the observation model should actually read, not a machine value.
    .replace(/<\/?assumption>/g, '')
    // New machine-only tag (mind-change tracking) — full removal, same as <lean>.
    // Tolerant close: model sometimes closes with </pushback> instead of the
    // full tag name (same drift as verdict_lean) — leaked tags are noise to the model.
    .replace(/<pushback_classification>[\s\S]*?<\/(?:pushback_classification|pushback)>/g, '')
    // Root-cause fix: same ordering bug as the other 3 sink files — this
    // guard ran before the proper strip above, so any validly-closed tag was
    // treated as unclosed and everything after it (feeding into the Mirror
    // observation prompt) was deleted.
    .replace(/<pushback_classification>[\s\S]*$/, '') // guard: open tag without close
    .replace(/^\s+/, '')
    .trim()
}

function stripSynthesisTags(raw: string): string {
  return raw
    .replace(/<verdict>[\s\S]*?<\/verdict>\n*/g, '')
    .replace(/<verdict>[\s\S]*/g, '')
    // P2 fix: this file has its own independent tag-stripping copy — it never
    // learned about the two tags added for forced-verdict-with-conditions.
    // This feeds into an LLM prompt (not direct display), but raw tags here
    // could still confuse the model or get echoed into its output, which IS
    // shown to Mirror subscribers.
    .replace(/<verdict_lean>[\s\S]*?<\/verdict(?:_lean)?>\n*/g, '')
    .replace(/<conditions>[\s\S]*?<\/conditions>\n*/g, '')
    // Counterfactual Analysis (new tag) — same full-removal treatment as
    // conditions above; this only feeds an LLM prompt, not direct display.
    .replace(/<counterfactual>[\s\S]*?<\/counterfactual>\n*/g, '')
    // Tag-wiring guardrail fix: same drift as verdict_lean/conditions above —
    // this file's independent copy never learned about the two newest
    // synthesis tags either. Full removal, matching SynthesisCard.tsx.
    .replace(/<action_plan>[\s\S]*?<\/action_plan>\n*/g, '')
    .replace(/<confidence_to_act>[\s\S]*?<\/confidence_to_act>\n*/g, '')
    // Guardrail follow-up: none of the 6 tags above had a fallback for a
    // truncated/malformed run (only <verdict> did, at line 51). A truncated
    // synthesis call — see lib/ai-client.ts createStream doc comment — most
    // often cuts off during action_plan/confidence_to_act since they're
    // written last, leaving an open tag with no close that every regex above
    // silently fails to match, leaking raw markup into the LLM prompt below.
    .replace(/<(?:verdict_lean|conditions|counterfactual|action_plan|confidence_to_act|key_question|tension)>[\s\S]*$/, '') // guard: open tag without close
    // Sprint 1 follow-on: same reasoning as verdict_lean/conditions above.
    .replace(/<\/?key_question>/g, '')
    .replace(/<\/?tension>/g, '')
    .replace(/^\s+/, '')
    .trim()
}

export async function POST(_req: Request, { params }: Params) {
  try {
    const { id: sessionId } = await params
    if (!sessionId) return NextResponse.json({ observation: null })

    const supabase = createServiceClient()

    const { data: session } = await supabase
      .from('sessions')
      .select('user_id, decision_text, decision_observation')
      .eq('id', sessionId)
      .single()

    if (!session) return NextResponse.json({ observation: null })

    // Cached — return immediately, no regeneration
    if (session.decision_observation) {
      return NextResponse.json({ observation: session.decision_observation })
    }

    // Mirror subscribers only — this is not a teaser surface
    if (!session.user_id) return NextResponse.json({ observation: null })
    const mirrorState = await getMirrorAccessState(session.user_id, supabase)
    if (mirrorState !== 'unlocked') return NextResponse.json({ observation: null })

    const { data: messages } = await supabase
      .from('messages')
      .select('persona, content, created_at')
      .eq('session_id', sessionId)
      .eq('role', 'assistant')
      .in('persona', [...ADVISOR_KEYS, 'synthesis'])
      .order('created_at', { ascending: true })

    if (!messages || messages.length === 0) return NextResponse.json({ observation: null })

    // Keep only the earliest assistant row per persona (the initial analysis,
    // not later pushback/examiner-update exchanges).
    const seen = new Set<string>()
    const advisorBlocks: string[] = []
    let synthesisText = ''
    for (const msg of messages) {
      if (seen.has(msg.persona)) continue
      seen.add(msg.persona)
      const decrypted = decrypt(msg.content)
      if (!decrypted) continue
      if (msg.persona === 'synthesis') {
        synthesisText = stripSynthesisTags(decrypted)
      } else {
        advisorBlocks.push(`[${msg.persona.toUpperCase().replace(/_/g, ' ')}]\n${stripHeaderTags(decrypted).slice(0, 500)}`)
      }
    }

    if (advisorBlocks.length === 0 || !synthesisText) {
      return NextResponse.json({ observation: null })
    }

    const decisionText = decrypt(session.decision_text) ?? ''

    const userPrompt = `DECISION:\n${decisionText}\n\nADVISOR RESPONSES:\n${advisorBlocks.join('\n\n')}\n\nSYNTHESIS:\n${synthesisText}`

    const raw = await createCompletion(userPrompt, 80, {
      provider:     'anthropic',
      systemPrompt: DECISION_OBSERVATION_PROMPT,
      temperature:  0.7,
    })

    const observation = raw.trim().replace(/^["']|["']$/g, '')
    if (!observation) return NextResponse.json({ observation: null })

    await supabase
      .from('sessions')
      .update({ decision_observation: observation })
      .eq('id', sessionId)

    return NextResponse.json({ observation })
  } catch (err) {
    console.error('[Observation] Route error:', err)
    return NextResponse.json({ observation: null })
  }
}
