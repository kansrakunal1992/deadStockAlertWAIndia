# Unified session experience — Tier 1 + 2 + 3, all flag-gated

Everything gated behind the same flag from before:
`NEXT_PUBLIC_UNIFIED_SESSION_ENABLED` (Railway env var, default unset = OFF).
Flag off → every file below behaves exactly as it did before any of this —
verified by diffing against your original zip; the changes are additive
branches, not rewrites of existing logic.

13 files total: 9 new, 4 modified. Full files are under their real paths;
`patches/` has a `.patch` per modified file and a `.NEW.txt` marker per new
file (nothing to diff against).

## Tier 1 (unchanged from last delivery)
- `lib/feature-flags.ts` — the flag itself.
- `app/api/mirror/calibration/route.ts` — Mirror access gate skipped when flag is on.
- `components/SessionView.tsx` — Examiner moved to the front, six-persona grid collapsed behind a disclosure toggle.

## Tier 2 — the prediction layer (new)
- `supabase/sprint_prediction_layer.sql` — new columns: `initial_instinct`,
  `optimization_priority`, `quorum_predicted_choice`,
  `quorum_prediction_reasoning`, `final_decision` (encrypted, matching
  `outcomes.what_decided`'s treatment), `prediction_matched_final`. **Run
  this in Supabase before enabling the flag** — the new routes will error
  without it.
- `lib/prediction-engine.ts` — generates the prediction. Separate from
  `app/api/persona/route.ts` on purpose (see that file's own doc comment on
  why touching the six-persona orchestrator is separate, riskier work).
  Personalized once a user has 3+ decided sessions; below that, uses
  `createWebSearchCompletion` (already in your `ai-client.ts`, wrapping
  Anthropic's native web search) to ground the guess in general patterns
  instead of faking personalization — and says so in the reasoning text.
- `app/api/session/[id]/instinct/route.ts` — locks initial instinct +
  priority before anything else renders.
- `app/api/persona/predict/route.ts` — generates + caches the prediction
  (idempotent — a refresh won't re-bill or regenerate).
- `app/api/session/[id]/decide/route.ts` — locks the final decision,
  computes whether it matched the prediction, and a simple pattern-callback
  count against past sessions.
- `components/InitialInstinctCapture.tsx` / `QuorumPrediction.tsx` /
  `PredictionReveal.tsx` — the three new UI moments.
- `components/SessionView.tsx` (further modified) — hard gate: nothing else
  in the session mounts until instinct is locked (this is the doc's
  "critical bias protection" requirement, implemented as an early return,
  not a conditional deep in the render tree — safe because it sits after
  every hook in the component).

**Honest limitation:** instinct-lock state is local-only for this pass — a
page refresh mid-session will ask again rather than remembering it was
already locked. Fixing that means having the session fetch that feeds
`SessionView` select the two new columns, which I didn't want to guess at
blindly. One-line follow-up once you point me at that query.

## Tier 3 (scoped honestly — see notes on each)
- `components/PersonaPanel.tsx` — structured challenge reason chips
  ("Misread my priorities," "Missed a risk," etc.) that prefill the
  existing free-form pushback box. Nothing about the actual submission
  path changed — this is a prefill helper, not new backend logic.
- `app/api/mirror/calibration/route.ts` (further modified) —
  `derivePersonalPattern()` alongside the existing `derivePattern()`,
  switched by the flag. This is **one representative reframing**, not
  every Mirror string rewritten — extending the same voice to Bias
  Fingerprint, Independence Score, etc. is a content pass on each of those
  components, not included here.
- `components/QuorumLearnedSomething.tsx` + `app/page.tsx` — the "Quorum
  noticed..." home screen line, reusing the calibration endpoint. Renders
  nothing for a user with no data yet. **Worth checking**: I noticed
  `CalibrationRevealCard` is already imported in `app/page.tsx` — possible
  overlap with what this does; I didn't have time to trace whether it
  already covers this, so take a look before assuming both should ship.
- Cold-start base rates: not a separate item — it's inside
  `lib/prediction-engine.ts` above, using real web search rather than the
  model's unaided general knowledge.

## What's still not built
A full home dashboard IA beyond the one line on `app/page.tsx`; propagating
the Tier 3 Mirror voice beyond calibration's pattern line; and the
positioning/marketing language changes (that's the website repo, not this
one).

## Before merging
Run the SQL migration first. Then your normal build/typecheck/test suite —
this was sanity-checked for bracket balance and scoped carefully around the
fragile parts (`persona/route.ts` untouched throughout), but not run
against your actual environment.
