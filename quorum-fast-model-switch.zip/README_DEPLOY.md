# Fast-role provider switch — deploy notes

## What changed
- `lib/ai-client.ts` — added `FAST_MODEL_PROVIDER` env-driven switch (`mistral` | `openai` | `gemini`) controlling both Free tier (end-to-end) and Elite's fast role. Added GPT-5 mini and Gemini 2.5 Flash as fully wired targets (`openai-fast`, `gemini-fast`), reusing the existing OpenAI-compatible stream/completion helpers. Handles GPT-5's request-shape quirks (`max_completion_tokens` instead of `max_tokens`, no custom `temperature`) automatically by model-name detection.
- `env.example` — documents the new vars.

## Pre-deploy steps
1. Set env vars in Railway (only the ones for the provider you're testing first):
   - `FAST_MODEL_PROVIDER=mistral` (leave as-is until you're ready to test — this is the safe default, zero behavior change)
   - `OPENAI_API_KEY=sk-...` (from platform.openai.com) — only needed once you set `FAST_MODEL_PROVIDER=openai`
   - `GEMINI_API_KEY=...` (from aistudio.google.com/apikey) — only needed once you set `FAST_MODEL_PROVIDER=gemini`
   - Optional overrides: `OPENAI_FAST_MODEL` (default `gpt-5-mini`), `GEMINI_FAST_MODEL` (default `gemini-2.5-flash`)
2. No SQL migrations, no new Razorpay setup, no other code changes required.
3. No Mistral rate-limiter changes needed — the new providers deliberately skip that admission-control queue (see code comments); they rely on the existing generic 429/503 retry handling instead.

## To test
Flip `FAST_MODEL_PROVIDER` to `openai` or `gemini` in Railway and redeploy (or restart) — takes effect immediately, no code change. Flip back to `mistral` to instantly revert.

## Known caveat to watch for during testing
GPT-5 mini cannot accept a custom `temperature` (OpenAI rejects anything but the default, 1). Any structured/low-temperature call (e.g. ontology tagger, bias scorer, if routed through the fast role) silently loses temperature-based determinism on `openai-fast` specifically — worth checking those outputs for consistency during the comparison, since this is a real behavioral difference from Mistral/DeepSeek/Gemini, not a bug to fix.
