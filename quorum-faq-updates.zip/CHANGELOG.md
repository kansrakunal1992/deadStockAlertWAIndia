# FAQ updates — model disclosure, DeepSeek data residency, what not to input

## Changed
- `components/FAQSection.tsx` (in-app home page FAQ)

## What changed
1. **"What AI models power Quorum?"** — updated. Free and Elite's fast role
   now say DeepSeek V4 Pro (previously Mistral Small). Elite's premium role
   (Claude Sonnet) and Private's self-hosted Qwen/Mistral are unchanged.
2. **New: "Is my data safe with DeepSeek?"** — placed directly after the
   models FAQ. States plainly that DeepSeek is China-based and that its own
   privacy policy puts processed data on servers in China, notes that only
   the call-specific data is sent (encrypted in transit), and points
   privacy-sensitive customers to Private tier (self-hosted Qwen/Mistral,
   DeepSeek never in that path) as the actual mitigation. Deliberately does
   not claim data never reaches China — that would contradict DeepSeek's own
   published policy.
3. **New: "What shouldn't I put into Quorum?"** — placed after "How private
   is my data?". Generic guidance: no passwords/PINs/API keys, no full card
   or bank account numbers, no government ID numbers, no other people's
   personal details without consent — reframe with the shape of the decision
   instead of the raw sensitive value.

## Not yet done
- The marketing site's FAQ (separate from this in-app component) still has
  the old Mistral-Small wording — pending the website files you mentioned
  you'll share.
- No other file in the app references "Mistral Small" in FAQ/marketing
  copy — this was the only stale spot found in the app codebase.

## Verification
Isolated `tsc --noEmit` on the file — clean aside from expected missing-
`react`-types noise (no `node_modules` in this environment). No syntax
errors in the edited `FAQItem[]` array; entry count and brace balance
checked by hand.
