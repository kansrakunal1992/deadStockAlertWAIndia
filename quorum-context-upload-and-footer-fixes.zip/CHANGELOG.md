# Quorum — Context Box File Uploads + Footer Install Link

2 files changed (app/page.tsx is a full drop-in — it's cumulative and
already includes every fix from the prior 4 zips, plus today's
additions below; AppFooter.tsx is a small, isolated addition). Builds
on top of quorum-install-guide-and-methodology-fixes.zip.

## 10 (upload piece). app/page.tsx — attach files to the context box

You can now attach a file to a decision's context box, not just paste
text. Reuses the exact same client-side parser Context Ingestion
already uses (`lib/context-export-parser.ts`) rather than building
new parsing logic — same accepted types: ChatGPT/Claude export
(.zip/.json), Markdown, HTML, or Word (.md/.html/.docx).

How it works:
- "Attach a file" button appears once the context box is expanded.
  Selecting a file (or several) parses each one entirely in your
  browser — the file itself never gets uploaded anywhere, only the
  extracted text does, same privacy property as Context Ingestion.
- Each attachment shows as a small removable chip (filename + char
  count), separate from whatever you've typed — so removing one
  doesn't touch your typed text or other attachments.
- On submit, typed context and every attachment's text are combined
  into one context_text string, each attachment clearly labeled
  ("— From attached file: X —") so it's obvious to both you and the
  Council what came from where.
- Unsupported file types, empty files, or unreadable files show a
  plain-language error (same error messages the parser already
  produces for Context Ingestion) rather than failing silently.

One deliberate difference from Context Ingestion: each attachment is
capped at 8,000 characters here (vs. Context Ingestion's ~400,000-char
cap). That larger cap makes sense for building a persistent Mirror
profile from a full chat export; it doesn't make sense for context on
a single decision, where a persona prompt is a few hundred tokens —
dumping in that much text would drown out the actual decision rather
than sharpen it. If truncated, the chip says so.

Tour copy updated too — the context-box walkthrough step now mentions
you can attach a file, not just type.

## Footer — install guide link

Added `/install` to the footer, and renamed the underlying constant
from `LEGAL_LINKS` to `FOOTER_LINKS` (with an updated comment) since
it's no longer legal-pages-only. Everything else in the footer is
unchanged.

## Verification
Both files run clean through `tsc --noEmit` in isolation (JSX
preserve, esModuleInterop, skipLibCheck) — no syntax errors. Same
caveat as prior batches: no node_modules here, so this is a
syntax/structure check on the edited files, not a full project
type-check — worth a manual smoke test of the attach flow (upload a
.docx, an .md file, remove one, submit a decision) after deploy.
