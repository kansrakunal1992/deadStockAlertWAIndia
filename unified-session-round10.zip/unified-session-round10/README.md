# Round 10 — the "worth stealing" items

7 files: 2 new (`SessionComposer.tsx`, `useTypewriter.ts`), 5 modified.
Everything gated behind the flag as before.

## 1. One composer, not three different-looking boxes

New `components/SessionComposer.tsx` — same look, same placement logic,
same button language everywhere it's used. Wired into `SynthesisChallenge`
(the disagree box) and `PredictionReveal` (the final-decision box) —
both are mine, safe to refactor.

**Scoping decision, not an oversight:** Examiner's own answer input is
untouched. It's a complex, pre-existing state machine (multiple questions,
redirect banners, its own streaming) that I didn't build and don't fully
own — swapping its internal input for an external shared component risked
destabilizing it for a purely visual goal. So this is "two of three inputs
now share one real component," not a single instance that literally
persists across the whole session. If you want Examiner included too, that
needs a dedicated pass with more care than a "while I'm at it" change.

## 2. Perceived streaming

New `lib/useTypewriter.ts` — a word-by-word reveal hook, wired into
`QuorumPrediction`'s reasoning text and `ExaminerReflectionLine`. Be
precise about what this is: **not real token streaming.** The network
call is unchanged — the full response still arrives in one shot, the same
number of seconds later. What changes is the transition from spinner to
text — it types out instead of popping in as a finished block. Real
streaming (server-sent events from the completion call) would mean
touching `lib/ai-client.ts`'s call pattern — a real backend change, not
something to fold into this pass. Worth doing properly later if the
perceived-vs-actual gap still bothers you once this is in front of users.

## 3. Review before lock

`PredictionReveal` now has three states instead of two: compose (type your
decision) → review (what you typed, read-only, plus the review date, with
Edit or Confirm & Lock) → revealed. One extra tap, not unlimited editing —
the record still only becomes permanent on explicit confirmation, so
Mirror's data integrity is unaffected. "Edit" goes back to compose with
your text preserved.

## 4. Less on screen at once

Small, deliberately modest change: more vertical space between the
required "Make your decision" step and the optional "See how Quorum got
here" disclosure, so the required action doesn't visually blend into the
optional deep-dive. This one is a judgment call more than an engineering
fix — the honest note from the mobile audit still applies: whether density
actually reads as "too much" is something to confirm by looking at it, not
something I can fully solve by reading component code.

## Before merging

Same as every round.
