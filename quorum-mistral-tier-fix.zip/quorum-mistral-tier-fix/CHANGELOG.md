# Mistral rate limit + tier-fallback fix — 2026-08-06

Two related fixes, delivered together because the screenshot ("elite run"
still hitting `no x-product-tier header ... falling back to free") is
explained by the second one, and the first one only pays off once the
second one is true — otherwise you're rate-limiting a Mistral account that
Elite traffic wasn't even supposed to be sharing.

---

## 1. Mistral shared-account rate limiter (new)

**Numbers used** (mistral-small-2603, from your account dashboard,
2026-08-06): 0.83 requests/second, 50,000 tokens/minute.

**Why it's needed:** every `mistral-cloud` call — Free tier end-to-end AND
Elite's fast role — shares one Mistral account. 6 personas fire
concurrently on mount, plus several scoring/tagging completions
(bias-scorer, ontology-tagger, structural-retrieval, contradiction-detector)
land in the same couple of seconds per session. Only reactive 429-retry
existed before this; nothing reduced the actual request rate.

**What it does** (`lib/mistral-limiter.ts`, new file):
- Proactive admission control: every mistral-cloud call is queued and only
  dispatched once two gates pass — an RPS leaky-bucket (≥1 request per
  ~1.2s) and a TPM sliding-window budget (estimated tokens, 90% of the
  published ceiling as safety margin).
- **Elite calls are prioritized over Free calls** in the shared queue —
  under contention, paying users get served first.
- A call that waits past 45s (configurable) fails with a clear error
  instead of hanging past Railway's own timeout.
- Scoped to exactly the `mistral-cloud` target — Private tier
  (`mistral-selfhosted`, per-customer accounts) and all other providers are
  untouched, correctly, since they're not sharing this account.
- Single-instance in-memory, same assumption as the existing
  `lib/rate-limit.ts`. Flagged in the file's doc comment if this ever needs
  to move to Redis for a multi-instance deploy.

**Verified:** standalone JS reimplementation of the queue algorithm
(`test_limiter.mjs`, not included in this zip — logic only, no toolchain
available in this environment) — 4 scenarios all passed: RPS spacing,
Elite-jumps-queue priority, TPM gating, timeout rejection. Also passed an
isolated `tsc --noEmit --strict` check (stubbed `server-only` + `process`
types — no other project deps needed for this file).

**Wired into** `lib/ai-client.ts`'s `createCompletion`/`createStream`,
`'mistral-cloud'` branches only. Zero changes needed at any of the 15+ AI
call sites — same zero-wiring design the tier system already uses.

**New env vars** (documented in `env.example`, all optional/defaulted):
`MISTRAL_RPS`, `MISTRAL_TPM`, `MISTRAL_MAX_QUEUE_WAIT_MS`.

---

## 2. Tier-fallback bug — root cause of the screenshot

**Root cause:** `x-product-tier` is only ever resolved by `middleware.ts`
from a request's `Authorization: Bearer` token. Several AI-calling steps
run via **internal server-to-server `fetch()` calls** (authenticated with
`x-internal-secret`, not a user's Bearer token) or via **client-side fetches
that never sent an Authorization header in the first place**. Either way,
`ai-client.ts`'s `getTierFromHeaders()` finds nothing and silently falls
back to Free — regardless of the real caller's tier. This is exactly what
the screenshot shows: `mistral-cloud` completions paired with repeated
`no x-product-tier header` warnings on what should have been an Elite
session.

Fixed at every point this was found, in two categories:

### A. Internal server-to-server hops (new `lib/tier-forward.ts`)

`forwardTierHeaders(req.headers)` copies the *current* request's
already-resolved tier headers onto an outbound internal `fetch()`'s headers.
Because `middleware.ts`'s "no Bearer token" branch forwards headers
unchanged rather than stripping them, this survives to the next hop.

Applied at all 4 internal hops found:
- `app/api/session/route.ts` → `fireOntologyTagger()` → `/api/ontology`
- `app/api/ontology/route.ts` → `fireStructuralMatch()` → `/api/structural-match`
- `app/api/examiner/route.ts` → `fireBiasScore()` → `/api/bias-score`
- `app/api/examiner/route.ts` → `fireContradictions()` → `/api/mirror/contradictions`
- (`fireIndependenceScore()` → `/api/mirror/independence` also updated,
  precautionary — that route is deterministic today, no AI call, so this
  one isn't fixing an active bug, just closing the gap before it becomes one)

### B. Missing route coverage

`/api/context-ingestion/:path*` was **entirely missing** from
`middleware.ts`'s matcher — not a header-forwarding issue, this route
family never ran through tier resolution at all, for any user, regardless
of what the client sent. `lib/context-extractor.ts` (used by both routes
under it) calls `createCompletion` directly, and Context Ingestion is an
Elite-only feature. One-line fix: added to the matcher. The client side
(`ContextIngestionPanel.tsx`) already sent proper auth headers — they just
had nowhere to land.

### C. Client-side fetches missing Authorization entirely

- **`components/ExaminerPanel.tsx`** — all 4 fetch calls (`GET /api/examiner`,
  and 3 `POST` calls for skip/submit) had no Authorization header, and the
  component's `Props` interface didn't even have an `authToken` field to
  begin with. `app/api/examiner/route.ts` calls `createCompletion` directly
  five times (the 80-max-token completions visible in the screenshot) and
  its POST handler is the trigger point for the whole bias-score/
  independence/contradictions chain above. **This is almost certainly the
  primary match for your screenshot** — small max_tokens values, right next
  to Examiner log lines, in the same session. Added `authToken` prop,
  threaded from `SessionView`'s existing `authTokenSV`.
- **`components/SynthesisCard.tsx`** — the Decision-Maker Observation
  auto-fetch (`POST /api/session/[id]/observation`, Mirror-subscriber-only
  feature) had no headers at all.
- **`components/DecisionStateCard.tsx`** — `proceedSave()`'s
  `POST /api/session/commitment` had no Authorization; that route calls
  `detectAdvisorDivergence()` (`lib/advisor-divergence.ts`), a real
  `createCompletion` call. Added an `authToken` prop (component had none).
- **`components/EarlyEchoCard.tsx`** — the echo-hint fetch had no
  Authorization; its route's annotation step goes through
  `createCompletion` too (an explicit `provider: 'anthropic'` request still
  resolves via the caller's real tier under tiered routing — it maps to the
  premium *role*, not a hardcoded bypass). Added an optional `authToken`
  prop, only wired at the `SessionView` render site — left the
  `app/record/[id]/page.tsx` render site alone since that page is an
  intentionally-public/shareable view that already doesn't resolve a
  personal token for its sibling component.
- **`components/SessionView.tsx`** — the structural-match fallback POST had
  no headers at all; fetches its own fresh Supabase session token (same
  pattern as the existing `fetchStyleCue`, to avoid a mount-order race
  against `authTokenSV`'s own effect).

### Not changed, checked and confirmed fine
- `components/RuleRecallBanner.tsx`, `BehaviorAlerts.tsx`,
  `CaseStudyOptIn.tsx`, `ContradictionDetector.tsx`, `ContradictionBanner.tsx`,
  `BiasFingerprint.tsx`, `DecisionRules.tsx`, `IndependenceScore.tsx` — all
  already send Authorization correctly.
- `app/api/voice/cleanup` (`VoiceInput.tsx`) — intentionally unauthenticated
  per the existing doc comment in `lib/rate-limit.ts`. Left alone.
- `app/api/record/[id]/brief` (PDF download, `BriefCTA.tsx`) — uses a
  separate shared-secret/query-param scheme by design (shareable link, not
  a Bearer-token flow). Left alone.
- `app/api/mirror/mind-change` — imports `lib/advisor-divergence.ts` but
  only the deterministic `getAdvisorDivergencePattern()` (no AI call).
  Not part of this bug.
- `app/api/mirror/alerts`, `app/api/session/[id]/bias-note` — import
  `bias-scorer.ts` but only for the `BIAS_PARAMETERS` constant, not a
  function that calls AI. Not part of this bug.

### Flagged, not fixed (out of scope for this pass)
- `app/api/cron/mirror-insight-email` imports `bias-scorer.ts`'s AI-calling
  function too, same as `daily-nudge`/`reanalyze-email` — which your own
  prior session already flagged as needing `lib/tier-context.ts`'s
  AsyncLocalStorage override, "not yet wired in." `mirror-insight-email`
  looks like it has the identical gap and was never included in that
  earlier flag. Didn't touch it this pass (batch/cron, not the live-session
  bug in your screenshot) — worth a follow-up.
- `components/SessionView.tsx`'s `handleOverrideRedirect()` — its
  `PATCH /api/ontology` call still has no Authorization header. Left as-is:
  that handler doesn't call AI (just logs an override flag) and the route
  doesn't read Authorization for it either, so this is cosmetic, not
  functional. Noted here rather than making a no-op edit.

---

## Files in this zip
```
lib/mistral-limiter.ts          NEW
lib/tier-forward.ts             NEW
lib/ai-client.ts                modified
middleware.ts                   modified
app/api/session/route.ts        modified
app/api/ontology/route.ts       modified
app/api/examiner/route.ts       modified
components/SessionView.tsx      modified
components/SynthesisCard.tsx    modified
components/ExaminerPanel.tsx    modified
components/DecisionStateCard.tsx modified
components/EarlyEchoCard.tsx    modified
env.example                     modified
```

## Verification done
- Isolated `tsc --noEmit --strict` on the two new standalone files (clean).
- Bracket/paren/brace balance check across every modified file (clean).
- Manual review of every switch-statement / function-boundary edited in
  `lib/ai-client.ts`, all three route.ts files, and each component.
- Standalone JS reimplementation of the rate limiter's queue algorithm,
  run against 4 scenarios (see above).
- Full-codebase regression check: re-confirmed the 4 previously-fixed
  `/api/persona` call sites (2 in `PersonaPanel.tsx`, 2 in
  `SynthesisCard.tsx`) still carry their Authorization headers after this
  session's edits touched the same file.
- No `vitest` run — no network access in this environment, consistent with
  prior sessions on this project.
