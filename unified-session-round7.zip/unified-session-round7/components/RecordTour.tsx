'use client'

// components/RecordTour.tsx
// Sprint TOUR-1 — Record page tour wrapper (client component)
// Server-rendered record page imports this; it reads localStorage on mount
// and shows the tour only when the user hasn't seen it yet.
//
// Dynamic step logic (built once on mount):
//   1. Base steps always appear.
//   2. Email-link steps (2 steps): only when user has no linked email.
//      — Explains where to enter email + what to do after the link arrives.
//   3. PWA install step: only when user HAS linked email AND is on a mobile
//      browser outside standalone mode (via buildPWAInstallStep).
//      Email-link users never see the PWA step in the same session — they get
//      it on a future tour after they've clicked the email link.

import { useState, useEffect } from 'react'
import { isUnifiedSessionEnabled } from '@/lib/feature-flags'
import OnboardingTour, { buildPWAInstallStep } from './OnboardingTour'
import type { TourStep } from './OnboardingTour'

interface Props {
  /** P0 fix: real cross-session decision count, resolved server-side in
   *  app/record/[id]/page.tsx. Previously this component had no way to know
   *  whether the user was new — it only ever checked localStorage, so an
   *  established user (e.g. 5 decisions already on record) opening the app on
   *  a fresh device/PWA install would see a "first decision" tour here too. */
  totalSessionCount?: number
  /** P0 fix: server-side truth for "has this user already seen the Record
   *  tour", resolved from user_profiles.record_tour_completed_at — same
   *  cross-device durability the Home tour already had. */
  tourDone?: boolean
}

const RECORD_STEPS_BASE: TourStep[] = [
  {
    id:               'record-decision',
    targetSelector:   '[data-tour-id="record-decision"]',
    heading:          'Your decision is now on the record',
    body:             'This is your permanent audit trail — the decision exactly as you framed it, when you made it, and how confident you were. Quorum never alters what you wrote.',
    preferredSide:    'bottom',
  },
  {
    id:               'record-outcome',
    targetSelector:   '[data-tour-id="record-outcome"]',
    heading:          'Come back here when the outcome is known',
    body:             'Log what you actually decided and how it unfolded. Without outcome data, pattern detection has nothing to learn from. Most users return 2–4 weeks after the decision.',
    preferredSide:    'bottom',
  },
  {
    id:               'record-decision-brief',
    targetSelector:   '[data-tour-id="record-decision-brief"]',
    heading:          'Take the full analysis with you',
    body:             isUnifiedSessionEnabled()
      ? 'Download this decision as a formatted PDF — the synthesis, your initial lean, Quorum\'s hypothesis and reasoning, what you actually chose, and any pushbacks you raised. Useful for sharing with a partner or co-founder, or just for your own records outside Quorum.'
      : 'Download this decision as a formatted PDF — every advisor\'s position, the synthesis, and any pushbacks you raised. Useful for sharing with a partner or co-founder, or just for your own records outside Quorum.',
    preferredSide:    'bottom',
  },
  {
    id:               'record-new-decision',
    targetSelector:   '[data-tour-id="record-new-decision"]',
    heading:          'Your next decision is already waiting',
    body:             'Each decision you bring to the Council adds a layer to your Judgment OS. Tap here when you have your next decision — patterns begin to surface from your third entry onward.',
    preferredSide:    'bottom',
  },
]

// Two-step email-link sequence — only for first-time users with no linked email.
const EMAIL_LINK_STEPS: TourStep[] = [
  {
    id:               'record-email-link',
    targetSelector:   '[data-tour-id="record-email-link"]',
    heading:          'Lock in your decisions',
    body:             'Right now your decisions are tied to this device only. Sign in with Google for instant, one-click access — or enter your email for a one-time link instead. Either way, your entire record travels with you across devices.',
    preferredSide:    'bottom',
  },
  {
    id:               'record-email-after',
    targetSelector:   null,
    heading:          'You\'re set either way',
    body:             'Chose Google? You\'re already linked — nothing else to do. Used email instead? Just click the link when it lands in your inbox and you\'ll come straight back here, fully synced.',
    preferredSide:    'bottom',
  },
]

export default function RecordTour({ totalSessionCount, tourDone = false }: Props) {
  const [active, setActive] = useState(false)
  const [steps,  setSteps]  = useState<TourStep[]>(RECORD_STEPS_BASE)

  useEffect(() => {
    // P0 fix: server truth + real decision count first — localStorage alone
    // was never enough to tell "new user" from "established user, new device".
    if (tourDone) return
    if ((totalSessionCount ?? 0) > 1) return
    try {
      const done = localStorage.getItem('quorum_tour.record')
      // Product decision (2026-08): the three tours (home, council, record)
      // are independent — dismissing one must not suppress the others. This
      // used to also check `quorum_tour.home === 'skip'` and bail out if the
      // home tour had been explicitly skipped, which meant a user who
      // skipped the home tour would silently never see this one either.
      // Now this tour only ever looks at its own dismissal state
      // (`quorum_tour.record`).
      if (!done) {
        // ── Build dynamic step list ──────────────────────────────────────────
        const hasEmail = !!localStorage.getItem('quorum_user_email')

        const dynamicSteps: TourStep[] = [...RECORD_STEPS_BASE]

        if (!hasEmail) {
          // User hasn't linked email → show the two email-link tutorial steps.
          // Do NOT append PWA step yet (requires email to be linked first).
          dynamicSteps.push(...EMAIL_LINK_STEPS)
        } else {
          // User has email → check if a PWA install step is appropriate.
          const pwaStep = buildPWAInstallStep()
          if (pwaStep) dynamicSteps.push(pwaStep)
        }

        setSteps(dynamicSteps)

        // Delay to let the record page fully paint before overlay appears
        const t = setTimeout(() => setActive(true), 700)
        return () => clearTimeout(t)
      }
    } catch {}
  }, [tourDone, totalSessionCount])

  if (!active) return null

  // P0 fix: persist completion/skip server-side too, not just localStorage —
  // mirrors the Home tour's existing cross-device fix. Token is fetched lazily
  // here (rather than held in state throughout) since it's only ever needed
  // at this one moment; dynamic import keeps the supabase client out of this
  // component's initial bundle for the common case where the tour never fires.
  const persistTourDone = async () => {
    try {
      const { createClient } = await import('@/lib/supabase')
      const sb = createClient()
      const { data: { session: authSession } } = await sb.auth.getSession()
      const token = authSession?.access_token
      if (!token) return
      fetch('/api/onboarding/complete', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body:    JSON.stringify({ tour: 'record' }),
      }).catch(() => {})
    } catch { /* anonymous session — nothing to persist server-side */ }
  }

  const handleComplete = () => {
    try { localStorage.setItem('quorum_tour.record', 'done') } catch {}
    persistTourDone()
    setActive(false)
  }

  const handleSkip = () => {
    try { localStorage.setItem('quorum_tour.record', 'skip') } catch {}
    persistTourDone()
    setActive(false)
  }

  return (
    <OnboardingTour
      page="record"
      steps={steps}
      active={active}
      onComplete={handleComplete}
      onSkip={handleSkip}
    />
  )
}
