# Round 7 — light-touch copy + full tour pass

4 files. Patches are each against the correct last-delivered version of
that file (see which round in each patch's diff — not all 4 were last
touched in the same round).

## Light-touch copy (as agreed)

- **`app/methodology/page.tsx`** (the actual "how Quorum works" page, never
  checked until this round) — the "Six advisors respond from that read"
  step now says "in the background" under the flag, and its detail line
  adds that "See how Quorum got here" reveals all six. Nothing else on
  this page touched.
- **`app/page.tsx`, onboarding Panel 1** ("01 · The Council," shown to
  returning users) — headline swapped from "Six advisors analyse every
  decision" to lead with prediction; six advisors moved into the sub-line
  with the same "in the background" framing used everywhere else this
  round.

## Tour pass — this is the one that actually mattered

You asked for a proper pass on the tours across home page, Council
Synthesis page, and record page. Home page's tour was already clean (found
two rounds ago). The other two were not:

**Council Synthesis page tour** (`components/SessionView.tsx`,
`COUNCIL_STEPS_BASE`) — two of its six steps point at elements that no
longer exist under the flag: `council-validation` (targets the
`ValidationCard` hidden two rounds ago) and `council-capture` (targets
`DecisionStateCard`, hidden when the compulsory decision+review-date step
was added). `OnboardingTour` doesn't crash on a missing target, but it does
show the step's instructions with no spotlight pointing at anything — which
is its own kind of broken, just quieter. Both are now filtered out under the
flag. The "six advisors" step's copy is reworded to describe the collapsed
read + the disagree button's real location; its target selector also had a
**pre-existing bug unrelated to any of this work** — it pointed at
`council-challenge`, which doesn't exist anywhere in the file; the real
attribute is `council-personas`. Fixed that too, since I was already there
and it was a one-line change either way. The "save" step's copy now
mentions initial lean, hypothesis, and final decision under the flag instead
of "every advisor's position."

**Record page tour** (`components/RecordTour.tsx`) — mostly already fine;
no persona names, no broken targets (double-checked each of its 4 real
selectors still exists after every change made to this page across the last
several rounds). One line updated: the Decision Brief step described the
PDF as "every advisor's position, the synthesis" — now also mentions the
prediction-arc content that's actually in the PDF under the flag.

## Before merging

Same as always — bracket-balance checked against the correct prior version
of each file, not run through your build/test pipeline.

---

Say "mobile audit" when you want me to start that phase.
