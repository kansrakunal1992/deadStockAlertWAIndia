# Round 11 — small, because most of the work was already done

2 files. Diffed against the code you just uploaded (not my earlier working
copy — that upload is newer and supersedes it).

## What I found when I checked

I went through your "critical new information" list item by item against
the uploaded code before touching anything, and almost all of it was
already done, correctly, with reasoning that matches what I would have
written myself:

- **Disclosure toggle removed, glance strip + individually-collapsed cards
  in its place** — done (`CouncilGlanceStrip.tsx`, `LeanBadge.tsx`).
- **Synthesis no longer requires clicking "See Quorum's full read"** — done.
  `predictionAcknowledged` now defaults to `true` and every gate that used
  to depend on it (Synthesis's wrapper, the persona strip, the tour
  trigger) has been updated with comments explaining the removal.
- **Point 2 (tour showing personas expanded)** — correctly not touched,
  matches your "not required" call; the tour step copy was also already
  updated to describe the new always-visible-cards model instead of the
  old disclosure-toggle one.
- **Point 3 (Back button)** — already fixed, `href="/"` wired in on both
  record-page instances, with a genuinely good explanation of *why* the
  old `router.back()` was landing on the instinct screen (Router Cache
  staleness across the remount boundary).
- **Point 4 (Ranked by relevance)** — correctly left alone, matches "not
  valid."
- **Point 5 (transparent backgrounds)** — `.btn-ghost` and `.btn-pushback`
  already fixed in `globals.css`, same reasoning I'd have used (dark theme
  masked it, light theme didn't).

## What I actually changed

One real piece of leftover dead code: `QuorumPrediction.tsx` still had the
"Continue" button and its `onContinue`/`alreadyAcknowledged` props sitting
in it — harmless, since the condition guarding it could now never be true,
but exactly the kind of thing that confuses whoever reads this file next
without also reading `SessionView.tsx` to know it's unreachable. Removed
the button, the props, and the now-pointless error-handler that used to
fire it. Updated `SessionView.tsx`'s one call site to match.

That's it — everything else on your list was already correct.
