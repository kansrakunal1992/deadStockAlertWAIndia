// app/api/auth/link-sessions/route.ts
// ── Sprint 6 + 6b: Link pre-auth sessions to authenticated user ───────────────
//
// Sprint 6b additions:
// - Accepts `deviceIds: string[]` (array) instead of single `deviceId`
// - Updates sessions table by device_id (not just bias_library)
// - Handles both same-browser (localStorage IDs) and cross-browser (URL-param IDs)
//
// Linking strategy (runs all in parallel):
//   1. RPC link_sessions_to_user — links sessions by explicit UUID list
//   2. Device-ID session sweep   — UPDATE sessions WHERE device_id IN (...) AND user_id IS NULL
//   3. Email session sweep       — UPDATE sessions WHERE user_email = ? AND user_id IS NULL
//   4. Bias library retro-link   — upgrades anonymous bias rows to user_id lane
//   5. user_preferences upsert   — ensures Mirror can access the user's preferences
//
// Provider-lock / duplicate-account note (confirmed with product, 2026-08):
// this route intentionally does NOT run a cross-provider duplicate-account check
// (e.g. "does this email already have a user_preferences row under a different
// user_id with a different signup_method, and if so delete the just-created
// duplicate auth user"). That backstop was drafted at one point but never built,
// and an earlier pass of this codebase's own documentation assumed it existed.
// It doesn't need to: Supabase Auth's own identity linking already merges a
// magic-link login and a Google login for the same email into a single auth
// user — confirmed directly against this project's Supabase configuration, not
// assumed. So `userId` here is already Supabase's one canonical user id for that
// email regardless of which method the person used to sign in this time; there
// is no second, orphaned auth user for this route to detect or clean up.
// `authMethod` below is purely informational (used only to label
// user_preferences.signup_method on that single row), not a decision input.
// ─────────────────────────────────────────────────────────────────────────────

import { NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase'

export async function POST(req: Request) {
  try {
    const { sessionIds, userId, userEmail, deviceIds, deviceId, authMethod } = await req.json() as {
      sessionIds?: string[]
      userId?:     string
      userEmail?:  string
      deviceIds?:  string[]                        // Sprint 6b: array of device IDs to sweep
      deviceId?:   string                           // legacy single deviceId (kept for backward compat)
      authMethod?: 'magic_link' | 'google'          // which flow just authenticated — stamped into
                                                     // user_preferences.signup_method below, informational only
    }

    if (!userId) {
      return NextResponse.json({ error: 'userId required' }, { status: 400 })
    }

    const supabase = createServiceClient()

    // Normalise device IDs — accept both legacy single field and new array
    const allDeviceIds = [
      ...(deviceIds ?? []),
      ...(deviceId ? [deviceId] : []),
    ].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i) // deduplicate

    // ── 1. Link explicit session IDs via RPC ──────────────────────────────────
    let linkedByIds = 0
    if (sessionIds?.length) {
      const { data, error } = await supabase.rpc('link_sessions_to_user', {
        p_session_ids: sessionIds,
        p_user_id:     userId,
        p_user_email:  userEmail ?? null,
      })

      if (error) {
        // Non-fatal — log and continue. Device sweep may still recover sessions.
        console.warn('[LinkSessions] RPC error (non-fatal):', error.message)
      } else {
        linkedByIds = data ?? 0
      }
    }

    // ── 2. Device-ID session sweep (THE cross-browser fix) ───────────────────
    // Updates sessions table directly for all device IDs.
    // This catches: sessions created before the magic link was sent, AND sessions
    // created by reanalyze AFTER the link was sent (those wouldn't be in ?xs=...).
    let linkedByDevice = 0
    for (const did of allDeviceIds) {
      const { error } = await supabase
        .from('sessions')
        .update({
          user_id:    userId,
          user_email: userEmail ?? null,
        })
        .eq('device_id', did)
        .is('user_id', null)

      if (error) {
        console.warn(`[LinkSessions] Device sweep failed for ${did} (non-fatal):`, error.message)
      } else {
        linkedByDevice++
        console.log(`[LinkSessions] device_id=${did}: sweep complete`)
      }

      // Phase 4: chat_intakes carry the same device_id and the same missing
      // user_id (this sweep only ever covered `sessions`). Linking them keeps a
      // half-finished chat attached to the person who started it. Best effort:
      // a failure here must not fail the sign-in.
      const { error: ciErr } = await supabase
        .from('chat_intakes')
        .update({ user_id: userId, user_email: userEmail ?? null })
        .eq('device_id', did)
        .is('user_id', null)
      if (ciErr) console.warn(`[LinkSessions] chat_intakes sweep failed for ${did} (non-fatal):`, ciErr.message)
    }

    // ── 3. Email session sweep ────────────────────────────────────────────────
    // Catches sessions where the user had entered their email before auth.
    // (Sessions where user_email was set but user_id was still null.)
    let linkedByEmail = 0
    if (userEmail) {
      const { error } = await supabase
        .from('sessions')
        .update({ user_id: userId })
        .eq('user_email', userEmail)
        .is('user_id', null)

      if (error) {
        console.warn('[LinkSessions] Email sweep failed (non-fatal):', error.message)
      } else {
        linkedByEmail = 1
        console.log('[LinkSessions] email sweep complete')
      }
    }

    // ── 4. Bias library retro-link ────────────────────────────────────────────
    // Upgrades anonymous bias rows to user_id lane for longitudinal accumulation.
    if (userEmail) {
      const { error: emailBiasErr } = await supabase
        .from('bias_library')
        .update({ user_id: userId, user_email: userEmail })
        .eq('user_email', userEmail)
        .is('user_id', null)

      if (emailBiasErr) {
        console.warn('[LinkSessions] Email bias retro-link failed (non-critical):', emailBiasErr.message)
      }
    }

    for (const did of allDeviceIds) {
      const { error: deviceBiasErr } = await supabase
        .from('bias_library')
        .update({ user_id: userId, user_email: userEmail ?? null })
        .eq('device_id', did)
        .is('user_email', null)
        .is('user_id', null)

      if (deviceBiasErr) {
        console.warn(`[LinkSessions] Device bias retro-link failed for ${did} (non-critical):`, deviceBiasErr.message)
      }
    }

    // ── 5. Ensure user_preferences row exists ─────────────────────────────────
    // signup_method is stamped once, on this user_id's first-ever row. Later
    // logins omit it from the upsert payload so it's never overwritten — by
    // this point step 0 has already guaranteed authMethod matches whatever
    // was originally stamped, so there's nothing to update anyway.
    const { data: existingPref } = await supabase
      .from('user_preferences')
      .select('signup_method')
      .eq('user_id', userId)
      .maybeSingle()

    const { error: prefError } = await supabase
      .from('user_preferences')
      .upsert({
        user_id:    userId,
        user_email: userEmail ?? null,
        ...(existingPref?.signup_method ? {} : { signup_method: authMethod ?? null }),
      }, { onConflict: 'user_id' })

    if (prefError) {
      console.warn('[LinkSessions] user_preferences upsert failed (non-critical):', prefError.message)
    }

    const totalLinked = linkedByIds + linkedByDevice + linkedByEmail
    console.log(`[LinkSessions] user=${userId}: ${totalLinked} total sessions linked (ids=${linkedByIds}, device=${linkedByDevice}, email=${linkedByEmail})`)

    return NextResponse.json({
      status:            'ok',
      linked_sessions:   totalLinked,
      linked_by_ids:     linkedByIds,
      linked_by_device:  linkedByDevice,
      linked_by_email:   linkedByEmail,
      user_id:           userId,
    })

  } catch (err) {
    console.error('[LinkSessions] Route error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
