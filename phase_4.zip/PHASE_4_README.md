# Quorum — Phase 4 (measurement and loose ends)

**Apply AFTER `phase_0_1.zip` and `phase_2_3.zip`.** Unzip over the repo root. 17 files changed, 7 new (plus this README). Several changed files were also in earlier zips (e.g. `app/layout.tsx`, the two crons); these are the complete current versions.
`tsconfig.json` is not included (`next build` rewrites it locally).

## Why this phase exists
Phases 0–3 covered every item on the agreed list. What was left: the measurement events from the original spec that were never built (notification opened / to-decision, return visit, mirror viewed/unlocked, paid conversion, notification opted-in), and the loose ends I flagged as "still not built". There is **no new product surface that needs a decision from you** except one small settings page.

## Deploy order
1. Run `supabase/phase4_measurement_views.sql` (views only; needs the Phase 0 and Phase 2/3 SQL already applied). Safe to re-run.
2. Deploy the code. Nothing needs a new env var.

## What changed
| Item | What it does | Files |
|---|---|---|
| Email preferences | New **Settings → Notifications** tab: choose Weekly / Only when I'm stuck / Only for big decisions, and switch the other emails on/off. Saves immediately. Choosing Weekly after a one-click unsubscribe turns the weekly brief back on. Signed-out people see a "Connect your email" card. | `app/settings/notifications/page.tsx`, `app/api/preferences/notifications/route.ts`, `components/SettingsNav.tsx` (4th tab, strip scrolls sideways on narrow phones) |
| Cadence now has meaning | **Only for big decisions** now also stops the "you've been away" nudges (`daily-nudge` skips them). **Only when I'm stuck** keeps stall/lapse nudges but sends no weekly note. Weekly is unchanged. | `app/api/cron/daily-nudge/route.ts` |
| Notification funnel | Email links now carry `?n=<source>` (weekly brief, pattern notice, review-date). `notification_opened` is logged on arrival (once per tab session); `notification_to_decision` if that visit starts a decision. Deliberately **not** `utm_*`, so a returning user clicking an email never overwrites how they were first acquired. Allow-listed values only. `/q` forwards `n`. | `lib/notification-source.ts`, `components/NotificationLandingTracker.tsx`, `app/layout.tsx`, `app/q/page.tsx`, `components/ChatIntake.tsx`, the 3 email crons |
| Remaining events | `return_visit` (back after 12+ h with decisions on the device; needs the device id, i.e. cookie consent), `mirror_viewed` (once per tab session per gate state), `notification_opted_in` (choosing Weekly; enabling push), plus server-side **`paid_conversion`** and **`mirror_unlocked`** from the Razorpay webhook (`subscription.activated` only; analytics failure can never change the webhook response or trigger a retry). | `lib/track.ts`, `app/api/events/route.ts`, `lib/track-server.ts`, `app/api/payment/webhook/route.ts`, `app/NaturalIntakeClient.tsx`, `app/mirror/page.tsx`, `components/HabitSetupCard.tsx`, `components/PushEnablePrompt.tsx` |
| Dashboards | `v_gate_experiment` (D1→D5 per gate arm; read **d4/d1 across arms**, never authenticated-vs-anonymous), `v_notification_funnel_30d` (sent → opened → decided), `v_habit_adoption`, `v_event_counts_14d`. | `supabase/phase4_measurement_views.sql` |
| New-device history | A signed-in person on a **new device** saw no history, counts or hero cards: `/api/history` already merged in everything linked to their account, but the client returned before calling it when local storage was empty. It now always asks when signed in. | `app/NaturalIntakeClient.tsx` |
| Half-finished chats | The sign-in link-up only swept `sessions`; it now also links `chat_intakes` by device id (best effort, never fails the sign-in). | `app/api/auth/link-sessions/route.ts` |

## Things to know
- `notification_sent` is not an event: use `notification_log` (the view above already joins it). `daily_nudge` and `validation_nudge` links are **not** tagged with `?n=`, so they show "sent" but no opened/decided numbers. Review-date emails are tagged but logged by their own cron, so they show opened/decided without a "sent" figure.
- `return_visit` and `mirror_viewed` rely on browser storage; people who declined cookies contribute nothing to `return_visit` (no device id).
- `mirror_unlocked` is emitted only from the subscription webhook, not from the admin grant route (a manual grant is not a user action).
- The new tab uses `user_preferences`, so Phase 2/3 SQL must be applied first.

## Verified vs not
- Verified: `tsc` (no new errors; only the pre-existing TS2802 target noise), **116 tests pass** (95 existing + 18 from Phase 2/3 + 3 new for the `?n=` allow-list), `next build` succeeds (same single pre-existing Edge-runtime warning).
- I diffed every changed file against the previous phase's snapshot and confirmed none of the 7 new files collides with an existing path (relevant because of the route collision caught in Phase 2/3).
- NOT verified: the SQL against a real database, the webhook change against Razorpay (please send a test event on staging and confirm the `events` rows and an unchanged 200 response), the settings page visually, email click-through.

## Staging checklist
1. Open Settings → Notifications signed in; change cadence and a switch; reload — values persist. Signed out → "Connect your email".
2. Choose "Only for big decisions"; run `daily-nudge` for that user → skipped.
3. Click a weekly-brief link (`/q?n=weekly_brief`) → one `notification_opened` row, the `n` param disappears from the address bar, starting a decision logs `notification_to_decision`. `?n=anything-else` logs nothing.
4. Sign in on a second browser with no local history → the hero shows your decisions and counts.
5. Send a Razorpay test `subscription.activated` → `paid_conversion` and `mirror_unlocked` rows appear; webhook still returns 200.
6. `select * from v_gate_experiment; select * from v_notification_funnel_30d;`

## Deliberately NOT built (unchanged decisions)
The quick-take lane (you chose to keep the Council as the default), streaks, share cards, a profile-change email (needs stored profile snapshots), and any change to Mirror pricing or thresholds. Per-user send time was also left out: it needs a stored time zone, which Quorum does not collect.
