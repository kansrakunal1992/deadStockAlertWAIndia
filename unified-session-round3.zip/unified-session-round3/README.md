# Round 3 — 6 feedback points incorporated

7 files, all changes gated behind the same `NEXT_PUBLIC_UNIFIED_SESSION_ENABLED`
flag as before. Diffed against the `unified-session-full` zip you deployed —
apply these 7 on top of it, nothing else needs to change.

## 1. Challenge/disagree needs to be near Council Synthesis, not buried in a persona panel
New `components/SynthesisChallenge.tsx` — a "Disagree / ask a follow-up"
button directly under Synthesis. Reuses the exact same backend path as the
per-persona challenge already had (`handleShareContext` in `SessionView.tsx`,
which broadcasts to all six advisors and triggers one resynthesis) — no new
backend logic, just a better front door onto the pipeline that already
existed. The per-persona challenge inside each expanded persona card still
works too; this doesn't remove it, it adds the one that's actually visible
by default.

## 2. Map the first-3-decision experience; keep / hide / remove
Went through every card that renders in that window. Classification:

**Removed under the flag** (their whole reason to exist assumed the old six-persona-reveal experience, or their job is now done better elsewhere):
- `OpeningCeremonyCard` — ceremony for watching six advisors stream in one by one. Nothing to build anticipation for anymore; Council is collapsed by default.
- `QuorumReadCard` — an onboarding aid that explains how Council/Synthesis works, under the *old* mental model. Its content is now wrong, not just redundant.
- `TensionInterstitial` — surfaces a proceed/wait/mixed breakdown *across the six personas*, which is exactly the mechanic being de-emphasized.
- `ValidationCard`, `EarlyEchoCard`, `MirrorEchoCard` — all three were different-shaped attempts at "here's Quorum's read" / "here's proof we're accumulating something about you." `QuorumPrediction` (the read) and `PredictionReveal`'s pattern callback (the accumulation proof) now do this job earlier and more directly, from session one instead of session 2/5.

Implementation note: these are skipped by initializing their own `dismissed`
state to already-true under the flag, not just hiding their JSX — several of
them gate downstream logic (persona streaming, synthesis start) on their own
dismiss firing, so skipping only the render would leave things stuck waiting
for a dismiss that never happens. Checked each one's dependency chain before
touching it.

**Kept as-is, not addressed this round:** `OntologyRevealCard` and the
`DecisionGraph` teaser — both auto-dismiss with no click required, lower
priority than the ones above. Worth a second pass if the experience still
feels busy after this round.

## 3. Backgrounds were transparent
Root cause: I'd used a CSS variable (`--surface-1`) that doesn't exist in
your stylesheet — it was silently resolving to nothing. The real one,
confirmed from `ExaminerPanel.tsx` and `app/globals.css`, is `--bg-card`
(`#101827` dark / `#ffffff` light — genuinely mode-aware, not a hardcoded
color). Fixed in all four cards that had this bug: `InitialInstinctCapture`,
`QuorumPrediction`, `PredictionReveal`, `QuorumLearnedSomething`.

## 4. Make locking in the final decision compulsory
There was never a skip button on `PredictionReveal`, so the input itself was
already non-optional. What was missing: the surrounding UI could still make
the session *feel* finished before that happened. Fixed by withholding
`RecordReceipt` (the "you're done" card) under the flag until the decision
is actually locked, and adding a visible "required to close this record"
label plus a gold left-border accent so it doesn't read as one card among
many.

## 5. Too much shown at once; too many clicks before Synthesis
This is now progressive reveal, not simultaneous: Synthesis (and everything
gated on it — the Council disclosure toggle, Prediction Reveal) stays
visually hidden — still generating in the background, same pattern as the
already-collapsed six-persona grid — until the user clicks "See Quorum's
full read" on the hypothesis card. One thing to look at, then a deliberate
click to the next thing, instead of two cards competing for attention.
Didn't reduce the click count *before* Quorum says anything (instinct lock
+ Examiner are both still required, and Examiner isn't mine to cut) — if
that's still too much friction, the next lever is combining the two
instinct questions into a lighter single interaction, not removing either.

## 6. Why ask for "a decision" twice?
They're genuinely two different things — a gut lean locked *before* Quorum
says anything (`InitialInstinctCapture`), and the actual final choice locked
*after* seeing the hypothesis and the full read (`PredictionReveal`) — that
gap between the two is the entire point of the prediction mechanic (whether
Quorum can anticipate what you'll actually do, not just what you started out
leaning toward). The confusion was real, though — the two moments looked
similar and appeared close together with nothing tying them to each other.
Fixed two ways: point 5's progressive reveal now puts real distance and a
deliberate click between them, and `PredictionReveal` now explicitly says
"You started out leaning yes/no/unsure — now that you've seen Quorum's
hypothesis and full read, what are you actually going to do?" so the
relationship is stated, not left for the user to infer.

## Also carried over from the prior "left" list
`lib/types.ts` — added the Tier 2 fields to the `Session` type, and
`SessionView.tsx`/`QuorumPrediction.tsx`/`PredictionReveal.tsx` now hydrate
from the session row (`app/session/[id]/page.tsx` already does `select('*')`,
so this was a typing gap, not a query gap) — a refresh mid-session no longer
re-asks for instinct or re-triggers a prediction fetch.

## Still not done
- `CalibrationRevealCard` vs `QuorumLearnedSomething` overlap — still
  unresolved, still worth checking before both ship.
- Reducing clicks *before* the first Quorum output (Examiner + instinct lock
  together) — noted in point 5, not acted on.
- Same build/typecheck caveat as every prior round — sanity-checked for
  structural soundness, not run against your real environment.
