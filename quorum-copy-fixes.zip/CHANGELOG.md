# Quorum — Quick Copy Fixes

4 files touched, copy-only changes (no logic/layout changes). Drop-in
replacements for the matching paths in your repo.

## 1. components/ProfileCaptureOverlay.tsx
Elite/Mirror import line now has a lead-in explaining what it does and
flags Elite as the paid tier, since this is the first time a new user
sees it.

Before: "Elite: skip months of rebuilding context — optionally import
what another AI already knows about you, from Mirror."

After: "Already have context built up elsewhere? On Elite (paid), you
can import what another AI already knows about you from Mirror —
skipping months of re-explaining yourself."

## 2. app/page.tsx — "Challenge the advisors" help text
Updated the quoted button name to match what the button actually says
today. Also softened the sentence around it slightly so it doesn't
repeat "Disagree" twice.

Before: quoted "Challenge this · add context"
After: quoted "Disagree or ask a follow-up"

## 3. components/AuthPanel.tsx + app/mirror/page.tsx — duplicate "Or"
AuthPanel.tsx had the literal bug: divider "or, skip Google" directly
followed by heading "Or use a one-time link" — two "Or"s back to back.
Fixed by trimming the divider to "skip Google" (Option A from the
proposed fixes), letting "Or use a one-time link" carry the "or" on
its own.

mirror/page.tsx uses the same divider phrase next to the same
Google button, but doesn't have a second "Or" heading after it — so
there was no actual duplication there. Trimmed it to "skip Google" too
anyway, purely for consistency between the two near-identical
sign-in blocks (an orphaned "or," reads a little odd without a
matching "Or" partner).

## 4. app/page.tsx — home page context field
Three related copy spots broadened so the context field doesn't read
as "documents only":
- Tour step body (home-context step)
- Collapsed button label
- Expanded textarea subtext

Before (button): "+ Add context · notes, emails, messages"
After (button): "+ Add context · details, background, documents"

Before (subtext): "Paste relevant context — emails, WhatsApp, term
sheets"
After (subtext): "Add any relevant detail — numbers, background,
prior conversations, or documents like emails and term sheets"

The decision field's own tour step (home-textarea) was already
correctly framed as "the actual decision" and wasn't touched.

## Verification
No node_modules in this environment, so a full `tsc --noEmit` against
the whole app isn't possible here. Each edited file was copied out and
run through `tsc --noEmit` in isolation (JSX preserve, esModuleInterop,
skipLibCheck) — filtered for real syntax errors (TS1xxx codes); none
found. Remaining errors are only the expected "no @types/react
installed" noise from running without node_modules, not related to
these edits.

## Not included in this batch
Item 4's fix in mirror/page.tsx assumes there's no other heading
between the divider and the email input on that page — confirmed by
reading the surrounding code, but worth a quick visual check after
deploy since I couldn't render the page.
