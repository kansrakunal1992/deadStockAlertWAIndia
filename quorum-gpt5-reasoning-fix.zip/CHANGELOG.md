# Fix: GPT-5-family calls silently burning their token budget on invisible reasoning

## Changed
- `lib/ai-client.ts`

## Root cause
GPT-5-family "reasoning" models (gpt-5, gpt-5-mini, gpt-5-nano, dated
snapshots) run an internal, non-visible reasoning pass before writing any
visible content, and those reasoning tokens are drawn from the SAME
`max_completion_tokens` budget as the output text. This file was already
correctly using `max_completion_tokens` for these models, but never set
`reasoning_effort` — so every GPT-5-family call defaulted to standard
(non-minimal) reasoning.

On Quorum's synthesis prompt specifically (which asks the model to work
through several layers before writing the verdict), that default reasoning
pass can consume most or all of a 2200-3200 token budget invisibly, leaving
little or nothing for the actual output. This matches a widely-reported
OpenAI API behavior (see openai/openai-python#2546 and multiple OpenAI
community threads) — it isn't specific to Quorum's prompts, and it explains
the exact symptoms from the gpt-5-mini test run: synthesis truncated to 1-2
lines, most of the 6 persona calls missing, and intermittent outright errors
(empty content on a finish_reason of "length" can trip whatever downstream
code expects non-empty content — e.g. the mandatory-tag backfill check).

## Fix
Pinned `reasoning_effort: 'minimal'` on every GPT-5-family call in both
`streamOpenAICompatible` and `completeOpenAICompatible`. This is the
correct behavior for this role, not a workaround forced onto it — every
place that can route to a GPT-5-family model in this file is the FAST role,
so suppressing the model's own deliberation is what the role calls for.

## What this does NOT tell you
This fix should eliminate the truncation/dropped-persona/error symptoms,
but it does not by itself confirm gpt-5-mini's output QUALITY is sufficient
for Quorum's persona/synthesis prompts — that's a separate, still-open
question. The pre-fix test run can't be used to judge capability, because
the plumbing bug would have degraded any GPT-5-family model regardless of
how good its actual reasoning is. A re-test with this fix in place is
needed to get a real read on quality.

## One more thing worth checking (not changed here)
OpenAI's current pricing page no longer lists `gpt-5-mini` — it appears to
have been superseded by newer naming (GPT-5.4-mini / GPT-5.6 family) as of
mid-2026. That's a plausible second contributor to "errors out" on some
runs (a sunset model ID can behave inconsistently during its retirement
window). Didn't change `OPENAI_FAST_MODEL`'s default here since I don't have
a verified exact API model-ID string to swap in — worth confirming directly
against OpenAI's current model list before you re-test.

## Verification
Isolated `tsc --noEmit` on the file — clean aside from expected missing-
`node_modules` noise. Confirmed via grep that both call sites
(`streamOpenAICompatible`, `completeOpenAICompatible`) now set
`reasoning_effort: 'minimal'` alongside `max_completion_tokens` for every
GPT-5-family branch.
