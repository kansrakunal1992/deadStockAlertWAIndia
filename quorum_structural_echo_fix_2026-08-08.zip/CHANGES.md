# Quorum — structural echo retroactive-enrichment fix (2026-08-08, round 2)

Builds on `quorum_ratelimit_fixes_2026-08-08.zip` — this zip contains only what's new/changed *since* that one. 1 new file, 4 changed files. Same relative paths as your project root.

## Why: the actual bug, not a threshold problem
`/api/structural-match`'s result depends on the current session's ontology tagging finishing first, then a scoring pass — a real pipeline with real latency. Persona initial calls fire almost immediately on mount, gated only on `canStream`/`panelState`, with nothing checking structural-match readiness. Structural context is only ever injected on a persona's *initial* call (`messages.length === 0`) — pushback replies exclude it, and there's no other injection point. So if `structuralContext` arrives after a persona's initial call already fired — the normal case, not an edge case — that persona gets zero structural echo for the rest of the session, permanently, even with a great match sitting in the database. `MATCH_THRESHOLD`/`MIN_SESSIONS` are fine as configured; this is a timing bug, not a tuning problem.

## The fix: catch it after the fact, never block the critical path
No latency added anywhere on the existing path — personas still fire exactly when they do today. Once `structuralContext` actually arrives (whenever that is), the client checks whether a structural-eligible persona's already-completed response lacks a `<structural>` tag, and if so makes one small follow-up call asking the model, using its own original response as context, whether the now-available match genuinely applies to its specific angle. If yes, the citation gets appended. If no — or if anything fails — nothing changes from current behavior. Purely additive.

## New file
### `app/api/persona/structural-enrich/route.ts`
Takes `{ sessionId, personaKey, originalResponse, structuralContext }`, returns `{ structuralTag: string | null }`. Validates persona eligibility and absence of an existing tag server-side too (defense in depth, not just trusting the client check). Any failure is swallowed and returns `{ structuralTag: null }` — this is an additive feature, so a failure here must never surface as an error to the person using the product. Rate-limited via a new `LIMITS.structuralEnrich` entry (same budget as `structuralMatch` — bounded the same way, at most one call per eligible persona per session). Matched by `middleware.ts`'s existing `/api/persona/:path*` pattern automatically, so it inherits correct `x-product-tier` handling with zero extra wiring.

## Changed files

### `lib/structural-dims.ts`
`PERSONAS_WITH_STRUCTURAL_CONTEXT` and `getPersonaStructuralDirective` moved here from `lib/structural-retrieval.ts` — same fix, same reasoning, same file this codebase already used once for `VECTOR_DIMS`/`DIM_LABELS`: pure data, but `structural-retrieval.ts` imports `lib/ai-client.ts` (server-only), so nothing from that file can be imported into a client component without pulling that whole chain in and failing the build. `components/PersonaPanel.tsx` needs the eligibility set client-side now.

### `lib/structural-retrieval.ts`
The two moved items replaced with a re-export from `structural-dims.ts` — every existing server-side importer (`app/api/persona/route.ts` included) keeps working unchanged.

### `lib/rate-limit.ts`
Added the `structuralEnrich` entry to `LIMITS`.

### `components/PersonaPanel.tsx`
New import of `PERSONAS_WITH_STRUCTURAL_CONTEXT`. New effect (placed right after the existing examiner-update effect) that fires the retroactive enrichment call — guarded by a ref so it only ever attempts once per mount, only for eligible personas, only once `panelState === 'done'` and `structuralContext` is actually present, only if no `<structural>` tag already exists. On success, updates the citation badge state and persists through the same `rawInitialRef` + `onComplete` path pushback/examiner updates already use, so a reload still shows it.

## Verified before packaging
- Type-checked the full project against `tsconfig.json` — zero errors in any of these 5 items' line ranges (remaining errors project-wide are the same pre-existing missing-`node_modules` noise as before, confirmed by isolated before/after comparison on `PersonaPanel.tsx` specifically: identical error-type distribution, no new category introduced).
- Confirmed `lib/structural-dims.ts` resolves correctly via the `@/` path alias in the full project compile (not just in isolation).
- Confirmed `app/api/persona/route.ts`'s existing import of `PERSONAS_WITH_STRUCTURAL_CONTEXT`/`getPersonaStructuralDirective` from `structural-retrieval.ts` still resolves via the new re-export — that file itself needed no changes.
