// app/privacy/page.tsx
// ── Sprint 3 (S3-01) — Privacy Policy ────────────────────────────────────────
// Server component — no interactivity, fully static.
// Content is accurate to what Quorum actually does today.
// No aspirational claims. Legal basis per GDPR + DPDP (India).
// ─────────────────────────────────────────────────────────────────────────────

import Link from 'next/link'

export const metadata = {
  title: 'Privacy Policy — Quorum',
  description: 'How Quorum collects, uses, and protects your personal data.',
}

export default function PrivacyPolicyPage() {
  return (
    <main style={{
      minHeight: '100vh',
      background: 'var(--bg-void)',
      padding: '48px 20px 96px',
    }}>
      <div style={{ maxWidth: 720, margin: '0 auto' }}>

        {/* Back link */}
        <Link href="/" style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          fontSize: 11, color: 'var(--text-4)',
          fontFamily: 'var(--font-mono)', letterSpacing: '0.08em',
          textDecoration: 'none', marginBottom: 36,
        }}>
          ← Back to Quorum
        </Link>

        {/* Header */}
        <div style={{ marginBottom: 40 }}>
          <p style={{
            fontFamily: 'var(--font-mono)', fontSize: 10,
            letterSpacing: '0.18em', textTransform: 'uppercase',
            color: 'var(--text-4)', margin: '0 0 12px',
          }}>
            Legal
          </p>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(28px, 4vw, 42px)',
            fontWeight: 400, letterSpacing: '-0.02em',
            color: 'var(--text-1)', margin: '0 0 12px', lineHeight: 1.15,
          }}>
            Privacy Policy
          </h1>
          <p style={{
            fontFamily: 'var(--font-mono)', fontSize: 11,
            color: 'var(--text-4)', letterSpacing: '0.06em',
            margin: 0,
          }}>
            Effective 14 August 2026 · Version 1.1
          </p>
        </div>

        <hr style={{ border: 'none', borderTop: '1px solid var(--border-dim)', marginBottom: 40 }} />

        <ProseBody>

          <Lead>
            Quorum is a private decision intelligence tool. We take the confidentiality of your
            decisions seriously. This policy explains exactly what data we collect, why we collect it,
            how it is protected, and what rights you have over it.
          </Lead>

          <Section title="1. Data we collect">
            <p>We collect only what is necessary to provide the service:</p>
            <Table rows={[
              ['Account data', 'Your email address, collected when you sign in with Google or via a magic link.'],
              ['Decision data', 'The decision text you submit and any register-mode answers you provide before Council analysis.'],
              ['Analysis data', 'AI-generated responses from persona analysis, synthesis, and the follow-up question diagnostic. These are stored so you can return to a session.'],
              ['Behavioural data', 'Bias scores, calibration records, decision patterns, and independence metrics derived from your decisions over time. This data compounds to form your decision profile in the Mirror module.'],
              ['Context Ingestion data (Elite)', 'If you import context via Mirror — a pasted description or a ChatGPT/Claude export — the file or text is processed in memory to extract a handful of distilled insights, which you review and approve before anything is saved. The raw import is never stored.'],
              ['Technical data', 'An anonymous device identifier (generated on your device, gated behind functional cookie consent), session identifiers, and server-side request logs including IP address and user agent.'],
              ['Website enquiry data', 'If you request early access via our public website, your name, email, WhatsApp number, and the decision context you provide.'],
            ]} />
          </Section>

          <Section title="2. Legal basis for processing">
            <Table rows={[
              ['Contract', 'Creating and delivering a Council session, linking sessions to your account, and providing subscribed features.'],
              ['Legitimate interests', 'Maintaining anonymous session access, improving reliability and product quality, and detecting abuse.'],
              ['Consent', 'Functional cookies (device ID, session history). You may withdraw consent at any time via the Privacy Center in Settings.'],
            ]} />
          </Section>

          <Section title="3. AI processing">
            <p>
              When you submit a decision for Council analysis, your decision text is transmitted to an
              AI processing service to generate the analysis. The AI provider processes your data solely
              to generate the response and does not use your submissions to train its models.
            </p>
            <p>
              Analysis generated by AI is for informational and reflective purposes only. It does not
              constitute legal, financial, medical, or investment advice. You retain full responsibility
              for the decisions you make.
            </p>
          </Section>

          <Section title="4. Third-party processors">
            <p>
              We share data with the following processors only to the extent necessary to operate the service.
              We do not sell your data to any third party.
            </p>
            <Table rows={[
              ['Supabase', 'Database and authentication (PostgreSQL, magic link auth). Hosted in the United States. See supabase.com/privacy.'],
              ['Railway', 'Application hosting and deployment. Hosted in the United States. See railway.app/legal/privacy.'],
              ['OpenAI', 'Generates fast-role Council analysis on the Free and Elite plans. Hosted in the United States. See openai.com/privacy.'],
              ['Anthropic', "Generates Quorum's deepest analysis — Council Synthesis, Mirror, and long-term pattern-reading — on the Elite plan. Hosted in the United States. See anthropic.com/privacy."],
              ['Google Fonts', 'Loads typefaces used in the interface. No personal data is transmitted beyond standard browser request metadata. See policies.google.com/privacy.'],
            ]} />
            <p style={{ marginTop: 10 }}>
              No China-based AI provider is used on the Free or Elite plans. If you're on the
              Private plan, your decisions are processed entirely on infrastructure you control —
              no third-party AI processor receives your data at all.
            </p>
          </Section>

          <Section title="5. Data retention">
            <Table rows={[
              ['Authenticated sessions', 'Retained until you delete your account or request erasure.'],
              ['Anonymous sessions', 'Retained for 90 days if not linked to an account. Linking a session to an account converts it to account-scoped retention.'],
              ['Bias and behavioural profiles', 'Retained while your account is active. Deleted on account erasure.'],
              ['Context Ingestion imports', 'The raw imported file or text is never stored — it is discarded immediately after the distilled insights are extracted. Only the insights you approve are retained, as part of your behavioural profile.'],
              ['Authentication tokens', 'Expire per the Supabase session defaults. You may invalidate all sessions via Settings → Security Center.'],
              ['Server logs', 'Standard infrastructure logs retained for up to 30 days.'],
            ]} />
          </Section>

          <Section title="6. Data security">
            <p>
              Decision text and analysis stored in the database is encrypted at rest using AES-256-GCM
              field-level encryption. All data in transit is protected by HTTPS/TLS. Authentication
              uses passwordless magic links — no passwords are stored. Row-level security is enforced
              in the database so each user's data is scoped to their account.
            </p>
            <p>
              For a full account of our technical security measures, see the{' '}
              <Link href="/security" style={{ color: 'var(--gold)', textDecoration: 'none' }}>
                Security &amp; Trust
              </Link>
              {' '}page.
            </p>
          </Section>

          <Section title="7. Your rights">
            <p>
              Under the General Data Protection Regulation (GDPR) and the Digital Personal Data
              Protection Act 2023 (DPDP), you have the following rights:
            </p>
            <Table rows={[
              ['Access', 'Request a copy of the personal data we hold about you.'],
              ['Portability', 'Export your data in a structured, machine-readable format (Article 20 GDPR).'],
              ['Correction', 'Request correction of inaccurate personal data.'],
              ['Erasure', 'Request deletion of your account and all associated personal data ("right to be forgotten", Article 17 GDPR / DPDP Section 13).'],
              ['Withdraw consent', 'Withdraw functional or analytics cookie consent at any time via Settings → Privacy Center. This does not affect the lawfulness of processing before withdrawal.'],
              ['Restriction', 'Request that we restrict processing of your data in certain circumstances.'],
              ['Complaint', 'Lodge a complaint with your supervisory authority (in India: the Data Protection Board; in the EU: your national data protection authority).'],
            ]} />
            <p>
              To exercise any of these rights, use the{' '}
              <Link href="/settings/privacy" style={{ color: 'var(--gold)', textDecoration: 'none' }}>
                Privacy Center
              </Link>
              {' '}in app Settings. Data export and account deletion are available there.
            </p>
          </Section>

          <Section title="8. Cookies and local storage">
            <p>
              Quorum uses browser local storage (not traditional HTTP cookies) to persist preferences
              and session data on your device. For a full list of every key stored, its purpose, and
              how to manage it, see the{' '}
              <Link href="/cookies" style={{ color: 'var(--gold)', textDecoration: 'none' }}>
                Cookie Policy
              </Link>.
            </p>
          </Section>

          <Section title="9. Children">
            <p>
              Quorum is intended for professionals and individuals making significant personal or
              business decisions. We do not knowingly collect data from anyone under the age of 18.
            </p>
          </Section>

          <Section title="10. Changes to this policy">
            <p>
              We will post any material changes here and update the effective date. Continued use of
              Quorum after changes constitutes acceptance of the revised policy.
            </p>
          </Section>

          <Section title="11. Contact">
            <p>
              To exercise your data rights or raise a privacy concern, use the{' '}
              <Link href="/settings/privacy" style={{ color: 'var(--gold)', textDecoration: 'none' }}>
                Privacy Center
              </Link>
              {' '}in Settings.
              We aim to respond to all data rights requests within 30 days.
            </p>
          </Section>

        </ProseBody>
      </div>
    </main>
  )
}

// ── Shared layout helpers ────────────────────────────────────────────────────

function ProseBody({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: 14, color: 'var(--text-2)', lineHeight: 1.85,
      fontFamily: 'var(--font-body)',
    }}>
      {children}
    </div>
  )
}

function Lead({ children }: { children: React.ReactNode }) {
  return (
    <p style={{
      fontSize: 15, color: 'var(--text-2)', lineHeight: 1.8,
      marginBottom: 36, borderLeft: '2px solid var(--gold-dim)',
      paddingLeft: 16,
    }}>
      {children}
    </p>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={{ marginBottom: 40 }}>
      <h2 style={{
        fontSize: 13, fontWeight: 600, color: 'var(--text-1)',
        fontFamily: 'var(--font-body)', letterSpacing: '0.01em',
        margin: '0 0 14px', paddingBottom: 8,
        borderBottom: '1px solid var(--border-dim)',
      }}>
        {title}
      </h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {children}
      </div>
    </section>
  )
}

function Table({ rows }: { rows: [string, string][] }) {
  return (
    <div style={{
      border: '1px solid var(--border-dim)',
      borderRadius: 10, overflow: 'hidden',
      marginTop: 4,
    }}>
      {rows.map(([label, value], i) => (
        <div key={i} style={{
          display: 'grid',
          gridTemplateColumns: '180px 1fr',
          gap: 0,
          borderTop: i > 0 ? '1px solid var(--border-dim)' : 'none',
          background: i % 2 === 0 ? 'var(--bg-card)' : 'var(--bg-card-alt)',
        }}>
          <div style={{
            padding: '11px 14px',
            fontSize: 12, fontWeight: 600, color: 'var(--text-2)',
            borderRight: '1px solid var(--border-dim)',
            fontFamily: 'var(--font-body)',
          }}>
            {label}
          </div>
          <div style={{
            padding: '11px 14px',
            fontSize: 13, color: 'var(--text-3)', lineHeight: 1.6,
          }}>
            {value}
          </div>
        </div>
      ))}
    </div>
  )
}
