'use client'
// components/AuthPanel.tsx
// ── Sprint 6 + 6b: Magic Link Auth Panel ─────────────────────────────────────
//
// Sprint 6b change: handleSend now passes deviceId + sessionIds to /api/auth.
// The auth route embeds them into the magic link's emailRedirectTo URL so the
// callback can recover them even when clicked in a different browser where
// localStorage is empty.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useState } from 'react'
import { getOrCreateDeviceId, getStoredSessionIds, captureUtm, getStoredUtm } from '@/lib/storage'
import GoogleSignInButton from '@/components/GoogleSignInButton'
import { trackMetaEvent } from '@/lib/meta-pixel'

interface Props {
  userEmail: string | null
  onAuthenticated?: (email: string) => void
}

// 'wrong_provider' — Sprint 12: this email is locked to Google; magic link
// send was skipped server-side and we show a redirect prompt instead.
type AuthState = 'idle' | 'sending' | 'sent' | 'error' | 'wrong_provider'

export default function AuthPanel({ userEmail, onAuthenticated }: Props) {
  const [email,     setEmail]     = useState('')
  const [authState, setAuthState] = useState<AuthState>('idle')
  const [errMsg,    setErrMsg]    = useState('')

  // Meta Pixel: ViewContent — fires once when this panel mounts for a
  // signed-out visitor, i.e. the moment someone actually reaches the
  // free-tier signup UI (not on every render — empty dep array, mount only).
  // Skipped entirely when userEmail is already set, since that branch below
  // never shows the signup form at all.
  useEffect(() => {
    if (!userEmail) {
      trackMetaEvent('ViewContent', { content_name: 'Quorum Free Tier' })
      // GTM attribution: snapshot ?utm_source/campaign/content the moment
      // this panel is shown, so it survives even if the user browses
      // around a bit before actually signing up. No-op if no consent yet
      // or no utm params present — see lib/storage.ts.
      captureUtm()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Already authenticated — show compact identity pill
  if (userEmail) {
    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '8px 14px',
        background: 'var(--success-bg)',
        border: '1px solid var(--success-border)',
        borderRadius: 10,
        marginTop: 12,
      }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--success-text)', flexShrink: 0 }} />
        <span style={{ fontSize: 11, color: 'var(--text-3)' }}>
          Sessions linked to <span style={{ color: 'var(--text-2)', fontWeight: 600 }}>{userEmail}</span>
          {' · '}cross-device history active
        </span>
      </div>
    )
  }

  const handleSend = async () => {
    if (!email.trim() || !email.includes('@')) {
      setErrMsg('Enter a valid email address.')
      return
    }
    setErrMsg('')
    setAuthState('sending')

    try {
      // ── Sprint 6b: embed device identity in the magic link ────────────────
      // getOrCreateDeviceId() reads quorum_device_id from localStorage (creating it if missing).
      // getStoredSessionIds() reads quorum_session_ids array.
      // These are passed to /api/auth which embeds them as ?xd=…&xs=… params in
      // the emailRedirectTo URL. The callback page reads them from the URL, so
      // link-sessions works even when clicked in a different browser with empty localStorage.
      const deviceId   = getOrCreateDeviceId()
      const sessionIds = getStoredSessionIds()
      const utm        = getStoredUtm() // ← NEW: first-touch GTM attribution

      const res = await fetch('/api/auth', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          email:      email.trim().toLowerCase(),
          deviceId,                    // ← NEW: quorum_device_id from this browser
          sessionIds,                  // ← NEW: all session IDs from this browser
          utmSource:   utm.utm_source,   // ← NEW: GTM attribution
          utmCampaign: utm.utm_campaign, // ← NEW
          utmContent:  utm.utm_content,  // ← NEW
        }),
      })

      // Sprint 12: this email is locked to Google — no link was sent.
      if (res.status === 409) {
        const body = await res.json().catch(() => ({}))
        if (body.error === 'wrong_provider') {
          setAuthState('wrong_provider')
          return
        }
      }

      if (!res.ok) throw new Error()
      setAuthState('sent')
      // NOTE: Do NOT call onAuthenticated here — the user has not clicked the link yet.
      // onAuthenticated fires after /auth/callback completes and storeUserEmail runs.
    } catch {
      setAuthState('error')
      setErrMsg('Failed to send link. Try again.')
    }
  }

  if (authState === 'wrong_provider') {
    return (
      <div style={{
        padding: '16px 18px',
        background: 'rgba(201,168,76,0.06)',
        border: '1px solid rgba(201,168,76,0.3)',
        borderRadius: 14,
        marginTop: 12,
      }}>
        <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 10, lineHeight: 1.5 }}>
          <span style={{ fontWeight: 600 }}>{email}</span> signed up with Google — use that to get back in rather than a link.
        </p>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <GoogleSignInButton variant="compact" />
          <button
            onClick={() => { setAuthState('idle'); setEmail('') }}
            style={{
              fontSize: 11, color: 'var(--text-4)', background: 'none', border: 'none',
              cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 2, padding: 0,
            }}
          >
            Wrong email?
          </button>
        </div>
      </div>
    )
  }

  if (authState === 'sent') {
    return (
      <div style={{
        padding: '20px 20px 18px',
        background: 'rgba(201,168,76,0.06)',
        border: '1px solid rgba(201,168,76,0.3)',
        borderRadius: 14,
        marginTop: 12,
      }}>
        {/* Pulsing envelope icon */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <div style={{
            width: 38, height: 38, borderRadius: '50%',
            background: 'rgba(201,168,76,0.1)',
            border: '1px solid rgba(201,168,76,0.35)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
            animation: 'auth-pulse 2.2s ease-in-out infinite',
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="4" width="20" height="16" rx="2"/>
              <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
            </svg>
          </div>
          <div>
            <p style={{ fontSize: 13, color: 'var(--gold)', fontWeight: 700, marginBottom: 1, lineHeight: 1.3 }}>
              Open your inbox now
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-4)', margin: 0, lineHeight: 1.4 }}>
              Sent to <span style={{ color: 'var(--text-2)', fontWeight: 600 }}>{email}</span>
            </p>
          </div>
        </div>

        {/* Step-by-step instruction */}
        <div style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border-dim)',
          borderRadius: 10,
          padding: '12px 14px',
          marginBottom: 12,
        }}>
          {[
            { n: '1', text: 'Go to your email inbox' },
            { n: '2', text: 'Find the email from Quorum — click the magic link inside' },
            { n: '3', text: 'You\'ll be returned here with your sessions linked' },
          ].map(step => (
            <div key={step.n} style={{
              display: 'flex', gap: 10, alignItems: 'flex-start',
              paddingBottom: step.n === '3' ? 0 : 8,
              marginBottom: step.n === '3' ? 0 : 8,
              borderBottom: step.n === '3' ? 'none' : '1px solid var(--border-dim)',
            }}>
              <span style={{
                width: 18, height: 18, borderRadius: '50%',
                background: 'rgba(201,168,76,0.15)',
                border: '1px solid rgba(201,168,76,0.3)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, fontWeight: 700, color: 'var(--gold)',
                flexShrink: 0, marginTop: 1,
              }}>{step.n}</span>
              <span style={{ fontSize: 12, color: 'var(--text-3)', lineHeight: 1.5 }}>{step.text}</span>
            </div>
          ))}
        </div>

        {/* Waiting indicator + resend */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 11, color: 'var(--text-5)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{
              display: 'inline-block', width: 6, height: 6, borderRadius: '50%',
              background: 'var(--gold)', opacity: 0.6,
              animation: 'auth-pulse 1.8s ease-in-out infinite',
            }} />
            Waiting for you to click the link…
          </span>
          <button
            onClick={() => { setAuthState('idle'); setEmail('') }}
            style={{
              fontSize: 11, color: 'var(--text-4)', background: 'none', border: 'none',
              cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 2,
              padding: 0, transition: 'color 0.15s',
            }}
          >
            Wrong email?
          </button>
        </div>

        <style>{`
          @keyframes auth-pulse {
            0%, 100% { opacity: 0.5; transform: scale(1); }
            50%       { opacity: 1;   transform: scale(1.12); }
          }
        `}</style>
      </div>
    )
  }

  return (
    <div style={{
      padding: '14px 18px',
      background: 'var(--bg-card)',
      border: '1px solid var(--border-dim)',
      borderRadius: 12,
      marginTop: 12,
    }}>
      {/* Sprint 12: Google sign-in — offered alongside, not instead of, magic link */}
      <GoogleSignInButton variant="primary" subtext="One click, no email to check" />

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '14px 0' }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border-dim)' }} />
        <span style={{ fontSize: 10, color: 'var(--text-5)' }}>skip Google</span>
        <div style={{ flex: 1, height: 1, background: 'var(--border-dim)' }} />
      </div>

      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 12 }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-4)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 2 }}>
          <rect x="2" y="3" width="20" height="14" rx="2"/><polyline points="8,21 12,17 16,21"/>
        </svg>
        <div>
          <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)', marginBottom: 3 }}>
            Or use a one-time link
          </p>
          <p style={{ fontSize: 11, color: 'var(--text-4)', lineHeight: 1.5, margin: 0 }}>
            Sessions currently live on this device only. Add an email to access them anywhere — no password, just a link.
          </p>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <input
          type="email"
          placeholder="your@email.com"
          value={email}
          onChange={e => setEmail(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          style={{
            flex: 1,
            background: 'var(--bg-inset)',
            border: '1px solid var(--border-mid)',
            borderRadius: 8,
            padding: '8px 12px',
            fontSize: 12,
            color: 'var(--text-1)',
            fontFamily: 'inherit',
            outline: 'none',
          }}
          disabled={authState === 'sending'}
        />
        <button
          onClick={handleSend}
          disabled={authState === 'sending' || !email.trim()}
          style={{
            padding: '8px 16px',
            background: 'rgba(201,168,76,0.12)',
            border: '1px solid var(--gold-dim)',
            borderRadius: 8,
            color: 'var(--gold)',
            fontSize: 12,
            fontWeight: 600,
            fontFamily: 'inherit',
            cursor: authState === 'sending' ? 'not-allowed' : 'pointer',
            opacity: authState === 'sending' || !email.trim() ? 0.5 : 1,
            whiteSpace: 'nowrap',
            transition: 'opacity 0.15s',
          }}
        >
          {authState === 'sending' ? 'Sending…' : 'Send link →'}
        </button>
      </div>

      {errMsg && (
        <p style={{ fontSize: 11, color: '#e05050', marginTop: 6, margin: '6px 0 0' }}>{errMsg}</p>
      )}

      {/* S2-05 — Terms acknowledgement at point of account creation */}
      <p style={{
        fontSize: 10.5,
        color: 'var(--text-4)',
        margin: '10px 0 0',
        lineHeight: 1.55,
        fontFamily: 'var(--font-body)',
      }}>
        By continuing you agree to our{' '}
        <a href="/terms" style={{ color: 'var(--text-3)', textDecoration: 'underline', textUnderlineOffset: 2 }}>
          Terms of Service
        </a>
        {' '}and{' '}
        <a href="/privacy" style={{ color: 'var(--text-3)', textDecoration: 'underline', textUnderlineOffset: 2 }}>
          Privacy Policy
        </a>.
      </p>
    </div>
  )
}
