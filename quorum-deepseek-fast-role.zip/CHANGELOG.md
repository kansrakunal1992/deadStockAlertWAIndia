# DeepSeek v4 Pro as a fast-role provider option

## Changed
- `lib/ai-client.ts`

## What changed
Added `FAST_MODEL_PROVIDER=deepseek` as a fourth candidate for the tiered
routing "fast" role (alongside the existing `mistral` / `openai` / `gemini`),
following the exact pattern already used for the GPT-5 mini / Gemini 2.5
Flash additions:

- New `ResolvedTarget` kind: `'deepseek-fast'` — kept distinct from the
  existing `'deepseek-legacy'` kind (which backs `AI_PROVIDER=deepseek`,
  `ROUTING_MODE=deepseek_only`, and the `deepseek` per-user route override).
- `resolveFastCloudTarget()` now returns `deepseek-fast` when
  `FAST_MODEL_PROVIDER=deepseek`. Since this is the single choke point both
  Free (end-to-end) and Elite's fast role call through, setting the env var
  moves both tiers together, same as the other three candidates.
- Thinking mode is **hardcoded to `'disabled'`** for this target — not read
  from the `DEEPSEEK_THINKING` env var. Reasoning: thinking mode adds latency
  and silently disables temperature sampling, both wrong for a role whose
  entire point is speed. Hardcoding also means flipping `DEEPSEEK_THINKING`
  for the legacy/hybrid path's own testing can never accidentally slow down
  this fast role too — the two paths are fully decoupled.
- Model name comes from the existing `DEEPSEEK_MODEL` env var, which already
  defaults to `deepseek-v4-pro` — no new env var needed for the model name
  itself.
- Wired into every place that switches on `ResolvedTarget.kind`:
  `createCompletion`, `createStream`, `getModelFamily`, `describeTarget`
  (console logging), `modelForTarget` (audit log). No admission-control
  queue (matches `openai-fast`/`gemini-fast` — DeepSeek's rate ceiling is
  well above this app's call volume; reactive 429 retry via `withRetry`
  already covers it).
- Updated the file's doc comment (env var table + `FAST_MODEL_PROVIDER`
  section) to document the new option and the thinking-hardcoded behavior.

## How to use it
Set `FAST_MODEL_PROVIDER=deepseek` (with `TIERED_ROUTING_ENABLED=true`) to
route Free tier end-to-end and Elite's fast role to DeepSeek v4 Pro with
thinking off. Everything else (legacy hybrid routing, the deepseek_only
tester path, the per-user `deepseek` route override) is untouched.

## Verification
No `node_modules` in this environment (network disabled), so a full project
`tsc` build wasn't possible. Verified instead by:
- Isolated `tsc --noEmit` on the file (clean aside from expected
  "Cannot find module" / missing `@types/node` noise from the missing
  `node_modules` — no syntax or type errors from the new code).
- Grepped every `switch` over `ResolvedTarget.kind` / `t.kind` in the file
  (5 total) and confirmed all 5 now handle `'deepseek-fast'`.
- Confirmed no other file in the codebase matches on `ResolvedTarget.kind`.
