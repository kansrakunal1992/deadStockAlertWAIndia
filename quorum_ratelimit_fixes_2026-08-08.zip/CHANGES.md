# Quorum — rate-limit + tag fixes (2026-08-08)

4 files changed, 0 new files, 0 deletions. Same relative paths as your project root — copy these over the matching files.

## `lib/mistral-limiter.ts`
- Updated `MISTRAL_RPS` / `MISTRAL_TPM` fallback defaults: `0.83` → `1.67`, `50000` → `100000`, matching the admin dashboard increase. (If you already set `MISTRAL_RPS`/`MISTRAL_TPM` as env vars in your deployment, this change is inert there — it only matters for any environment without those set.)
- Corrected two doc comments whose math was stale relative to the old limits (`MIN_INTERVAL_MS` rationale, `MAX_QUEUE_WAIT_MS` rationale).

## `lib/personas.ts`
- **Step B**: `WORD_LIMIT_PREFIX` condensed ~25% (six review passes checking every rule/example against the original — see the comment directly above the constant).
- **Step A**: `PUSHBACK_DETECTION_PREFIX` is now `export`ed. Two new constants added — `WORD_LIMIT_SUFFIX_CORE` (always sent) and `PUSHBACK_PROTOCOL_ADDENDUM` (exported, sent only on actual pushback replies). `WORD_LIMIT_SUFFIX` itself is untouched, byte-identical, left in place specifically so `tests/persona-tag-wiring-guardrail.test.ts`'s literal source-text scan still finds it — verified by hand-simulating that test's exact logic against this file (all markers found, all required tags present, see chat for the check).
- All 6 `PERSONAS[...].prompt` entries updated to build from `WORD_LIMIT_SUFFIX_CORE` instead of `WORD_LIMIT_SUFFIX`, and no longer prepend `PUSHBACK_DETECTION_PREFIX` (that's now conditional, done in `route.ts`).

## `app/api/persona/route.ts`
- Imports `PUSHBACK_DETECTION_PREFIX` and `PUSHBACK_PROTOCOL_ADDENDUM` from `lib/personas`.
- `basePrompt` now conditionally prepends `PUSHBACK_DETECTION_PREFIX` when `pushbackText` is present (same condition the existing dynamic `pushbackProtocol` variable already used) — was unconditional before.
- Final `systemPrompt` assembly now conditionally appends `PUSHBACK_PROTOCOL_ADDENDUM` on the same condition.
- **Bug fix**: synthesis backfill generalized from action_plan-only to all four mandatory tags (`verdict`, `tension`, `key_question`, `action_plan`) — each with its own tag-specific backfill prompt. Previously `<tension>` going missing (confirmed in your logs, session `5b63b9fb`, alongside `action_plan`) had zero recovery path.

## `middleware.ts`
- **Bug fix**: the no-Bearer-token branch now explicitly sets `x-product-tier: free` before forwarding, instead of leaving the header unset. This was causing `lib/ai-client.ts`'s "no x-product-tier header" warning to fire on every single anonymous request — identical to what a genuine paid-tier resolution failure logs — making that warning useless as a signal. Confirmed via your logs: every AIClient call in one ordinary anonymous free-tier session logged it.

## Verified before packaging
- Hand-simulated `tests/persona-tag-wiring-guardrail.test.ts`'s exact marker-search + tag-extraction logic against the modified `lib/personas.ts` — passes.
- Type-checked both edited `.ts`/`.tsx`-adjacent files against your `tsconfig.json` — zero errors attributable to these changes (remaining errors across the project are pre-existing missing-`node_modules` noise from this being a fresh checkout, unrelated to this diff).

## Not included in this zip
- Structural echo timing fix — see chat for the proposed approach; not implemented yet, pending your go-ahead on the design.
