import { describe, it, expect, expectTypeOf } from 'vitest'
import {
  EMPTY_COUNCIL_CONTEXT,
  type CouncilContext,
} from '@/app/api/persona/route'
import {
  EMPTY_USER_BIAS_CONTEXT,
  type UserBiasContext,
} from '@/lib/bias-scorer'

// Sprint TB1 (June 2026) — regression test for the bug class behind the
// diligence report's third logged incident: a return-type shape extended with
// new optional fields in three places, where exactly one of several
// hand-typed fallback object literals elsewhere in the codebase was missed on
// first deploy. TypeScript's structural typing does not flag an *omitted*
// field on a fresh object literal the way it flags other mismatches, until
// that literal is used somewhere the compiler can narrow against — which is
// precisely how the original bug slipped past `git apply --check` and a
// passing local build.
//
// The fix (this sprint) was to hoist both shapes to one named interface +
// one exported constant each, used at every fallback site instead of being
// retyped. These tests exist to keep that property true going forward: if a
// future field is added to either interface without updating the constant
// (or vice versa via a stray `as` cast that bypasses the compiler), the
// runtime key-set assertions below catch it even in a context where the
// compile-time check was somehow circumvented.

describe('CouncilContext / EMPTY_COUNCIL_CONTEXT shape contract', () => {
  it('EMPTY_COUNCIL_CONTEXT satisfies the CouncilContext type', () => {
    expectTypeOf(EMPTY_COUNCIL_CONTEXT).toMatchTypeOf<CouncilContext>()
  })

  it('EMPTY_COUNCIL_CONTEXT has exactly the 7 fields CouncilContext declares — no more, no fewer', () => {
    // This is the runtime backstop for the compile-time check above. A field
    // added to the interface but not the constant (or a stray `as CouncilContext`
    // cast on a partial object) would pass a naive "has these keys" check but
    // fail this exact-match assertion.
    const expectedKeys = [
      'councilContextStr',
      'ontologyVector',
      'userId',
      'ruleEngineResult',
      'maxStructuralScore',
      'decisionTypePrimary',
      'dominantEmotion',
    ].sort()
    expect(Object.keys(EMPTY_COUNCIL_CONTEXT).sort()).toEqual(expectedKeys)
  })

  it('every field on EMPTY_COUNCIL_CONTEXT is null (true empty state, not a partial default)', () => {
    // Guards against someone "fixing" a future missing-field bug by filling
    // in a non-null placeholder instead of null — which would silently change
    // what every fallback call site in app/api/persona/route.ts means.
    for (const [key, value] of Object.entries(EMPTY_COUNCIL_CONTEXT)) {
      expect(value, `expected ${key} to be null in the empty-state constant`).toBeNull()
    }
  })
})

describe('UserBiasContext / EMPTY_USER_BIAS_CONTEXT shape contract', () => {
  it('EMPTY_USER_BIAS_CONTEXT satisfies the UserBiasContext type', () => {
    expectTypeOf(EMPTY_USER_BIAS_CONTEXT).toMatchTypeOf<UserBiasContext>()
  })

  it('EMPTY_USER_BIAS_CONTEXT has exactly the 5 fields UserBiasContext declares', () => {
    const expectedKeys = [
      'synthesisBlock',
      'personaAlert',
      'hasAnyBiases',
      'personalCalibrationZones',
      'personalBiasTriggers',
    ].sort()
    expect(Object.keys(EMPTY_USER_BIAS_CONTEXT).sort()).toEqual(expectedKeys)
  })

  it('empty-state scalar/array fields match their documented defaults', () => {
    // synthesisBlock is '' (not null) and the array fields are [] (not null) —
    // unlike CouncilContext, this shape's "empty" isn't all-null by design
    // (synthesis directly string-concatenates synthesisBlock, and the two
    // array fields are iterated directly by persona-relevance.ts /
    // mirror-fingerprint.ts without an upstream null check). A regression
    // here (e.g. a future field defaulting to null instead of []) would crash
    // a .map()/.length call downstream rather than failing loudly at the
    // source — exactly the kind of bug this shape-contract test is meant to
    // catch close to where it's introduced.
    expect(EMPTY_USER_BIAS_CONTEXT.synthesisBlock).toBe('')
    expect(EMPTY_USER_BIAS_CONTEXT.personaAlert).toBeNull()
    expect(EMPTY_USER_BIAS_CONTEXT.hasAnyBiases).toBe(false)
    expect(EMPTY_USER_BIAS_CONTEXT.personalCalibrationZones).toEqual([])
    expect(EMPTY_USER_BIAS_CONTEXT.personalBiasTriggers).toEqual([])
  })
})
