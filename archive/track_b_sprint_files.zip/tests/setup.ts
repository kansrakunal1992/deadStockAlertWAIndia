import { vi } from 'vitest'

// Sprint TB1 (June 2026).
//
// lib/ai-client.ts and lib/encryption.ts both now `import 'server-only'` as a
// build-time guard against client-bundle leakage (see those files for the
// incident this targets). In a real Next.js server bundle, that import
// resolves to a no-op via the `react-server` package-export condition; Next's
// bundler sets that condition for server code and the package's `index.js`
// (which throws unconditionally) is never reached.
//
// Vitest's default Node module resolution does not set that condition, so
// without this mock, importing anything that transitively reaches
// lib/ai-client.ts or lib/encryption.ts (e.g. lib/bias-scorer.ts,
// lib/calibration-engine.ts, app/api/persona/route.ts) would throw on import
// in every test — not because of a real bug, just because the test runner
// isn't a Next.js server bundle. This mock makes 'server-only' a true no-op
// for the test run, matching its real behaviour in production.
vi.mock('server-only', () => ({}))
