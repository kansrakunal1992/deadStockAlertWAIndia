import { describe, it, expect } from 'vitest'
import { evaluateRules, buildCouncilContext, type RuleEngineResult } from '@/lib/rule-engine'
import { computePersonaRelevance, type AdvisorKey } from '@/lib/persona-relevance'
import type { ScoredVector, DimensionScore } from '@/lib/ontology-tagger'
import type { OntologyScoreMap } from '@/lib/bias-scorer'

// Sprint TB1 (June 2026) — deterministic-logic coverage for the parts of the
// council→synthesis chain that run with no LLM call: lib/rule-engine.ts
// (R1–R12) and lib/persona-relevance.ts (the Council Weighting Directive).
// Deliberately does NOT touch lib/ai-client.ts's actual model calls — that
// needs live API keys and isn't the gap this scaffold targets. The gap the
// diligence report flagged was the wiring around the model calls (a missing
// end-to-end test exercising this exact chain), not the model output itself.

// ── Fixture helper ────────────────────────────────────────────────────────
// All 14 dimensions default to a neutral score (3) at high confidence (0.9)
// so no rule fires unless a test explicitly overrides the dimension(s) it's
// targeting. Keeps each test's intent legible — only the overridden fields
// are relevant to what's being asserted.
function dim(score: 1 | 2 | 3 | 4 | 5, confidence = 0.9): DimensionScore {
  return { score, confidence, rationale: 'fixture' }
}

function neutralVector(overrides: Partial<ScoredVector> = {}): ScoredVector {
  return {
    reversibility:                dim(3),
    time_horizon:                 dim(3),
    stakes_magnitude:             dim(3),
    outcome_uncertainty:          dim(3),
    value_conflict:               dim(3),
    identity_alignment:           dim(3),
    regret_asymmetry:             dim(3),
    upstream_dependency:          dim(3),
    ambiguity:                    dim(3),
    task_complexity:              dim(3),
    decision_discriminating_info: dim(3),
    time_pressure:                dim(3),
    decision_unit:                dim(3),
    emotional_intensity:          dim(3),
    vector_version: 'v2.0',
    ...overrides,
  }
}

describe('evaluateRules — mode hierarchy and confidence guard', () => {
  it('a fully neutral vector triggers nothing and resolves to OPEN', () => {
    const result = evaluateRules(neutralVector())
    expect(result.mode).toBe('OPEN')
    expect(result.triggered_rules).toHaveLength(0)
    expect(result.flag_rules).toHaveLength(0)
  })

  it('R1 fires REDIRECT at upstream_dependency score 5 with high confidence, and short-circuits all other evaluation', () => {
    // upstream_dependency=5 alone would also be in range to be a high-signal
    // dimension for buildCouncilContext, and reversibility=5 would normally
    // contribute an R9 flag — both are deliberately included here to prove
    // the REDIRECT short-circuit means flag_rules stays empty even though a
    // flag condition is also structurally present in the same vector.
    const vector = neutralVector({
      upstream_dependency: dim(5, 0.9),
      reversibility:        dim(5, 0.9),
    })
    const result = evaluateRules(vector)
    expect(result.mode).toBe('REDIRECT')
    expect(result.triggered_rules).toHaveLength(1)
    expect(result.triggered_rules[0].rule_id).toBe('R1')
    expect(result.flag_rules).toHaveLength(0)
  })

  it('R1 does NOT fire when confidence is below the 0.55 threshold, even at score 5 (Sprint 16b guard)', () => {
    const vector = neutralVector({ upstream_dependency: dim(5, 0.3) })
    const result = evaluateRules(vector)
    expect(result.mode).toBe('OPEN')
    expect(result.triggered_rules.find(r => r.rule_id === 'R1')).toBeUndefined()
  })

  it('R9 (irreversibility) is suppressed when R4 (regret asymmetry) also fires — both address the same axis', () => {
    // R4 fires on regret_asymmetry >= 4 (not suppressed by R2 here, since
    // identity_alignment stays neutral). R9 fires on reversibility >= 4.
    // Per the documented suppression rule, R9 should not appear when R4 does.
    const vector = neutralVector({
      regret_asymmetry: dim(5, 0.9),
      reversibility:     dim(5, 0.9),
    })
    const result = evaluateRules(vector)
    const flagIds = result.flag_rules.map(r => r.rule_id)
    expect(flagIds).toContain('R4')
    expect(flagIds).not.toContain('R9')
  })
})

describe('buildCouncilContext — synthesis-prompt enrichment string', () => {
  it('omits the EXAMINER FLAGS section when no rules triggered', () => {
    const sv = neutralVector()
    const result = evaluateRules(sv)
    const block = buildCouncilContext(sv, result)
    expect(block).not.toContain('EXAMINER FLAGS')
  })

  it('includes EXAMINER FLAGS with the rule id and question when a GATE rule triggers', () => {
    const sv = neutralVector({ identity_alignment: dim(5, 0.9), ambiguity: dim(4, 0.9) })
    const result = evaluateRules(sv)
    expect(result.triggered_rules.some(r => r.rule_id === 'R2')).toBe(true)
    const block = buildCouncilContext(sv, result)
    expect(block).toContain('EXAMINER FLAGS')
    expect(block).toContain('R2 [GATE]')
  })
})

describe('computePersonaRelevance — Council Weighting Directive', () => {
  const ALL_PERSONAS: AdvisorKey[] = [
    'contrarian', 'risk_architect', 'pattern_analyst',
    'stakeholder_mirror', 'elder', 'competitor',
  ]

  it('returns a flat 0.50 baseline for every persona when ruleEngineResult and ontologyVector are both null (KDD 100)', () => {
    // Documented in HANDOVER_DOC: "computePersonaRelevance() fires for
    // synthesis even when councilContext is null ... returns a flat 0.50
    // baseline map ... Do not gate the call on councilContext presence."
    // This test pins that contract.
    const scores = computePersonaRelevance(null, null, null, null)
    for (const persona of ALL_PERSONAS) {
      expect(scores[persona]).toBe(0.50)
    }
  })

  it('boosts risk_architect when R1 is in triggered_rules, leaves uninvolved personas at baseline', () => {
    const ruleEngineResult: RuleEngineResult = {
      mode: 'REDIRECT',
      triggered_rules: [{
        rule_id: 'R1', mode: 'REDIRECT', dimension: 'upstream_dependency',
        score: 5, confidence: 0.9, question: 'fixture', low_confidence: false,
      }],
      flag_rules: [],
      evaluated_at: new Date().toISOString(),
      vector_version: 'v2.0',
    }
    const scores = computePersonaRelevance(ruleEngineResult, null, null, null)
    expect(scores.risk_architect).toBeCloseTo(0.70, 5) // 0.50 base + 0.20 R1 boost
    expect(scores.competitor).toBe(0.50) // R1 has no competitor boost — unaffected
  })

  it('clamps stacked boosts to a ceiling of 1.0', () => {
    // Stack every rule/dimension boost this file maps to elder onto one
    // vector to push well past 1.0 if unclamped, then assert the ceiling holds.
    const sv = neutralVector({
      identity_alignment: dim(5, 0.9),
      value_conflict:     dim(5, 0.9),
      regret_asymmetry:   dim(5, 0.9),
      emotional_intensity: dim(5, 0.9),
      stakes_magnitude:   dim(5, 0.9),
      ambiguity:          dim(4, 0.9), // needed for R2 alongside identity_alignment
    })
    const result = evaluateRules(sv)
    const scores = computePersonaRelevance(result, sv as unknown as OntologyScoreMap, null, null)
    expect(scores.elder).toBeLessThanOrEqual(1.0)
    expect(scores.elder).toBeGreaterThan(0.50) // confirms boosts actually applied, not a no-op
  })
})
