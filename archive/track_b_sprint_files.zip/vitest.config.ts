import { defineConfig } from 'vitest/config'
import tsconfigPaths from 'vite-tsconfig-paths'

// Sprint TB1 (June 2026) — minimal test scaffold.
//
// Scope, deliberately: these tests cover the deterministic, no-LLM-call parts
// of the council→synthesis chain (lib/rule-engine.ts, lib/persona-relevance.ts)
// and the CouncilContext/UserBiasContext shape contracts that the diligence
// report's three logged incidents trace back to. They do NOT call Claude or
// DeepSeek — that needs live API keys and isn't the gap this scaffold targets;
// the gap was the wiring around the model calls, not the model output itself.
//
// Run: npm test (single run) or npm run test:watch (watch mode).
export default defineConfig({
  plugins: [tsconfigPaths()],
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    setupFiles: ['./tests/setup.ts'],
  },
})
