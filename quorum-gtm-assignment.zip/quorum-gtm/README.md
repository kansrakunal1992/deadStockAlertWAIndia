# Quorum — Founder Office / GTM Internship Assignment

Single-file HTML assignment page (`index.html`) plus a 5-line Node server (`server.js`) so it can be deployed on Railway with zero dependencies.

## Deploy on Railway

1. Push this folder to a new GitHub repo (or use `railway up` from this directory with the Railway CLI).
2. In Railway: **New Project → Deploy from GitHub repo** (or run `railway up`).
3. Railway's Nixpacks builder will detect `package.json`, run `npm start`, and serve the page. No environment variables or database needed.
4. Once deployed, share the Railway URL with candidates.

## What to edit before sending this out

- **Submission contact.** The page currently says "export as PDF and send it back to us" without naming an inbox or WhatsApp number, since none was specified. If you want candidates to see exactly where to send it, add a line to the `.meta-row` block in `index.html` (search for `Submission`) — e.g. `hello@quorumvault.org` or a WhatsApp number.
- **Branding.** The wordmark is a plain "Quorum" + a small brass seal mark (no logo file was provided). Swap in a real logo if you have one.

## How it works

- **Everything client-side.** No backend, no database — all answers are written to the candidate's own browser `localStorage` as they type (debounced autosave, plus a periodic fallback save every few seconds), so they can close the tab and return later without losing work.
- **Progress.** A thin top rule and a circular "seal" badge (top-right) track how many of the ~70 tracked fields are filled in.
- **Word/character counters.** The two capped questions in Section II (300 and 250 words) show a live word counter that turns red past the limit; every other long-answer field shows a character count.
- **Export.** "Download PDF" uses html2pdf.js (loaded from cdnjs) to generate and download a formatted PDF directly, styled like a typeset case document rather than a screenshot of the form. "Print / Save as PDF" opens the browser print dialog using the same generated document via a dedicated print stylesheet — this is the reliable fallback if html2pdf can't load (e.g. blocked network).
- **Section VI (Experimentation)** ships with 10 pre-built experiment rows and a "+ Add experiment" button for candidates who want to list more than 10.
- **Section VII (Execution)** auto-generates the seven day cards (Monday–Sunday) from a small JS loop rather than being hand-duplicated in the HTML.

## A note on the rest of the request

Along with this build, you asked for the "top 10 candidate names" after "running the prompt." I want to flag that directly rather than guess: this document is the *specification* for the assignment page itself — it doesn't contain any candidate submissions, so there's no data here to rank or shortlist from. I haven't fabricated names or scores; once candidates actually fill this out and send back their exported PDFs, I'm glad to help you read through and evaluate those against the criteria in the page's own evaluation note (ownership, clarity of thinking, curiosity, ability to execute, etc.) — just share the submissions.
