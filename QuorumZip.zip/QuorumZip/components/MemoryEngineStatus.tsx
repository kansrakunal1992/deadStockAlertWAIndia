'use client'

// ── MemoryEngineStatus ────────────────────────────────────────────────────────
// Displays a compact "system readiness" card on the home page.
// Tells users how close they are to activating Structural Retrieval (5 sessions)
// and Mirror (10 sessions), and nudges them to log pending outcomes.
//
// Sprint 4b: hasIdentity prop added.
// When false (anonymous / no email), shows a minimal email CTA instead of the
// progress bar. Prevents anonymous users from seeing misleading pattern-memory
// progress that would vanish if they clear localStorage.
//
// Placement: between the input card and persona/tips grid.
// Only rendered when sessions.length > 0.

interface Props {
  sessionCount: number
  pendingOutcomes: number
  decidedCount: number
  hasIdentity: boolean
  mirrorUnlocked?: boolean      // true if user has active Mirror subscription
  foundingAvailable?: boolean   // see lib/founding.ts — branches the Mirror preview nudge copy
  onScrollToHistory: () => void
}

const PATTERN_MEMORY_THRESHOLD = 5   // Pattern Memory / Structural Retrieval activates here (also segment bar total)
const MIRROR_TEASER_THRESHOLD  = 3   // Sprint 19: Mirror preview (teaser) activates at 3 sessions

function SegmentBar({ filled, total }: { filled: number; total: number }) {
  return (
    <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
      {Array.from({ length: total }).map((_, i) => {
        const isFilled = i < filled
        const isPulse  = i === filled && filled < total
        return (
          <div
            key={i}
            style={{
              width: 18,
              height: 4,
              borderRadius: 2,
              background: isFilled
                ? filled >= PATTERN_MEMORY_THRESHOLD
                  ? 'var(--green-text)'
                  : 'var(--gold)'
                : 'var(--border-mid)',
              opacity: isFilled ? 1 : isPulse ? 0.4 : 0.2,
              transition: 'background 0.4s, opacity 0.4s',
              animation: isPulse ? 'segment-pulse 2s ease-in-out infinite' : 'none',
            }}
          />
        )
      })}
    </div>
  )
}

export default function MemoryEngineStatus({
  sessionCount,
  pendingOutcomes,
  decidedCount,
  hasIdentity,
  mirrorUnlocked = false,
  foundingAvailable = false,
  onScrollToHistory,
}: Props) {
  if (sessionCount === 0) return null

  // ── Anonymous view (no email, no user_id) ─────────────────────────────────
  // Show a minimal card with a CTA to add email. Do NOT show progress bar —
  // device-local sessions would be "forgotten" if localStorage is cleared,
  // so surfacing pattern-memory progress would be misleading.
  if (!hasIdentity) {
    return (
      <>
        <style>{`
          @keyframes dot-blink {
            0%, 100% { opacity: 0.4; }
            50%       { opacity: 1; }
          }
        `}</style>
        <div
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border-mid)',
            borderRadius: 14,
            padding: '14px 20px',
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            gap: 14,
          }}
        >
          <div
            style={{
              width: 7,
              height: 7,
              borderRadius: '50%',
              background: 'var(--gold)',
              animation: 'dot-blink 2s ease-in-out infinite',
              flexShrink: 0,
            }}
          />
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 11, color: 'var(--text-3)', margin: '0 0 2px', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Memory Engine
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-4)', margin: 0, lineHeight: 1.5 }}>
              Add your email below to build your judgment record across sessions.{' '}
              <span style={{ color: 'var(--text-3)' }}>
                {sessionCount} decision{sessionCount !== 1 ? 's' : ''} on this device
              </span>
              {' '}— not yet linked to your profile.
            </p>
          </div>
        </div>
      </>
    )
  }

  // ── Identified view (email or user_id present) ─────────────────────────────
  const patternActive         = sessionCount >= PATTERN_MEMORY_THRESHOLD
  const mirrorTeaserReady     = sessionCount >= MIRROR_TEASER_THRESHOLD
  const mirrorReady           = sessionCount >= PATTERN_MEMORY_THRESHOLD
  // UX fix (post-launch journey review): a subscribed user below the
  // pattern-memory threshold previously showed a flat "Active" (misleading —
  // nothing's active yet) via the old engineActive = mirrorUnlocked ||
  // patternActive. That's now split into its own "recording" state: paid,
  // access granted, genuinely building — not the same as fully active, and
  // not the same as the free-tier "hasn't started" Inactive state either.
  const recording              = mirrorUnlocked && !patternActive
  const engineActive           = patternActive

  let statusLabel: string
  let statusColor: string
  if (mirrorUnlocked && patternActive) {
    // Both Pattern Memory (≥5 sessions) and Mirror subscription active
    statusLabel = 'Pattern Memory active · Mirror active'
    statusColor = 'var(--green-text)'
  } else if (mirrorUnlocked) {
    // Mirror access active (subscription), but not enough decisions yet for
    // Pattern Memory itself. Was "Mirror active" (misleading) — now an
    // honest in-progress count, same tone as the free-tier countdown below.
    const remaining = PATTERN_MEMORY_THRESHOLD - sessionCount
    statusLabel = `Recording — ${sessionCount} of ${PATTERN_MEMORY_THRESHOLD} decisions · Mirror access active`
    statusColor = 'var(--gold)'
  } else if (patternActive) {
    // ≥5 sessions, no Mirror subscription
    statusLabel = 'Pattern Memory active · Mirror ready to activate'
    statusColor = 'var(--green-text)'
  } else if (mirrorTeaserReady) {
    const remaining = PATTERN_MEMORY_THRESHOLD - sessionCount
    statusLabel = `${remaining} more decision${remaining !== 1 ? 's' : ''} — Pattern Memory activates`
    statusColor = 'var(--gold)'
  } else {
    const remaining = MIRROR_TEASER_THRESHOLD - sessionCount
    statusLabel = `${remaining} more decision${remaining !== 1 ? 's' : ''} — Mirror preview activates`
    statusColor = 'var(--gold)'
  }

  return (
    <>
      <style>{`
        @keyframes segment-pulse {
          0%, 100% { opacity: 0.25; }
          50%       { opacity: 0.6; }
        }
        @keyframes dot-blink {
          0%, 100% { opacity: 0.4; }
          50%       { opacity: 1; }
        }
        /* Bug fix (Natural Intake hero, 440px column): this row was a fixed
           1fr/auto CSS grid, sized for the classic home page's much wider
           column. At ~440px or less, "N sessions" plus the outcomes-pending
           box no longer both fit on one row, and the box's own padding
           pushed it past the card's right edge instead of wrapping. Below
           480px the row now stacks instead of shrinking text to fit —
           shortening the copy would only postpone the same overflow at the
           next three-digit session count. */
        .mem-metrics-row { display: grid; grid-template-columns: 1fr auto; gap: 16px; align-items: center; }
        .mem-metrics-right { text-align: right; flex-shrink: 0; }
        @media (max-width: 480px) {
          .mem-metrics-row   { grid-template-columns: 1fr; }
          .mem-metrics-right { text-align: left; margin-top: 10px; }
        }
      `}</style>

      <div
        style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border-mid)',
          borderRadius: 14,
          padding: '16px 20px',
          marginBottom: 20,
        }}
      >
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div
              style={{
                width: 7,
                height: 7,
                borderRadius: '50%',
                background: engineActive ? 'var(--green-text)' : 'var(--gold)',
                animation: (engineActive || recording || mirrorTeaserReady) ? 'none' : 'dot-blink 2s ease-in-out infinite',
                flexShrink: 0,
              }}
            />
            <span
              style={{
                fontSize: 10.5,
                fontWeight: 700,
                letterSpacing: '0.14em',
                textTransform: 'uppercase',
                color: 'var(--text-3)',
              }}
            >
              Memory Engine
            </span>
          </div>

          <span
            style={{
              fontSize: 10,
              fontWeight: 600,
              color: engineActive ? 'var(--green-text)' : 'var(--gold)',
              letterSpacing: '0.06em',
              textTransform: 'uppercase',
            }}
          >
            {engineActive
              ? '● Active'
              : recording
                ? `◐ Recording — ${sessionCount} of ${PATTERN_MEMORY_THRESHOLD}`
                : mirrorTeaserReady
                  ? '● Mirror Preview'
                  : '○ Inactive'}
          </span>
        </div>

        {/* Main metrics row — see the .mem-metrics-row media query above for
            why this is a className now instead of an inline grid style: an
            inline style on this element would always beat the stylesheet's
            media query, however narrow the viewport gets. */}
        <div className="mem-metrics-row">
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
              <SegmentBar
                filled={Math.min(sessionCount, PATTERN_MEMORY_THRESHOLD)}
                total={PATTERN_MEMORY_THRESHOLD}
              />
              <span style={{ fontSize: 11, color: 'var(--text-3)', fontVariantNumeric: 'tabular-nums', flexShrink: 0 }}>
                {mirrorReady
                  ? `${sessionCount} sessions`
                  : `${sessionCount} of ${PATTERN_MEMORY_THRESHOLD}`}
              </span>
            </div>
            <p style={{ fontSize: 11, color: statusColor, margin: 0, lineHeight: 1.4 }}>
              {statusLabel}
            </p>
            {mirrorUnlocked && (
              <p style={{ fontSize: 11, color: 'var(--green-text)', margin: '3px 0 0', lineHeight: 1.4, display: 'flex', alignItems: 'center', gap: 0 }}>
                {/* Bug fix: when patternActive, statusLabel above already
                    reads "Pattern Memory active · Mirror active" — this line
                    used to repeat "Mirror active" verbatim right underneath
                    it. Now shows just the link in that case; the
                    non-patternActive wording is unchanged. */}
                {patternActive ? null : 'Mirror access active — recording your decisions'}
                <a
                  href="/mirror"
                  style={{
                    display:        'inline-flex',
                    alignItems:     'center',
                    gap:            4,
                    marginLeft:     patternActive ? 0 : 10,
                    color:          'var(--green-text)',
                    fontSize:       10.5,
                    fontWeight:     600,
                    textDecoration: 'none',
                    letterSpacing:  '0.06em',
                    opacity:        0.85,
                  }}
                >
                  View Mirror →
                </a>
              </p>
            )}
            {(mirrorTeaserReady && !mirrorUnlocked) && (
              <p style={{ fontSize: 11, color: 'var(--green-text)', margin: '3px 0 0', lineHeight: 1.4, display: 'flex', alignItems: 'center', gap: 0 }}>
                Mirror preview active
                <a
                  href="/mirror"
                  style={{
                    display:        'inline-flex',
                    alignItems:     'center',
                    gap:            4,
                    marginLeft:     10,
                    color:          'var(--green-text)',
                    fontSize:       10.5,
                    fontWeight:     600,
                    textDecoration: 'none',
                    letterSpacing:  '0.06em',
                    opacity:        0.85,
                  }}
                >
                  {foundingAvailable ? 'Become a Founding Member →' : 'View Mirror →'}
                </a>
              </p>
            )}
          </div>

          <div className="mem-metrics-right">
            {pendingOutcomes > 0 ? (
              <button
                onClick={onScrollToHistory}
                style={{
                  background: 'rgba(201,168,76,0.08)',
                  border: '1px solid var(--gold-dim)',
                  borderRadius: 8,
                  padding: '6px 12px',
                  cursor: 'pointer',
                  fontFamily: 'inherit',
                }}
              >
                <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--gold)', margin: '0 0 1px' }}>
                  {pendingOutcomes}
                </p>
                <p style={{ fontSize: 9.5, color: 'var(--text-4)', margin: 0, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                  {pendingOutcomes === 1 ? 'Outcome pending' : 'Outcomes pending'}
                </p>
              </button>
            ) : decidedCount > 0 ? (
              <div>
                <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--green-text)', margin: '0 0 1px' }}>
                  {decidedCount}
                </p>
                <p style={{ fontSize: 9.5, color: 'var(--text-4)', margin: 0, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                  Outcomes logged
                </p>
              </div>
            ) : null}
          </div>
        </div>

        {!patternActive && (
          <div
            style={{
              marginTop: 12,
              paddingTop: 10,
              borderTop: '1px solid var(--border-dim)',
              display: 'flex',
              alignItems: 'flex-start',
              gap: 8,
            }}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-4)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}>
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <p style={{ fontSize: 11, color: 'var(--text-4)', margin: 0, lineHeight: 1.5 }}>
              Pattern Memory surfaces structural matches between your current decision and past sessions —&nbsp;
              <span style={{ color: 'var(--text-3)' }}>
                &quot;you faced this structure before.&quot;
              </span>
              {' '}Each decision logged builds toward it. Pattern Memory activates at {PATTERN_MEMORY_THRESHOLD} decisions.
            </p>
          </div>
        )}


      </div>
    </>
  )
}
