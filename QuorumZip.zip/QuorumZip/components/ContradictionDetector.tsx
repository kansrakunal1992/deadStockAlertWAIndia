'use client'

// components/ContradictionDetector.tsx
// ── Sprint 9: Contradiction Detector ────────────────────────────────────────
//
// Gate: requires mirror_access (paid) AND >= UNLOCK_THRESHOLD sessions
// (currently 15, env-configurable via CONTRADICTION_UNLOCK_THRESHOLD).
//
// Progressive teaser system — 3 milestones, evenly spaced across
// UNLOCK_THRESHOLD (see buildSteps()), each reveals a bit more:
//   stage 0 → "Building the map" — locked, no preview
//   stage 1 → "First patterns detected" — one blurred principle tile visible
//   stage 2 → "Contradiction forming" — two tiles + excerpt of what's coming
//   threshold reached → Fully unlocked — live contradiction cards
//
// Milestone ranges and copy are derived from UNLOCK_THRESHOLD, not hardcoded,
// so the teaser always matches the real gate whatever it's tuned to.
//
// Each milestone has distinct copy to build anticipation without being
// fake or misleading. Tiles stay blurred. No fabricated contradictions shown.
//
// When unlocked: contradiction cards show principle vs violation, session refs,
// severity badge, and are dismissible (stored server-side).
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useEffect } from 'react'
import { formatShortDate } from '@/lib/dates'
import type { MirrorTier } from '@/lib/types'
// AdvisoryUpsellCard/ADVISORY_UPSELL_COPY imports removed — Advisory tier
// retired (Phase 6). ContradictionSummaryView (the component that used them)
// removed below too — it was only reachable from the branch that showed
// summary-only data to non-Advisory users, which no longer exists.

// ── Types ─────────────────────────────────────────────────────────────────────

interface Contradiction {
  id:                 string
  principleText:      string
  principleSessionId: string | null
  principleDecision:  string | null
  violationText:      string
  violationSessionId: string | null
  violationDecision:  string | null
  severity:           'sharp' | 'notable' | 'forming'
  category:           string
  generatedAt:        string
}

interface ContradictionData {
  contradictions:    Contradiction[]
  sessionCount:      number
  meetsThreshold:    boolean
  threshold:         number
  lastRanAt:         string | null
  dismissedCount?:   number   // Sprint M4: all-time dismissed count for ratio display
}

interface Props {
  authToken:    string
  sessionCount: number   // from parent — renders gate immediately, no extra fetch
  tier:         MirrorTier
}

// ── Constants ─────────────────────────────────────────────────────────────────

// Lowered from 40 (was Advisory's old bypass point vs. Mirror's 40-session
// wait) to 15 — env-configurable like the other thresholds in this codebase,
// so it can be tuned without a code change.
const UNLOCK_THRESHOLD = Number(process.env.CONTRADICTION_UNLOCK_THRESHOLD ?? 15)

// Milestone/progress-bar steps are derived from UNLOCK_THRESHOLD (not hardcoded)
// so the teaser always matches the real gate, whatever it's tuned to via env.
// 4 evenly-spaced checkpoints across the threshold, e.g. threshold=15 → [4,8,11,15].
const MILESTONE_STEP_COUNT = 3
function buildSteps(threshold: number): number[] {
  const raw = Array.from({ length: MILESTONE_STEP_COUNT }, (_, i) =>
    Math.round((threshold * (i + 1)) / MILESTONE_STEP_COUNT)
  )
  // De-dupe in case a low threshold collapses steps onto the same integer
  // (e.g. threshold=3 → [1,2,2,3]); keep the array monotonic and unique.
  const out: number[] = []
  for (const v of raw) out.push(Math.max(v, (out[out.length - 1] ?? 0) + 1))
  out[out.length - 1] = threshold // last step is always exactly the real gate
  return out
}
const STEPS = buildSteps(UNLOCK_THRESHOLD)

// Milestone definitions — what copy and how many blurred tiles to show.
// Ranges come from STEPS so they always add up to exactly [0, UNLOCK_THRESHOLD).
const MILESTONES = [
  {
    // Sprint M3: reframed from "Detection initialising" (gate) to "Building the map"
    // (forward commitment). Old copy said "needs more signal" which read as
    // nothing happening. New copy explains what IS being built and why it matters.
    min:     0,
    max:     STEPS[0] - 1,
    label:   'Building the map',
    body:    `Quorum is constructing a record of the reasoning principles you've stated across your decisions — what you said you'd prioritise, how you framed commitments, what conditions you said would change your mind. At ${STEPS[0]} decisions, it begins testing that map against what you actually chose.`,
    tiles:   0,
    excerpt: 'This isn\'t an assessment — it\'s your own logic, about to be checked against itself.',
  },
  {
    min:      STEPS[0],
    max:      STEPS[1] - 1,
    label:    'First patterns detected',
    body:     'Quorum has begun mapping the principles you\'ve stated across decisions. A pattern is forming — but it needs more data points before it can surface a reliable contradiction.',
    tiles:    1,
    excerpt:  'Something about how you handle urgency is starting to emerge.',
  },
  {
    min:      STEPS[1],
    max:      STEPS[2] - 1,
    label:    'Contradiction forming',
    body:     'Two distinct reasoning patterns are now structurally defined. The system has identified at least one area where your reasoning in one decision appears to conflict with a principle you stated in another.',
    tiles:    2,
    excerpt:  'The gap between a stated standard and an actual framing is now clear enough to name. You\'re close.',
  },
]

function getMilestone(count: number) {
  return MILESTONES.find(m => count >= m.min && count <= m.max) ?? MILESTONES[0]
}

// ── Severity display ──────────────────────────────────────────────────────────

const SEVERITY_LABEL: Record<string, string> = {
  sharp:   'Direct',
  notable: 'Tension',
  forming: 'Emerging',
}

const SEVERITY_COLOR: Record<string, string> = {
  sharp:   'rgba(200, 80, 60, 0.8)',
  notable: 'rgba(201, 168, 76, 0.9)',
  forming: 'rgba(130, 130, 150, 0.8)',
}

// ── Blurred placeholder tile ──────────────────────────────────────────────────

function BlurredTile({ index }: { index: number }) {
  const widths = ['82%', '68%', '75%']
  const w = widths[index % widths.length]
  return (
    <div style={{
      background:   'linear-gradient(180deg, rgba(255,255,255,0.015) 0%, transparent 50%), var(--bg-card)',
      border:       '1px solid var(--border-dim)',
      borderRadius: 12,
      padding:      '18px 20px',
      boxShadow:    '0 1px 4px rgba(0,0,0,0.3)',
      marginBottom: 10,
      position:     'relative',
      overflow:     'hidden',
    }}>
      {/* Top severity bar placeholder */}
      <div style={{
        position: 'absolute', top: 0, left: 0,
        width: '100%', height: 2,
        background: 'var(--border-mid)', opacity: 0.4,
      }} />

      {/* Header placeholder */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        <div style={{ width: 60, height: 7, background: 'var(--border-dim)', borderRadius: 3, opacity: 0.5 }} />
        <div style={{ width: 40, height: 7, background: 'var(--border-dim)', borderRadius: 3, opacity: 0.3 }} />
      </div>

      {/* "What you said" blurred text lines */}
      <div style={{ marginBottom: 12, filter: 'blur(4px)', userSelect: 'none' }}>
        <div style={{ width: '35%', height: 6, background: 'var(--text-4)', borderRadius: 2, marginBottom: 8, opacity: 0.4 }} />
        <div style={{ width: w, height: 10, background: 'var(--text-2)', borderRadius: 3, marginBottom: 5, opacity: 0.25 }} />
        <div style={{ width: '55%', height: 10, background: 'var(--text-2)', borderRadius: 3, opacity: 0.15 }} />
        <div style={{ width: '40%', height: 7, background: 'var(--text-4)', borderRadius: 2, marginTop: 6, opacity: 0.2 }} />
      </div>

      {/* Connector */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '0 0 12px', opacity: 0.2 }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border-mid)' }} />
        <span style={{ fontSize: 9, color: 'var(--text-4)' }}>then</span>
        <div style={{ flex: 1, height: 1, background: 'var(--border-mid)' }} />
      </div>

      {/* "What you did" blurred */}
      <div style={{ filter: 'blur(4px)', userSelect: 'none' }}>
        <div style={{ width: '32%', height: 6, background: 'var(--text-4)', borderRadius: 2, marginBottom: 8, opacity: 0.4 }} />
        <div style={{ width: '88%', height: 10, background: 'var(--text-2)', borderRadius: 3, marginBottom: 5, opacity: 0.2 }} />
        <div style={{ width: '62%', height: 10, background: 'var(--text-2)', borderRadius: 3, opacity: 0.12 }} />
      </div>

      {/* Lock overlay */}
      <div style={{
        position:       'absolute',
        inset:          0,
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'center',
        background:     'rgba(var(--bg-base-rgb, 12,12,14), 0.35)',
        backdropFilter: 'blur(1px)',
      }}>
        <span style={{ fontSize: 14, opacity: 0.25 }}>🔒</span>
      </div>
    </div>
  )
}

// ── Progress bar ──────────────────────────────────────────────────────────────

function ProgressBar({ count }: { count: number }) {
  const steps = STEPS // derived from UNLOCK_THRESHOLD — see buildSteps() above
  return (
    <div style={{ marginTop: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
        {steps.map((step, i) => {
          const filled = count >= step
          const partial = count >= (i === 0 ? 0 : steps[i - 1]) && count < step
          const pct = partial
            ? ((count - (i === 0 ? 0 : steps[i - 1])) / 10) * 100
            : filled ? 100 : 0

          return (
            <div key={step} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
              {/* Segment track */}
              <div style={{
                width: '90%', height: 3, borderRadius: 2,
                background: 'var(--border-dim)',
                overflow: 'hidden',
                position: 'relative',
              }}>
                <div style={{
                  position:   'absolute',
                  top: 0, left: 0,
                  height:     '100%',
                  width:      `${pct}%`,
                  background: filled ? 'var(--gold)' : 'var(--gold-dim)',
                  borderRadius: 2,
                  transition: 'width 0.6s ease',
                }} />
              </div>
              {/* Step label */}
              <span style={{
                fontSize:   9,
                color:      filled ? 'var(--gold)' : 'var(--text-4)',
                fontWeight: filled ? 700 : 400,
                opacity:    filled ? 1 : 0.5,
              }}>
                {step}
              </span>
            </div>
          )
        })}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
        <span style={{ fontSize: 9, color: 'var(--text-4)' }}>{count} decisions</span>
        <span style={{ fontSize: 9, color: 'var(--text-4)' }}>{UNLOCK_THRESHOLD - count} to unlock</span>
      </div>
    </div>
  )
}

// ── Teaser card (below threshold) ─────────────────────────────────────────────

function TeaserView({ sessionCount }: { sessionCount: number }) {
  const milestone = getMilestone(sessionCount)

  return (
    <div>
      {/* Status card */}
      <div style={{
        background:   'var(--bg-card)',
        border:       '1px solid var(--border-mid)',
        borderRadius: 12,
        padding:      '18px 20px',
        marginBottom: milestone.tiles > 0 ? 16 : 0,
        position:     'relative',
        overflow:     'hidden',
      }}>
        <div style={{
          position: 'absolute', top: 0, left: 0,
          width: '100%', height: 2,
          background: 'linear-gradient(90deg, var(--gold-dim) 0%, transparent 60%)',
        }} />

        <p style={{
          fontSize: 10, fontWeight: 700, color: 'var(--gold)',
          textTransform: 'uppercase', letterSpacing: '0.1em',
          margin: '0 0 8px',
        }}>
          {milestone.label}
        </p>

        <p style={{ fontSize: 12.5, color: 'var(--text-3)', margin: '0 0 10px', lineHeight: 1.6 }}>
          {milestone.body}
        </p>

        {milestone.excerpt && (
          <p style={{
            fontSize:    12,
            color:       'var(--text-4)',
            fontStyle:   'italic',
            margin:      '0 0 10px',
            paddingLeft: 10,
            borderLeft:  '2px solid rgba(201,168,76,0.25)',
            lineHeight:  1.55,
          }}>
            {milestone.excerpt}
          </p>
        )}

        <ProgressBar count={sessionCount} />

        {/* Run a decision CTA */}
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--border-dim)' }}>
          <a
            href="/"
            style={{
              display:        'inline-flex',
              alignItems:     'center',
              gap:            6,
              fontSize:       11.5,
              fontWeight:     600,
              color:          'var(--gold)',
              textDecoration: 'none',
              opacity:        0.8,
              transition:     'opacity 0.15s',
            }}
            onMouseEnter={e => ((e.currentTarget as HTMLAnchorElement).style.opacity = '1')}
            onMouseLeave={e => ((e.currentTarget as HTMLAnchorElement).style.opacity = '0.8')}
          >
            Run a decision →
          </a>
          <p style={{ fontSize: 10, color: 'var(--text-4)', margin: '4px 0 0', lineHeight: 1.4 }}>
            Each decision with follow-up answers builds the signal needed to detect contradictions.
          </p>
        </div>
      </div>

      {/* Blurred tiles — count varies by milestone */}
      {Array.from({ length: milestone.tiles }).map((_, i) => (
        <BlurredTile key={i} index={i} />
      ))}
    </div>
  )
}

// ── Skeleton ──────────────────────────────────────────────────────────────────

function Skeleton() {
  return (
    <>
      <style>{`
        @keyframes cd-pulse {
          0%, 100% { opacity: 0.15; }
          50%       { opacity: 0.4; }
        }
      `}</style>
      {[0, 1].map(i => (
        <div key={i} style={{
          background: 'var(--bg-card)', border: '1px solid var(--border-dim)',
          borderRadius: 12, padding: '18px 20px', marginBottom: 12,
          animation: `cd-pulse 1.8s ease-in-out infinite ${i * 0.3}s`,
        }}>
          <div style={{ height: 8, width: '35%', background: 'var(--border-dim)', borderRadius: 3, marginBottom: 14 }} />
          <div style={{ height: 11, width: '85%', background: 'var(--border-dim)', borderRadius: 4, marginBottom: 8 }} />
          <div style={{ height: 11, width: '65%', background: 'var(--border-dim)', borderRadius: 4 }} />
        </div>
      ))}
    </>
  )
}

// ── Contradiction card ────────────────────────────────────────────────────────

function ContradictionCard({
  item, onDismiss,
}: {
  item: Contradiction
  onDismiss: (id: string) => void
}) {
  const [dismissing, setDismissing] = useState(false)

  return (
    <div style={{
      background:   'var(--bg-card)',
      border:       '1px solid var(--border-mid)',
      borderRadius: 12,
      padding:      '18px 20px',
      marginBottom: 12,
      position:     'relative',
      overflow:     'hidden',
      opacity:      dismissing ? 0.3 : 1,
      transition:   'opacity 0.35s',
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0,
        width: '100%', height: 2,
        background: SEVERITY_COLOR[item.severity], opacity: 0.65,
      }} />

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <span style={{
          fontSize: 9.5, fontWeight: 700, textTransform: 'uppercase',
          letterSpacing: '0.1em', color: SEVERITY_COLOR[item.severity],
        }}>
          {SEVERITY_LABEL[item.severity] ?? item.severity}
          {item.category ? ` · ${item.category.replace(/_/g, ' ')}` : ''}
        </span>
        <button
          onClick={() => { setDismissing(true); onDismiss(item.id) }}
          disabled={dismissing}
          style={{
            background: 'none', border: 'none', color: 'var(--text-4)',
            cursor: 'pointer', fontSize: 16, lineHeight: 1,
            padding: '0 2px', opacity: 0.45, transition: 'opacity 0.15s',
          }}
          onMouseEnter={e => ((e.currentTarget as HTMLButtonElement).style.opacity = '1')}
          onMouseLeave={e => ((e.currentTarget as HTMLButtonElement).style.opacity = '0.45')}
        >×</button>
      </div>

      {/* Principle */}
      <div style={{ marginBottom: 12 }}>
        <p style={{
          fontSize: 9, fontWeight: 700, color: 'var(--text-4)',
          textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 5px',
        }}>What you said</p>
        <p style={{ fontSize: 13, color: 'var(--text-1)', lineHeight: 1.55, margin: 0, fontStyle: 'italic' }}>
          "{item.principleText}"
        </p>
        {item.principleDecision && (
          <p style={{ fontSize: 10, color: 'var(--text-4)', margin: '4px 0 0', lineHeight: 1.4 }}>
            From: {item.principleDecision}{item.principleDecision.length >= 80 ? '…' : ''}
          </p>
        )}
      </div>

      {/* Connector */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '0 0 12px', opacity: 0.35 }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border-mid)' }} />
        <span style={{ fontSize: 9, color: 'var(--text-4)', letterSpacing: '0.06em' }}>then</span>
        <div style={{ flex: 1, height: 1, background: 'var(--border-mid)' }} />
      </div>

      {/* Violation */}
      <div>
        <p style={{
          fontSize: 9, fontWeight: 700, color: 'var(--text-4)',
          textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 5px',
        }}>What you did</p>
        <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.55, margin: 0 }}>
          {item.violationText}
        </p>
        {item.violationDecision && (
          <p style={{ fontSize: 10, color: 'var(--text-4)', margin: '4px 0 0', lineHeight: 1.4 }}>
            From: {item.violationDecision}{item.violationDecision.length >= 80 ? '…' : ''}
          </p>
        )}
      </div>
    </div>
  )
}

// ── Mirror-tier summary view (Phase 5) ────────────────────────────────────────
//
// For 'mirror' tier, full contradictions exist (sessionCount >= 40, same as
// 'advisory') but the exact statements are not shown — only the count and
// category. This is deliberately NOT a locked/blurred state: the user is told
// precisely what was found, just not the evidentiary detail. Designed to pull
// toward Advisory, not just block.

const CATEGORY_LABELS: Record<string, string> = {
  process:           'Process',
  risk_assessment:   'Risk assessment',
  stakeholder:       'Stakeholder framing',
  commitment:        'Commitment & follow-through',
  values:            'Stated values vs. action',
  timing:            'Timing & urgency',
}

function categoryLabel(key: string): string {
  return CATEGORY_LABELS[key] ?? key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
}

// ContradictionSummaryView removed (Phase 6) — was dead code after Advisory
// tier retirement; only reachable from the summary-only branch removed above.

// ── Main component ────────────────────────────────────────────────────────────

export default function ContradictionDetector({ authToken, sessionCount, tier }: Props) {
  const [data,      setData]      = useState<ContradictionData | null>(null)
  const [loading,   setLoading]   = useState(true)
  const [error,     setError]     = useState(false)
  const [dismissed, setDismissed] = useState<Set<string>>(new Set())

  // Guard restored (session count, not tier), threshold lowered from the
  // original 40 to a friendlier UNLOCK_THRESHOLD. Advisory's old bypass made
  // sense with a founder personally watching new members; Elite has no such
  // safety net, so a real data-sufficiency gate applies to everyone now.
  const belowThreshold = sessionCount < UNLOCK_THRESHOLD

  useEffect(() => {
    if (belowThreshold) { setLoading(false); return }

    let cancelled = false
    const load = async () => {
      try {
        const res = await fetch('/api/mirror/contradictions', {
          headers: { Authorization: `Bearer ${authToken}` },
        })
        if (!res.ok) { if (!cancelled) setError(true); return }
        const json = await res.json() as ContradictionData
        if (!cancelled) setData(json)
      } catch {
        if (!cancelled) setError(true)
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => { cancelled = true }
  }, [authToken, belowThreshold])

  const handleDismiss = async (id: string) => {
    setDismissed(prev => new Set([...prev, id]))
    try {
      await fetch(`/api/mirror/contradictions?id=${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${authToken}` },
      })
    } catch { /* dismissed locally regardless */ }
  }

  // ── Below threshold — progressive teaser ─────────────────────────────────
  if (belowThreshold) return <TeaserView sessionCount={sessionCount} />

  // ── Loading ───────────────────────────────────────────────────────────────
  if (loading) return <Skeleton />

  // ── Error ─────────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.015) 0%, transparent 50%), var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 12, padding: '16px 18px', boxShadow: '0 1px 4px rgba(0,0,0,0.3)' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-4)', margin: 0, lineHeight: 1.6 }}>
          Contradiction detection temporarily unavailable. Your data is intact.
        </p>
      </div>
    )
  }

  const active = (data?.contradictions ?? []).filter(c => !dismissed.has(c.id))

  // ── No contradictions yet ─────────────────────────────────────────────────
  if (active.length === 0) {
    return (
      <div style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.015) 0%, transparent 50%), var(--bg-card)', border: '1px solid var(--border-dim)', borderRadius: 12, padding: '16px 18px', boxShadow: '0 1px 4px rgba(0,0,0,0.3)' }}>
        <p style={{ fontSize: 12.5, color: 'var(--text-4)', margin: 0, lineHeight: 1.6 }}>
          {data?.lastRanAt
            ? 'No structural contradictions detected yet. This updates as you add more decisions and deepen your follow-up answers.'
            : 'Contradiction analysis runs after each session. Your data is building — check back after a few more decisions.'}
        </p>
      </div>
    )
  }

  // ── Live contradictions ───────────────────────────────────────────────────

  // Advisory tier retired, folded into Elite (Phase 6) — full detail (exact
  // statements) now shows for any paid tier, same as 'advisory' alone before.

  return (
    <div>
      {/* Sprint M4: dismissed / active ratio */}
      {(data?.dismissedCount ?? 0) > 0 && (
        <p style={{ fontSize: 10, color: 'var(--text-4)', margin: '0 0 10px', letterSpacing: '0.03em' }}>
          {data!.dismissedCount} dismissed all-time &nbsp;·&nbsp; {active.length} active
        </p>
      )}
      {active.map(item => (
        <ContradictionCard key={item.id} item={item} onDismiss={handleDismiss} />
      ))}
      <p style={{ fontSize: 10, color: 'var(--text-4)', margin: '4px 0 0', lineHeight: 1.5 }}>
        Extracted from your follow-up answers and pushbacks — your own words, not an assessment.
        {data?.lastRanAt && ` Last updated ${formatShortDate(data.lastRanAt)}.`}
      </p>
    </div>
  )
}
