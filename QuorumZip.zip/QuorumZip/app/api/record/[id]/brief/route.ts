// app/api/record/[id]/brief/route.ts
// ── Sprint 8: Decision Brief PDF (v2) ────────────────────────────────────────
//
// Fixes vs v1:
//   1. Unicode sanitiser — replaces Rs./₹ and all non-Latin-1 chars before
//      passing to jsPDF (Latin-1 encoding; anything outside it renders as garbage)
//   2. Line-by-line rendering throughout — no pre-calculated box heights that
//      go wrong when text wraps more than estimated
//   3. Dark premium layout — deep navy/black pages, gold accents, per-persona
//      colour bands matching the Quorum UI dark theme
//   4. Dynamic import — avoids "window is not defined" in Next.js server context
// ─────────────────────────────────────────────────────────────────────────────

import { NextResponse }        from 'next/server'
import { createServiceClient } from '@/lib/supabase'
import { PERSONAS, DECISION_BRIEF } from '@/lib/personas'
import { createCompletion }   from '@/lib/ai-client'
import type { PersonaKey }     from '@/lib/types'
import { encrypt, decrypt }    from '@/lib/encryption'
import { briefLineIsRedundantTitle } from '@/lib/brief-markdown'
import { checkLimit, getClientIP, tooManyRequests, LIMITS } from '@/lib/rate-limit'

const APPENDIX_ORDER: PersonaKey[] = [
  'synthesis',
  'contrarian',
  'risk_architect',
  'pattern_analyst',
  'stakeholder_mirror',
  'elder',
  'competitor',
]

// ── Unicode → Latin-1 sanitiser ───────────────────────────────────────────────
// jsPDF default encoding is Latin-1 (Windows-1252). Characters outside this
// range render as garbage (e.g. ₹ → ¹, — → ?, " → ?).
// This sanitiser replaces common non-Latin-1 chars with ASCII equivalents
// before any text reaches the PDF renderer.

function sanitise(text: string): string {
  return text
    // Currency
    .replace(/₹/g, 'Rs.')
    .replace(/€/g, 'EUR ')
    .replace(/£/g, 'GBP ')
    .replace(/\$/g, '$')
    // Dashes and hyphens
    .replace(/[\u2013\u2014]/g, '--')   // en-dash, em-dash
    .replace(/\u2012/g, '-')            // figure dash
    // Smart quotes → straight
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    // Ellipsis
    .replace(/\u2026/g, '...')
    // Bullets
    .replace(/[\u2022\u2023\u25E6\u2043]/g, '-')
    // Arrows
    .replace(/\u2192/g, '->')
    .replace(/\u2190/g, '<-')
    // Multiplication / degree
    .replace(/\u00D7/g, 'x')
    .replace(/\u00B0/g, ' deg')
    // Fractions
    .replace(/\u00BD/g, '1/2')
    .replace(/\u00BC/g, '1/4')
    .replace(/\u00BE/g, '3/4')
    // Remove any remaining non-Latin-1
    // eslint-disable-next-line no-control-regex
    .replace(/[^\x00-\xFF]/g, '?')
}

// Strip the examiner-style wrapper that automatic advisor-to-advisor context
// sharing prepends to pushback messages before they are saved to the DB,
// leaving only the raw pushback text the decision-maker actually typed.
function cleanPushbackText(raw: string): string {
  return raw
    // Strip any wrapper preamble (old or current wording) that precedes the
    // quoted pushback text — matched structurally (a line ending in ':' or
    // a newline run, right before the opening quote) rather than one exact
    // sentence, so this survives future wording changes to the wrapper.
    .replace(/^[^"\n]*[:\n]+\s*/i, '')
    // Bug fix: this required the closing quote to sit at (or right near) the
    // end of the string. That's true for a directly-challenged advisor
    // (PersonaPanel.tsx stores the raw challenge text with no wrapper at
    // all), but the five auto-shared advisors receive the full examinerMsg
    // template (components/SessionView.tsx, handleShareContext) — which
    // appends "Reassess it independently through your own lens..." and
    // "Provide a concise update..." AFTER the closing quote. Since nothing
    // used to follow the quote, that instructional tail was left in place
    // and printed into the PDF as if it were part of the pushback. Matching
    // the FIRST quoted segment (non-greedy, no end anchor) instead of
    // "everything to the end is one big quote" fixes this regardless of
    // what trails it.
    .replace(/^"([\s\S]*?)"[\s\S]*$/, '$1')
    // Belt-and-suspenders for the same wrapper's instruction lines, in case
    // a stored message ever lacks the quote marks.
    .replace(/\s*Reassess it independently through your own lens[\s\S]*$/i, '')
    // Remove the trailing instruction block (old or current wording)
    .replace(/\s*Provide a concise update[\s\S]*$/i, '')
    .trim()
}

// Strip <lens>, <position>, <realcost>, <lean>, <structural>, <verdict>,
// <verdict_lean>, <conditions>, <key_question>, <tension>, <assumption>,
// <reversal>, <estimate> tags from advisor/synthesis text before it goes into the PDF
function stripAdvisorTags(raw: string): string {
  return raw
    .replace(/<lens>[\s\S]*?<\/lens>/gi, '')
    .replace(/<position>[\s\S]*?<\/position>/gi, '')
    .replace(/<realcost>[\s\S]*?<\/realcost>/gi, '')
    // Fix: <lean> was never stripped here — every advisor response includes
    // this tag (base persona prompt), so it could leak into the PDF's advisor
    // sections. Same bug class as verdict_lean/conditions below, just pre-existing.
    .replace(/<lean>[\s\S]*?<\/lean>/gi, '')
    // Bug fix: <structural> was never stripped here either — every persona
    // response with a structural-echo citation (R6) leaked the raw tag
    // straight into the generated PDF.
    .replace(/<structural>[\s\S]*?<\/structural>/gi, '')
    .replace(/<verdict>[\s\S]*?<\/verdict>\n*/gi, '')
    .replace(/<verdict>[\s\S]*/gi, '')           // guard: open tag without close
    // P2 fix: this file has its own independent tag-stripping copy — it never
    // learned about the two tags added for forced-verdict-with-conditions.
    .replace(/<verdict_lean>[\s\S]*?<\/verdict(?:_lean)?>\n*/gi, '')
    .replace(/<conditions>[\s\S]*?<\/conditions>\n*/gi, '')
    // Sprint 1 follow-on: PDF has no separate callout mechanism, so this is
    // content-preserving (keeps the sentence as its own paragraph, which is
    // how the model already writes it) rather than dropping it entirely.
    .replace(/<\/?key_question>/gi, '')
    .replace(/<(?:lens|position|realcost|lean|structural|verdict_lean|conditions)>[\s\S]*$/i, '') // guard: open tag without close
    .replace(/<\/?(?:proceed|wait|mixed)>\s*/gi, '')      // guard: stray malformed lean-value tag (see PersonaPanel.tsx)
    // Third bug fix (GPT-5-mini, Aug 2026) — see PersonaPanel.tsx's extractHeaderTags
    // for the full explanation. Two leaked-lean shapes gpt-5-mini produces that the
    // guard above doesn't catch: a bare enum word glued to the next capitalized
    // sentence ("mixedThis is..."), and a truncated open tag ("<mixed</lean>").
    .replace(/^(?:proceed|wait|mixed)\s*(?=[A-Z])/i, '')
    .replace(/^<(?:proceed|wait|mixed)<\/lean>\s*/i, '')
    // Shape 3 (seen leaking specifically in pushback replies, Aug 2026): bare value,
    // no leading "<", but WITH the closing tag attached — e.g. "mixed</lean>".
    .replace(/^(?:proceed|wait|mixed)<\/lean>\s*/i, '')
    .replace(/<\/?tension>/gi, '')
    // Sprint 2 follow-on: content-preserving, same reasoning as PersonaPanel's
    // stripHeaderTags — this wraps substantive prose, not a machine value.
    .replace(/<\/?assumption>/gi, '')
    // Reversal Test <reversal> tag (all six personas) — same content-preserving
    // treatment as <assumption> just above.
    .replace(/<\/?reversal>/gi, '')
    // Numeric Provenance <estimate> tag (WORD_LIMIT_PREFIX #6, all six
    // personas) — same content-preserving treatment as <assumption>/
    // <reversal> above. Before this line existed, this file's substring
    // check happened to pass by accident (an unrelated comment two screens
    // up contains the word "estimated"), which is exactly the silent-gap
    // failure mode this whole stripping function exists to prevent — see
    // tests/persona-tag-wiring-guardrail.test.ts.
    .replace(/<\/?estimate>/gi, '')
    // New machine-only tag (mind-change tracking) — full removal, same as <lean>.
    // Tolerant close: model sometimes closes with </pushback> instead of the
    // full tag name (same drift as verdict_lean) — without this it leaks into the PDF.
    .replace(/<pushback_classification>[\s\S]*?<\/(?:pushback_classification|pushback)>/gi, '')
    // Root-cause fix: same ordering bug found on the record page and in
    // RecordExport.tsx — this guard ran BEFORE the proper strip above, so it
    // treated every validly-closed <pushback_classification> tag as if it
    // were unclosed and deleted everything after it, including the actual
    // reply text. This is the confirmed cause of the PDF showing the same
    // missing-reply-after-a-challenge issue as the record page.
    .replace(/<pushback_classification>[\s\S]*$/i, '') // guard: open tag without close
    .replace(/^\s+/, '')
}

// Bug fix: <realcost> and <lean> were being deleted by stripAdvisorTags above
// with no equivalent content shown anywhere in the PDF — same root cause as
// the record page's stripHeaderTags. <realcost> is substantive advisor prose
// (content-preserving, like <assumption>); <lean> is machine-only but
// PersonaPanel.tsx surfaces it to users as a "Leaning: X" line, which the PDF
// had no equivalent for either.
const LEAN_LABELS: Record<string, string> = {
  proceed: 'Proceed',
  wait:    'Wait',
  mixed:   'Mixed',
}

// Bug fix (visible tag leak, same root cause as PersonaPanel.tsx's
// extractHeaderTags, the record page, and RecordExport.tsx): <estimate>/
// <assumption>/<reversal> can legitimately appear nested inside a
// <realcost> or <position> sentence, and this returned that content
// verbatim — leaking raw tag markup into the generated PDF. Strip just the
// markers, keep the inner text.
function stripInlineDisplayTags(s: string): string {
  return s
    .replace(/<\/?estimate>/gi, '')
    .replace(/<\/?assumption>/gi, '')
    .replace(/<\/?reversal>/gi, '')
}

function extractTag(raw: string, tag: string): string {
  const m = raw.match(new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`, 'i'))
  return m ? stripInlineDisplayTags(m[1].trim()) : ''
}

// ── Colour palettes — dark (original) + light ─────────────────────────────────
// buildPdf() selects one into a local `const C` and `const PERSONA_ACCENT` at
// the top of the function; every existing C.xxx / PERSONA_ACCENT[key] reference
// below resolves to whichever palette is active via lexical scoping — no other
// lines in the function need to change.

type Palette = {
  gold:         [number, number, number]
  goldDim:      [number, number, number]
  goldText:     [number, number, number]
  pageBg:       [number, number, number]
  headerBg:     [number, number, number]
  briefBg:      [number, number, number]
  synthBg:      [number, number, number]
  decisionBg:   [number, number, number]
  pushbackBg:   [number, number, number]
  bodyText:     [number, number, number]
  mutedText:    [number, number, number]
  dimText:      [number, number, number]
  ruleGold:     [number, number, number]
  ruleMid:      [number, number, number]
  white:        [number, number, number]
  goldLight:    [number, number, number]
  pushbackText: [number, number, number]
  verdictBg:           [number, number, number]
  verdictAccent:       [number, number, number]
  tensionHighlightBg:  [number, number, number]
  // P2 fix: action_plan/confidence_to_act had no box treatment at all in this
  // file, unlike every other synthesis tag — added here to match the teal
  // "action" accent already used for this content on the live session view
  // (app/globals.css --action-accent/--action-bg/--action-note-border),
  // approximated as flat RGB since jsPDF fills don't support the CSS
  // gradient/opacity these are defined with.
  actionBg:            [number, number, number]
  actionAccent:        [number, number, number]
  actionNoteBorder:    [number, number, number]
}

const DARK_PALETTE: Palette = {
  gold:         [201, 168, 76],
  goldDim:      [100, 82,  30],
  goldText:     [201, 168, 76],
  pageBg:       [4,   6,   15],
  headerBg:     [4,   6,   15],
  briefBg:      [8,   18,  8],
  synthBg:      [15,  22,  15],
  decisionBg:   [7,   10,  22],
  pushbackBg:   [7,   12,  24],
  bodyText:     [188, 200, 220],
  mutedText:    [74,  85,  104],
  dimText:      [42,  58,  92],
  ruleGold:     [42,  38,  18],
  ruleMid:      [28,  43,  74],
  white:        [232, 234, 240],
  goldLight:    [180, 148, 60],
  pushbackText: [160, 172, 198],
  verdictBg:           [44, 36, 15],
  verdictAccent:       [222, 184, 96],
  tensionHighlightBg:  [56, 47, 21],
  actionBg:            [17, 29, 35],
  actionAccent:        [111, 199, 184],
  actionNoteBorder:    [34, 60, 62],
}

// Light palette — warm off-white pages, deep bronze gold, near-black text.
// All tones chosen for print legibility at 300dpi.
const LIGHT_PALETTE: Palette = {
  gold:         [150, 108, 20],   // deep bronze — legible on white
  goldDim:      [200, 172, 110],
  goldText:     [150, 108, 20],
  pageBg:       [250, 248, 243],  // warm off-white
  headerBg:     [250, 248, 243],
  briefBg:      [232, 240, 228],  // light sage wash
  synthBg:      [234, 242, 230],
  decisionBg:   [242, 236, 222],  // light cream wash
  pushbackBg:   [228, 234, 244],
  bodyText:     [40,  38,  34],   // near-black warm
  mutedText:    [120, 114, 104],
  dimText:      [165, 160, 150],
  ruleGold:     [225, 205, 165],
  ruleMid:      [215, 210, 200],
  white:        [30,  28,  24],   // unused in practice; kept for key parity
  goldLight:    [140, 100, 40],   // pushback label
  pushbackText: [55,  65,  90],   // pushback body — readable on light
  verdictBg:           [249, 238, 211],
  verdictAccent:       [150, 108, 20],
  tensionHighlightBg:  [251, 243, 222],
  actionBg:            [232, 239, 233],
  actionAccent:        [26, 138, 118],
  actionNoteBorder:    [199, 222, 214],
}

// Persona accent backgrounds — dark vs light
const PERSONA_ACCENT_DARK: Record<string, [number, number, number]> = {
  synthesis:         [15,  22,  15],
  contrarian:        [60,  18,  18],
  risk_architect:    [11,  22,  56],
  pattern_analyst:   [11,  32,  22],
  stakeholder_mirror:[28,  12,  46],
  elder:             [38,  24,  8],
  competitor:        [22,  16,  6],
}

const PERSONA_ACCENT_LIGHT: Record<string, [number, number, number]> = {
  synthesis:         [228, 238, 224],
  contrarian:        [250, 224, 220],
  risk_architect:    [220, 230, 248],
  pattern_analyst:   [222, 240, 228],
  stakeholder_mirror:[240, 226, 248],
  elder:             [248, 236, 210],
  competitor:        [242, 240, 216],
}

// ── PDF builder ───────────────────────────────────────────────────────────────
// v3 fixes:
//   A) Always set font BEFORE splitTextToSize — bold font metrics were bleeding
//      into normal-text wrapping, causing text to clip/overflow
//   B) Markdown renderer for Decision Brief — **bold**, *italic*, ---, - bullets,
//      numbered lists, ## headings all parsed and rendered correctly
//   C) Decision block rendered line-by-line (no pre-calc box height)

interface ExaminerQA { question_text: string; response_text: string | null; question_order: number }

async function buildPdf(
  session: {
    decision_text: string; context_text?: string | null; created_at: string; id: string
    // Unified session, point 7 — all optional so a pre-migration or flag-off
    // session (all null/undefined) renders exactly as before, no new page.
    initial_instinct?:            'accept' | 'reject' | 'unsure' | null
    optimization_priority?:       string | null
    quorum_predicted_choice?:     string | null
    quorum_prediction_reasoning?: string | null
    final_decision?:              string | null
    prediction_matched_final?:    boolean | null
  },
  messages: { persona: string; role: string; content: string }[],
  examinerQAs: ExaminerQA[] = [],
  theme: 'dark' | 'light' = 'dark',
): Promise<Buffer> {
  // ── Theme selection — every C.xxx and PERSONA_ACCENT[key] reference below
  // resolves to the active palette without any other code changes needed.
  const C              = theme === 'light' ? LIGHT_PALETTE      : DARK_PALETTE
  const PERSONA_ACCENT = theme === 'light' ? PERSONA_ACCENT_LIGHT : PERSONA_ACCENT_DARK

  const { jsPDF } = await import('jspdf')

  const doc  = new jsPDF({ unit: 'pt', format: 'a4', putOnlyUsedFonts: true })
  const PW   = doc.internal.pageSize.getWidth()
  const PH   = doc.internal.pageSize.getHeight()
  const ML   = 56
  const MR   = 56
  const TW   = PW - ML - MR
  const BOTTOM_MARGIN = 60
  let   Y    = 0
  let   page = 1

  // ── Page fill (uses C.pageBg — resolves to dark or light depending on theme) ──
  const fillPage = () => {
    doc.setFillColor(...C.pageBg)
    doc.rect(0, 0, PW, PH, 'F')
  }
  fillPage()

  // ── Footer ────────────────────────────────────────────────────────────────────
  const drawFooter = () => {
    doc.setDrawColor(...C.ruleMid)
    doc.setLineWidth(0.3)
    doc.line(ML, PH - 40, PW - MR, PH - 40)
    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.mutedText)
    doc.text(`Private \xB7 Quorum`, ML, PH - 26)
    doc.text(String(page), PW - MR, PH - 26, { align: 'right' })
  }

  // ── Page break ────────────────────────────────────────────────────────────────
  const ensure = (needed: number) => {
    if (Y + needed > PH - BOTTOM_MARGIN) {
      doc.addPage()
      fillPage()
      page++
      Y = 52
      drawFooter()
    }
  }

  // ── Body text (prose) ─────────────────────────────────────────────────────────
  // CRITICAL: font must be set BEFORE splitTextToSize — jsPDF uses current font
  // metrics for wrapping. If a bold header was drawn previously, wrapping uses
  // bold metrics but text renders in normal → lines overflow their measured width.
  const bodyBlock = (raw: string, indent = 0, size = 10.5, color = C.bodyText) => {
    const text = sanitise(raw).replace(/\r\n/g, '\n').replace(/\r/g, '\n')
    const lh   = size * 1.58
    // Split on actual newlines first, then wrap each paragraph
    const paragraphs = text.split('\n')
    for (const para of paragraphs) {
      if (!para.trim()) { Y += lh * 0.4; continue }
      // SET FONT BEFORE SPLIT — fixes metric mismatch bug
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(size)
      const lines = doc.splitTextToSize(para, TW - indent) as string[]
      for (const line of lines) {
        ensure(lh + 2)
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(size)
        doc.setTextColor(...color)
        doc.text(line, ML + indent, Y)
        Y += lh
      }
    }
    Y += 5
  }

  // ── Synthesis verdict + tension rendering ──────────────────────────────────
  // Mirrors the live session view (components/SynthesisCard.tsx): the verdict
  // is pulled out into a gold accent box; the tension sentence stays inline in
  // the prose with a highlighted background. Both use theme-aware palette colors.

  const VERDICT_SIZE = 12.5

  // Truncate to first complete sentence — guards against the model writing
  // more than one sentence inside <verdict>, same rule as the web renderer.
  const firstSentencePdf = (text: string): string => {
    const m = text.match(/^[^.!?]*[.!?]/)
    return m ? m[0].trim() : text.trim()
  }

  // Decision Action Plan / Confidence to Act: 3–4 items (resp. at most 1),
  // each "**lead phrase** — clause", pipe-separated (same wire format as
  // <conditions>). Mirrors components/SynthesisCard.tsx's parseActionPlan
  // exactly, so the PDF's own box (renderActionPlanBoxPdf below) matches the
  // "What to do next" / "Before you act" sections shown live.
  const parseActionPlanPdf = (raw: string): { lead: string; rest: string }[] =>
    raw.split('|').map(s => s.trim()).filter(Boolean).map(item => {
      const m = item.match(/^\*\*(.+?)\*\*\s*[—-]\s*(.*)$/)
      return m ? { lead: m[1].trim(), rest: m[2].trim() } : { lead: '', rest: item }
    })

  // Strips verdict + conditions (returned separately) and leaves tension tags
  // intact in `rest` for renderSynthesisBody to locate per-paragraph.
  const parseVerdictTension = (raw: string): { verdict: string | null; conditions: string[]; counterfactual: string | null; keyQuestion: string | null; actionPlan: { lead: string; rest: string }[]; confidenceToAct: { lead: string; rest: string } | null; rest: string } => {
    const vMatch = raw.match(/<verdict>([\s\S]*?)<\/verdict>/)
    const verdict = vMatch?.[1]?.trim() ? firstSentencePdf(vMatch[1].trim()) : null
    const cMatch = raw.match(/<conditions>([\s\S]*?)<\/conditions>/)
    const conditions = cMatch?.[1] ? cMatch[1].split('|').map(s => s.trim()).filter(Boolean) : []
    // Counterfactual Analysis (new tag) — same extraction shape as
    // keyQuestion below: optional, at most one, no pipe-split.
    const cfMatch = raw.match(/<counterfactual>([\s\S]*?)<\/counterfactual>/)
    const counterfactual = cfMatch?.[1]?.trim() ?? null
    // Bug fix: this file never extracted <key_question> at all — not even a
    // strip-and-discard line, unlike verdict/conditions above — so it printed
    // as raw, visible <key_question>...</key_question> markup in the PDF
    // (confirmed: session 8814F91F's PDF). Same tag, same "worth confirming"
    // framing the record page and live SessionView already give it (see
    // app/record/[id]/page.tsx's keyQuestion / SynthesisCard.tsx's
    // worthConfirming) — extracted here so this PDF can give it the same
    // callout treatment instead of leaking the tag or silently dropping it.
    const kqMatch = raw.match(/<key_question>([\s\S]*?)<\/key_question>/)
    const keyQuestion = kqMatch?.[1]?.trim() ?? null
    // Bug fix (tag-wiring guardrail gap): this file's independent copy of
    // tag-handling never learned about <action_plan>/<confidence_to_act> at
    // all — unlike every other synthesis tag here, there wasn't even a
    // strip-and-discard line for them, so they printed as raw, visible
    // <action_plan>/<confidence_to_act> markup in the generated PDF. Extract
    // them the same way <conditions> already is, so renderActionPlanBoxPdf
    // below can give them their own box instead of just deleting them.
    const apMatch = raw.match(/<action_plan>([\s\S]*?)<\/action_plan>/)
    const actionPlan = apMatch?.[1] ? parseActionPlanPdf(apMatch[1]) : []
    const caMatch = raw.match(/<confidence_to_act>([\s\S]*?)<\/confidence_to_act>/)
    const confidenceToAct = caMatch?.[1] ? (parseActionPlanPdf(caMatch[1])[0] ?? null) : null
    const rest = raw
      .replace(/<verdict>[\s\S]*?<\/verdict>\n*/, '')
      .replace(/<verdict>[\s\S]*/, '')   // guard: open tag without close
      // P2 fix: these were never stripped here — the actual source of the
      // raw-tag leak, since `rest` is what gets rendered as the PDF's body text.
      .replace(/<verdict_lean>[\s\S]*?<\/verdict(?:_lean)?>\n*/, '')
      .replace(/<conditions>[\s\S]*?<\/conditions>\n*/, '')
      // Same fix as above: extracted into its own line, must not also remain
      // in the flowing body text.
      .replace(/<counterfactual>[\s\S]*?<\/counterfactual>\n*/, '')
      // Guardrail follow-up: this file had no fallback at all for
      // verdict_lean/conditions (only key_question/action_plan/
      // confidence_to_act did, from the earlier fix) — a cut-off mid-tag
      // generation would leak raw markup for these two specifically.
      .replace(/<(?:verdict_lean|conditions|counterfactual)>[\s\S]*$/, '') // guard: open tag without close
      // Same fix as above: extracted into its own callout, must not also
      // remain in the flowing body text. Includes a guard for the
      // unclosed-tag case, same rationale as action_plan/confidence_to_act below.
      .replace(/<key_question>[\s\S]*?<\/key_question>\n*/, '')
      .replace(/<key_question>[\s\S]*$/, '')           // guard: open tag without close
      // Same fix as above: extracted into their own box, must not also
      // remain in the flowing body text. Includes a guard for the
      // unclosed-tag case (a synthesis run cut short before
      // </action_plan>/</confidence_to_act> arrived — see lib/ai-client.ts
      // max_tokens note) so a truncated run degrades to "missing section"
      // rather than "raw tag markup printed in the PDF".
      .replace(/<action_plan>[\s\S]*?<\/action_plan>\n*/, '')
      .replace(/<action_plan>[\s\S]*$/, '')            // guard: open tag without close
      .replace(/<confidence_to_act>[\s\S]*?<\/confidence_to_act>\n*/, '')
      .replace(/<confidence_to_act>[\s\S]*$/, '')       // guard: open tag without close
      .trimStart()
    return { verdict, conditions, counterfactual, keyQuestion, actionPlan, confidenceToAct, rest }
  }

  const renderVerdictBoxPdf = (verdictText: string, conditions: string[] = [], counterfactual: string | null = null) => {
    // Layout is computed top-down with explicit baseline math (label baseline,
    // then verdict baseline) instead of a fixed labelGap — the previous fixed
    // gap (13pt) was tuned for the label's old font size and didn't account for
    // VERDICT_SIZE's actual ascent, so the verdict text's cap-height crept up
    // into the "COUNCIL VERDICT" label above it.
    const padTop = 14, padBottom = 14, padX = 16
    const labelSize = 7.5
    const labelToVerdictGap = labelSize * 1.9   // generous clearance below label

    doc.setFont('Helvetica', 'normal')   // verdict sentence is not bold (display weight, not heavy)
    doc.setFontSize(VERDICT_SIZE)
    const wrapped: string[] = doc.splitTextToSize(verdictText, TW - padX * 2) as string[]
    const lh   = VERDICT_SIZE * 1.4

    // P2 fix: conditions were parsed but never rendered anywhere in the PDF —
    // same "Conditional on" treatment as the web views, added to the box's
    // height budget up front so the fill rect is sized correctly.
    const condSize   = 8.5
    const condLh     = condSize * 1.5
    const condLabelGap = 12
    let condWrapped: string[][] = []
    let condH = 0
    if (conditions.length > 0) {
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(condSize)
      condWrapped = conditions.map(c => doc.splitTextToSize(`•  ${c}`, TW - padX * 2 - 6) as string[])
      const condLines = condWrapped.reduce((n, w) => n + w.length, 0)
      condH = condLabelGap + labelSize * 1.1 + (condLines * condLh)
    }

    // Counterfactual Analysis: same box treatment as conditions above, one
    // level down the point-ownership hierarchy (lib/personas.ts) — plain
    // wrapped prose rather than a bulleted list, since it's always exactly
    // one sentence pair, never a list of items.
    const cfSize = 8.5
    const cfLh   = cfSize * 1.5
    const cfLabelGap = 12
    let cfWrapped: string[] = []
    let cfH = 0
    if (counterfactual) {
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(cfSize)
      cfWrapped = doc.splitTextToSize(counterfactual, TW - padX * 2) as string[]
      cfH = cfLabelGap + labelSize * 1.1 + (cfWrapped.length * cfLh)
    }

    const boxH = padTop + labelToVerdictGap + (wrapped.length * lh) + condH + cfH + padBottom
    ensure(boxH + 14)
    const boxY = Y
    doc.setFillColor(...C.verdictBg)
    doc.rect(ML, boxY, TW, boxH, 'F')
    doc.setFillColor(...C.verdictAccent)
    doc.rect(ML, boxY, 3, boxH, 'F')

    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(labelSize)
    doc.setTextColor(...C.verdictAccent)
    doc.setCharSpace(0.8)
    doc.text('COUNCIL VERDICT', ML + padX, boxY + padTop + labelSize * 0.75)
    doc.setCharSpace(0)

    let ty = boxY + padTop + labelToVerdictGap + VERDICT_SIZE * 0.75
    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(VERDICT_SIZE)
    doc.setTextColor(...C.bodyText)
    for (const wl of wrapped) {
      doc.text(wl, ML + padX, ty)
      ty += lh
    }

    if (conditions.length > 0) {
      ty += condLabelGap
      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(labelSize)
      doc.setTextColor(...C.verdictAccent)
      doc.setCharSpace(0.6)
      doc.text('CONDITIONAL ON', ML + padX, ty)
      doc.setCharSpace(0)
      ty += labelSize * 1.1
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(condSize)
      doc.setTextColor(...C.bodyText)
      for (const wl of condWrapped) {
        for (const line of wl) {
          doc.text(line, ML + padX, ty)
          ty += condLh
        }
      }
    }

    if (counterfactual) {
      ty += cfLabelGap
      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(labelSize)
      doc.setTextColor(...C.verdictAccent)
      doc.setCharSpace(0.6)
      doc.text('IF DIFFERENT', ML + padX, ty)
      doc.setCharSpace(0)
      ty += labelSize * 1.1
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(cfSize)
      doc.setTextColor(...C.bodyText)
      for (const line of cfWrapped) {
        doc.text(line, ML + padX, ty)
        ty += cfLh
      }
    }

    Y = boxY + boxH + 14
  }

  // P2 fix: <action_plan>/<confidence_to_act> previously had no rendering
  // path in this file at all — not even a "strip and discard" line, so they
  // printed as raw tag markup. This mirrors renderVerdictBoxPdf's box
  // treatment (measure-then-draw, matching term-by-term so the fill rect's
  // height always agrees with what's actually drawn inside it) and gives
  // this content the same "What to do next" / "Before you act" sections
  // already shown on the live session view (components/SynthesisCard.tsx).
  //
  // jsPDF has no native inline bold-run support, so each item's lead phrase
  // is bolded by re-using jsPDF's own word-wrap (doc.splitTextToSize on the
  // plain "lead — rest" string) and then, on the second draw pass, walking
  // those same wrapped lines to find where the lead phrase's character span
  // falls and switching font/color at that exact point — the bold/normal
  // split can never disagree with where the text actually wrapped, since
  // it's derived from the same wrapped lines being drawn.
  const drawLeadRestWrapped = (
    wrappedLines: string[], boldLen: number, x: number, startY: number, lh: number, size: number,
    boldColor: [number, number, number] = C.actionAccent,
  ): number => {
    let consumed = 0
    let ty = startY
    for (const line of wrappedLines) {
      ensure(lh + 2)
      const lineLen = line.length
      doc.setFontSize(size)
      if (consumed >= boldLen) {
        doc.setFont('Helvetica', 'normal'); doc.setTextColor(...C.bodyText)
        doc.text(line, x, ty)
      } else if (consumed + lineLen <= boldLen) {
        doc.setFont('Helvetica', 'bold'); doc.setTextColor(...boldColor)
        doc.text(line, x, ty)
      } else {
        const splitAt   = boldLen - consumed
        const boldPart  = line.slice(0, splitAt)
        const restPart  = line.slice(splitAt)
        doc.setFont('Helvetica', 'bold'); doc.setTextColor(...boldColor)
        doc.text(boldPart, x, ty)
        const w = doc.getTextWidth(boldPart)
        doc.setFont('Helvetica', 'normal'); doc.setTextColor(...C.bodyText)
        doc.text(restPart, x + w, ty)
      }
      consumed += lineLen
      ty += lh
    }
    return ty
  }

  // Bug fix: <key_question> had no rendering path in this file at all — see
  // parseVerdictTension's keyQuestion extraction above. Record page and live
  // SessionView both show this as a "Worth confirming" note directly in the
  // flowing prose (bold lead in plain text color, not the teal action
  // accent) rather than a bordered box like the action plan gets — matched
  // here by reusing drawLeadRestWrapped with bodyText as the lead color.
  const renderWorthConfirmingPdf = (keyQuestion: string | null) => {
    if (!keyQuestion) return
    const size = 10, lh = size * 1.6
    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(size)
    const lead = 'Worth confirming'
    const combined = `${lead} — ${keyQuestion}`
    const wrapped = doc.splitTextToSize(combined, TW) as string[]
    ensure(wrapped.length * lh + 16)
    Y += 10
    Y = drawLeadRestWrapped(wrapped, lead.length, ML, Y, lh, size, C.bodyText)
    Y += 4
  }

  const renderActionPlanBoxPdf = (
    items: { lead: string; rest: string }[],
    confidenceToAct: { lead: string; rest: string } | null,
  ) => {
    if (items.length === 0) return
    const padTop = 14, padBottom = 14, padX = 16
    const labelSize = 7.5
    const labelGap  = labelSize * 1.9
    const itemSize  = 9.5
    const itemLh    = itemSize * 1.55
    const itemGap   = 8

    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(itemSize)
    const itemWraps = items.map(it => {
      const combined = it.lead ? `${it.lead} — ${it.rest}` : it.rest
      const wrapped = doc.splitTextToSize(combined, TW - padX * 2) as string[]
      return { wrapped, boldLen: it.lead ? it.lead.length : 0 }
    })
    const itemsLines = itemWraps.reduce((n, iw) => n + iw.wrapped.length, 0)
    const itemsH = itemsLines * itemLh + Math.max(0, items.length - 1) * itemGap

    const caSize        = 9
    const caLh           = caSize * 1.45
    const caTopGap       = 12
    const caLabelToBody  = labelSize * 1.3
    let caWrapped: string[] = []
    let caBoldLen = 0
    let caH = 0
    if (confidenceToAct) {
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(caSize)
      const combined = confidenceToAct.lead ? `${confidenceToAct.lead} — ${confidenceToAct.rest}` : confidenceToAct.rest
      caWrapped = doc.splitTextToSize(combined, TW - padX * 2) as string[]
      caBoldLen = confidenceToAct.lead ? confidenceToAct.lead.length : 0
      caH = caTopGap + caLabelToBody + (caWrapped.length * caLh)
    }

    const boxH = padTop + labelGap + itemsH + caH + padBottom
    ensure(boxH + 14)
    const boxY = Y
    doc.setFillColor(...C.actionBg)
    doc.rect(ML, boxY, TW, boxH, 'F')
    doc.setFillColor(...C.actionAccent)
    doc.rect(ML, boxY, 3, boxH, 'F')

    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(labelSize)
    doc.setTextColor(...C.actionAccent)
    doc.setCharSpace(0.8)
    doc.text('WHAT TO DO NEXT', ML + padX, boxY + padTop + labelSize * 0.75)
    doc.setCharSpace(0)
    doc.setFont('Helvetica', 'italic')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.mutedText)
    doc.text(
      'in order of impact',
      ML + padX + doc.getTextWidth('WHAT TO DO NEXT') + 10,
      boxY + padTop + labelSize * 0.75,
    )

    let ty = boxY + padTop + labelGap
    itemWraps.forEach((iw, i) => {
      ty = drawLeadRestWrapped(iw.wrapped, iw.boldLen, ML + padX, ty, itemLh, itemSize)
      if (i < itemWraps.length - 1) ty += itemGap
    })

    if (confidenceToAct) {
      ty += caTopGap
      doc.setDrawColor(...C.actionNoteBorder)
      doc.setLineWidth(0.5)
      doc.line(ML + padX, ty - caTopGap / 2, ML + TW - padX, ty - caTopGap / 2)
      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(labelSize)
      doc.setTextColor(...C.mutedText)
      doc.setCharSpace(0.6)
      doc.text('BEFORE YOU ACT', ML + padX, ty)
      doc.setCharSpace(0)
      ty += caLabelToBody
      ty = drawLeadRestWrapped(caWrapped, caBoldLen, ML + padX, ty, caLh, caSize)
    }

    Y = boxY + boxH + 14
  }

  // Renders one paragraph as continuous prose with a highlighted background
  // run behind the [hlStart, hlEnd) character range — used for the sentence
  // wrapped in <tension> tags. Word-level wrap with manual width measurement
  // since jsPDF has no native inline-span styling.
  const renderTensionParagraph = (full: string, hlStart: number, hlEnd: number, size: number, lh: number) => {
    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(size)
    const rawTokens = full.split(/(\s+)/)
    let charPos = 0
    const tokens: { text: string; hl: boolean }[] = []
    for (const t of rawTokens) {
      const start = charPos, end = charPos + t.length
      tokens.push({ text: t, hl: t.trim().length > 0 && start < hlEnd && end > hlStart })
      charPos = end
    }
    const lines: (typeof tokens)[] = []
    let line: typeof tokens = []
    let lineW = 0
    for (const tok of tokens) {
      const w = doc.getTextWidth(tok.text)
      if (lineW + w > TW && line.length > 0) {
        lines.push(line); line = []; lineW = 0
        if (tok.text.trim().length === 0) continue   // drop leading space on wrapped line
      }
      line.push(tok); lineW += w
    }
    if (line.length) lines.push(line)

    for (const ln of lines) {
      ensure(lh + 4)
      // Pass 1 — highlight background runs (contiguous hl tokens share one rect)
      let cx = ML, runStart = -1, runX = ML
      for (let i = 0; i < ln.length; i++) {
        const w = doc.getTextWidth(ln[i].text)
        if (ln[i].hl) {
          if (runStart === -1) { runStart = i; runX = cx }
        } else if (runStart !== -1) {
          doc.setFillColor(...C.tensionHighlightBg)
          doc.rect(runX, Y - size * 0.82, cx - runX, size * 1.12, 'F')
          runStart = -1
        }
        cx += w
      }
      if (runStart !== -1) {
        doc.setFillColor(...C.tensionHighlightBg)
        doc.rect(runX, Y - size * 0.82, cx - runX, size * 1.12, 'F')
      }
      // Pass 2 — text on top
      cx = ML
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(size)
      doc.setTextColor(...C.bodyText)
      for (const tok of ln) {
        doc.text(tok.text, cx, Y)
        cx += doc.getTextWidth(tok.text)
      }
      Y += lh
    }
  }

  // Synthesis prose body — same paragraph/blank-line handling as bodyBlock,
  // but detects the paragraph containing <tension>...</tension> and routes it
  // through renderTensionParagraph for the inline highlight; all other
  // paragraphs render with the standard wrap.
  const renderSynthesisBody = (raw: string) => {
    const size = 10.5, lh = size * 1.58
    const text = raw.replace(/\r\n/g, '\n').replace(/\r/g, '\n')
    for (const para of text.split('\n')) {
      if (!para.trim()) { Y += lh * 0.4; continue }
      const tStart = para.indexOf('<tension>')
      const tEnd   = para.indexOf('</tension>')
      if (tStart !== -1 && tEnd !== -1 && tEnd > tStart) {
        const before  = para.slice(0, tStart)
        const content = para.slice(tStart + '<tension>'.length, tEnd)
        const after   = para.slice(tEnd + '</tension>'.length)
        const full    = before + content + after
        renderTensionParagraph(full, before.length, before.length + content.length, size, lh)
      } else {
        const cleanPara = para.replace(/<\/?tension>/g, '')
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(size)
        const wrapped: string[] = doc.splitTextToSize(cleanPara, TW) as string[]
        for (const wl of wrapped) {
          ensure(lh + 2)
          doc.setFont('Helvetica', 'normal')
          doc.setFontSize(size)
          doc.setTextColor(...C.bodyText)
          doc.text(wl, ML, Y)
          Y += lh
        }
      }
    }
    Y += 5
  }


  type Seg = { text: string; bold: boolean; italic: boolean }
  const parseInline = (raw: string): Seg[] => {
    const segs: Seg[] = []
    // Replace **text** and *text* with markers, then split
    const re = /(\*\*(.+?)\*\*|\*(.+?)\*)/g
    let last = 0; let m: RegExpExecArray | null
    while ((m = re.exec(raw)) !== null) {
      if (m.index > last) segs.push({ text: raw.slice(last, m.index), bold: false, italic: false })
      if (m[0].startsWith('**')) segs.push({ text: m[2], bold: true, italic: false })
      else segs.push({ text: m[3], bold: false, italic: true })
      last = m.index + m[0].length
    }
    if (last < raw.length) segs.push({ text: raw.slice(last), bold: false, italic: false })
    return segs.filter(s => s.text)
  }

  const renderSegments = (segs: Seg[], x: number, size: number, color: [number,number,number]) => {
    let cx = x
    for (const seg of segs) {
      const style = seg.bold ? 'bold' : seg.italic ? 'italic' : 'normal'
      doc.setFont('Helvetica', style)
      doc.setFontSize(size)
      doc.setTextColor(...color)
      const w = doc.getTextWidth(sanitise(seg.text))
      doc.text(sanitise(seg.text), cx, Y)
      cx += w
    }
  }

  // ── Markdown renderer (for Decision Brief content) ────────────────────────────
  // Handles: **bold**, *italic*, ---, - bullets, 1. numbered, ## headings
  const renderMarkdown = (raw: string) => {
    const SIZE_BODY    = 10.5
    const SIZE_SMALL   = 9.5
    const SIZE_HEADING = 11.5
    const LH_BODY      = SIZE_BODY * 1.58
    const LH_SMALL     = SIZE_SMALL * 1.55
    const LH_HEAD      = SIZE_HEADING * 1.5

    const text = sanitise(raw).replace(/\r\n/g, '\n').replace(/\r/g, '\n')
    const lines = text.split('\n')
    // See briefLineIsRedundantTitle in lib/brief-markdown.ts: the
    // decision_brief persona sometimes opens with a redundant title line
    // restating "Decision Brief" — already shown by this PDF's own gold
    // section band just above — and its dash/box-drawing decoration isn't
    // supported by the base Helvetica encoding `sanitise` targets, so
    // instead of being recognized as a heading it fell through to plain
    // text and rendered as a run of literal "?" characters (confirmed:
    // session 8814F91F's PDF). Skipped below rather than drawn.
    const firstContentIdx = lines.findIndex(l => l.trim().length > 0)

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      const trimmed = line.trim()

      // Blank line → small gap
      if (!trimmed) {
        Y += LH_BODY * 0.35
        continue
      }

      if (i === firstContentIdx && briefLineIsRedundantTitle(trimmed)) continue

      // Horizontal rule ---
      if (/^---+$/.test(trimmed)) {
        ensure(16)
        Y += 4
        doc.setDrawColor(...C.ruleGold)
        doc.setLineWidth(0.3)
        doc.line(ML, Y, PW - MR, Y)
        Y += 10
        continue
      }

      // ALL CAPS section label (e.g. KEY INSIGHTS, RISKS, RECOMMENDED DIRECTION)
      // Detect: trimmed line is ≥2 words, all uppercase letters/spaces/punctuation, no lowercase
      const isAllCaps = trimmed.length > 3
        && /^[A-Z][A-Z\s\-–:&/()]{2,}$/.test(trimmed)
        && !/^[-•*\d]/.test(trimmed)
      if (isAllCaps) {
        ensure(LH_HEAD + 10)
        Y += 6
        doc.setFont('Helvetica', 'bold')
        doc.setFontSize(SIZE_HEADING)
        doc.setTextColor(...C.gold)
        doc.setCharSpace(0.8)
        doc.text(trimmed, ML, Y)
        doc.setCharSpace(0)
        // Thin underline
        const labelW = doc.getTextWidth(trimmed)
        doc.setDrawColor(...C.ruleGold)
        doc.setLineWidth(0.4)
        doc.line(ML, Y + 4, ML + labelW, Y + 4)
        Y += LH_HEAD + 2
        continue
      }

      // ## Heading / **Heading** (whole line is bold heading)
      const headingMatch = trimmed.match(/^#{1,3}\s+(.+)$/)
      const boldLineMatch = trimmed.match(/^\*\*([^*]+)\*\*\s*$/)
      if (headingMatch || boldLineMatch) {
        const headText = headingMatch ? headingMatch[1] : boldLineMatch![1]
        ensure(LH_HEAD + 4)
        Y += 3
        doc.setFont('Helvetica', 'bold')
        doc.setFontSize(SIZE_HEADING)
        doc.setTextColor(...C.bodyText)
        const wLines = doc.splitTextToSize(sanitise(headText), TW) as string[]
        for (const wl of wLines) {
          ensure(LH_HEAD)
          doc.setFont('Helvetica', 'bold')
          doc.setFontSize(SIZE_HEADING)
          doc.setTextColor(...C.bodyText)
          doc.text(wl, ML, Y)
          Y += LH_HEAD
        }
        Y += 3
        continue
      }

      // - Bullet item (may contain inline bold/italic)
      const bulletMatch = trimmed.match(/^[-•*]\s+(.+)$/)
      if (bulletMatch) {
        const bulletText = bulletMatch[1]
        const INDENT = 20
        ensure(LH_BODY + 2)
        // Draw bullet dot
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(SIZE_BODY)
        doc.setFillColor(...C.gold)
        doc.circle(ML + 5, Y - 3.5, 1.5, 'F')
        // Parse inline bold in bullet text
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(SIZE_BODY)
        const wrapWidth = TW - INDENT
        const segs = parseInline(bulletText)
        // Measure total line in normal font to see if it fits
        const fullText = segs.map(s => sanitise(s.text)).join('')
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(SIZE_BODY)
        const wLines = doc.splitTextToSize(fullText, wrapWidth) as string[]
        if (wLines.length === 1) {
          // Single line — render inline segments
          renderSegments(segs, ML + INDENT, SIZE_BODY, C.bodyText)
          Y += LH_BODY
        } else {
          // Multi-line bullet — render plain (inline bold too complex to wrap)
          for (const wl of wLines) {
            ensure(LH_SMALL)
            doc.setFont('Helvetica', 'normal')
            doc.setFontSize(SIZE_SMALL)
            doc.setTextColor(...C.bodyText)
            doc.text(wl, ML + INDENT, Y)
            Y += LH_SMALL
          }
        }
        continue
      }

      // 1. Numbered list item
      const numMatch = trimmed.match(/^(\d+)\.\s+(.+)$/)
      if (numMatch) {
        const num = numMatch[1]
        const itemText = numMatch[2]
        const INDENT = 22
        ensure(LH_BODY + 2)
        doc.setFont('Helvetica', 'bold')
        doc.setFontSize(SIZE_BODY)
        doc.setTextColor(...C.gold)
        doc.text(`${num}.`, ML, Y)
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(SIZE_BODY)
        doc.setTextColor(...C.bodyText)
        const wLines = doc.splitTextToSize(sanitise(itemText), TW - INDENT) as string[]
        for (let j = 0; j < wLines.length; j++) {
          ensure(LH_SMALL)
          doc.setFont('Helvetica', 'normal')
          doc.setFontSize(j === 0 ? SIZE_BODY : SIZE_SMALL)
          doc.setTextColor(...C.bodyText)
          doc.text(wLines[j], ML + INDENT, Y)
          Y += j === 0 ? LH_BODY : LH_SMALL
        }
        continue
      }

      // Regular paragraph (may have inline bold/italic — e.g. **Label:** text)
      const segs = parseInline(trimmed)
      const hasInline = segs.some(s => s.bold || s.italic)

      if (hasInline) {
        // Measure as plain text first to check wrapping
        const fullText = segs.map(s => sanitise(s.text)).join('')
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(SIZE_BODY)
        const wLines = doc.splitTextToSize(fullText, TW) as string[]
        if (wLines.length === 1) {
          ensure(LH_BODY + 2)
          renderSegments(segs, ML, SIZE_BODY, C.bodyText)
          Y += LH_BODY
        } else {
          // Multi-line inline: render first line with segments, rest as normal
          ensure(LH_BODY + 2)
          // First line: render with inline formatting up to first wrap point
          // Simplification: render the first segment as bold if it ends with ':',
          // then the rest as normal wrapped text
          if (segs[0]?.bold && segs[0].text.trim().endsWith(':')) {
            const labelW = (() => {
              doc.setFont('Helvetica', 'bold')
              doc.setFontSize(SIZE_BODY)
              return doc.getTextWidth(sanitise(segs[0].text))
            })()
            doc.setFont('Helvetica', 'bold')
            doc.setFontSize(SIZE_BODY)
            doc.setTextColor(...C.bodyText)
            doc.text(sanitise(segs[0].text), ML, Y)
            // Wrap the rest after the bold label
            const rest = segs.slice(1).map(s => sanitise(s.text)).join('')
            doc.setFont('Helvetica', 'normal')
            doc.setFontSize(SIZE_SMALL)
            const restLines = doc.splitTextToSize(rest.trim(), TW - labelW - 4) as string[]
            if (restLines[0]) {
              doc.setTextColor(...C.bodyText)
              doc.text(restLines[0], ML + labelW + 4, Y)
            }
            Y += LH_BODY
            for (let k = 1; k < restLines.length; k++) {
              ensure(LH_SMALL)
              doc.setFont('Helvetica', 'normal')
              doc.setFontSize(SIZE_SMALL)
              doc.setTextColor(...C.bodyText)
              doc.text(restLines[k], ML, Y)
              Y += LH_SMALL
            }
          } else {
            // Render all lines as normal text (strip bold markers)
            for (const wl of wLines) {
              ensure(LH_SMALL)
              doc.setFont('Helvetica', 'normal')
              doc.setFontSize(SIZE_SMALL)
              doc.setTextColor(...C.bodyText)
              doc.text(wl, ML, Y)
              Y += LH_SMALL
            }
          }
        }
      } else {
        // Pure plain text paragraph
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(SIZE_BODY)
        const wLines = doc.splitTextToSize(sanitise(trimmed), TW) as string[]
        for (const wl of wLines) {
          ensure(LH_BODY)
          doc.setFont('Helvetica', 'normal')
          doc.setFontSize(SIZE_BODY)
          doc.setTextColor(...C.bodyText)
          doc.text(wl, ML, Y)
          Y += LH_BODY
        }
      }
      Y += 3
    }
    Y += 4
  }

  // ── Examiner Q&A renderer ────────────────────────────────────────────────────
  const renderExaminerQA = (qas: ExaminerQA[]) => {
    if (!qas.length) return
    ensure(24)
    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(8.5)
    doc.setTextColor(...C.gold)
    doc.setCharSpace(1.2)
    doc.text('EXAMINER -- QUESTIONS & ANSWERS', ML, Y)
    doc.setCharSpace(0)
    Y += 8
    doc.setDrawColor(...C.ruleGold)
    doc.setLineWidth(0.3)
    doc.line(ML, Y, PW - MR, Y)
    Y += 14

    const sorted = [...qas].sort((a, b) => a.question_order - b.question_order)
    for (const qa of sorted) {
      const SIZE_Q = 9.5
      const SIZE_A = 9.5
      const LH_Q   = SIZE_Q * 1.5
      const LH_A   = SIZE_A * 1.5
      const qLabel = `Q${qa.question_order}  `

      // Question — gold label + body text
      ensure(LH_Q + 4)
      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(SIZE_Q)
      doc.setTextColor(...C.gold)
      doc.text(qLabel, ML, Y)
      const qLabelW = doc.getTextWidth(qLabel)
      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(SIZE_Q)
      doc.setTextColor(...C.bodyText)
      const qLines = doc.splitTextToSize(sanitise(qa.question_text), TW - qLabelW) as string[]
      for (let qi = 0; qi < qLines.length; qi++) {
        if (qi > 0) ensure(LH_Q)
        doc.setFont('Helvetica', qi === 0 ? 'bold' : 'normal')
        doc.setFontSize(SIZE_Q)
        doc.setTextColor(...C.bodyText)
        doc.text(qLines[qi], qi === 0 ? ML + qLabelW : ML + qLabelW, Y)
        Y += LH_Q
      }
      Y += 4

      // Answer — italicised, indented, muted colour
      const answerText = qa.response_text?.trim() || '(no answer provided)'
      ensure(LH_A + 4)
      doc.setFont('Helvetica', 'italic')
      doc.setFontSize(SIZE_A)
      doc.setTextColor(...C.mutedText)
      const aLines = doc.splitTextToSize(sanitise(answerText), TW - 12) as string[]
      for (const al of aLines) {
        ensure(LH_A)
        doc.setFont('Helvetica', 'italic')
        doc.setFontSize(SIZE_A)
        doc.setTextColor(...C.mutedText)
        doc.text(al, ML + 12, Y)
        Y += LH_A
      }
      Y += 10

      // Thin separator between questions
      doc.setDrawColor(...C.ruleMid)
      doc.setLineWidth(0.2)
      doc.line(ML + 12, Y, PW - MR, Y)
      Y += 8
    }
    Y += 6
  }

  // ── Thin rule ─────────────────────────────────────────────────────────────────
  const rule = (color = C.ruleGold, weight = 0.3) => {
    ensure(16)
    Y += 2
    doc.setDrawColor(...color)
    doc.setLineWidth(weight)
    doc.line(ML, Y, PW - MR, Y)
    Y += 12
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // COVER — full dark page with gold wordmark
  // ═══════════════════════════════════════════════════════════════════════════════

  // Gold top rule — clear of any text, sits at very top
  doc.setDrawColor(...C.gold)
  doc.setLineWidth(1.2)
  doc.line(ML, 22, PW - MR, 22)

  // QUORUM wordmark — baseline at 56, ascender clears 22pt rule with ~18pt of air
  Y = 56
  doc.setFont('Helvetica', 'bold')
  doc.setFontSize(22)
  doc.setTextColor(...C.gold)
  doc.setCharSpace(7)
  doc.text('QUORUM', ML, Y)
  doc.setCharSpace(0)

  // Extend gold rule rightward from end of wordmark to page edge
  const wordW = (() => {
    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(22)
    // approximate: each char ~14pt wide at 22pt with charSpace 7
    return 0
  })()
  Y += 14

  // Subtitle
  doc.setFont('Helvetica', 'normal')
  doc.setFontSize(7.5)
  doc.setTextColor(...C.mutedText)
  doc.setCharSpace(2.5)
  doc.text('STRUCTURAL DECISION RECORD', ML, Y)
  doc.setCharSpace(0)
  Y += 14

  // Thin separator rule
  doc.setDrawColor(...C.ruleMid)
  doc.setLineWidth(0.3)
  doc.line(ML, Y, PW - MR, Y)
  Y += 12

  // Date + session ID
  const dateStr = new Date(session.created_at).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Kolkata',
  })
  doc.setFont('Helvetica', 'normal')
  doc.setFontSize(8.5)
  doc.setTextColor(...C.mutedText)
  doc.text(`${sanitise(dateStr)}  \xB7  Session ${session.id.slice(0, 8).toUpperCase()}`, ML, Y)
  Y += 36  // generous breathing space before THE DECISION label

  drawFooter()

  // ── Decision block (box height computed upfront, then drawn) ────────────────

  // "THE DECISION" eyebrow label
  doc.setFont('Helvetica', 'bold')
  doc.setFontSize(7.5)
  doc.setTextColor(...C.mutedText)
  doc.setCharSpace(1.5)
  doc.text('THE DECISION', ML, Y)
  doc.setCharSpace(0)
  Y += 14  // clear gap between label and box top

  const decText = sanitise(session.decision_text)
  const decSize = 10.5
  const decLH   = decSize * 1.58
  const decPadTop = 11, decPadBottom = 11, decPadX = 14
  doc.setFont('Helvetica', 'normal')
  doc.setFontSize(decSize)
  const decLines = doc.splitTextToSize(decText, TW - decPadX * 2) as string[]
  const decBoxH  = decPadTop + (decLines.length * decLH) + decPadBottom
  ensure(decBoxH + 10)

  const decBoxTop = Y
  doc.setFillColor(...C.decisionBg)
  doc.rect(ML, decBoxTop, TW, decBoxH, 'F')
  doc.setFillColor(...C.gold)
  doc.rect(ML, decBoxTop, 3, decBoxH, 'F')

  let decTy = decBoxTop + decPadTop + decSize * 0.75
  doc.setFont('Helvetica', 'normal')
  doc.setFontSize(decSize)
  doc.setTextColor(...C.bodyText)
  for (const dl of decLines) {
    doc.text(dl, ML + decPadX, decTy)
    decTy += decLH
  }
  Y = decBoxTop + decBoxH + 6

  if (session.context_text?.trim()) {
    ensure(20)
    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.mutedText)
    doc.setCharSpace(0.8)
    doc.text('CONTEXT', ML, Y)
    doc.setCharSpace(0)
    Y += 10
    bodyBlock(session.context_text, 0, 9.5, C.mutedText)
  }

  Y += 14

  // ═══════════════════════════════════════════════════════════════════════════════
  // SECTION 0 — Examiner Q&A (before Decision Brief, if answers exist)
  // ═══════════════════════════════════════════════════════════════════════════════

  if (examinerQAs.length > 0) {
    doc.addPage()
    fillPage()
    page++
    Y = 52
    drawFooter()
    renderExaminerQA(examinerQAs)
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // Unified session, point 7 — Prediction Arc page. Only renders when at least
  // one of the new fields exists, so a pre-migration session or one created
  // with the flag off gets no new page and no visible change at all.
  // ═══════════════════════════════════════════════════════════════════════════════

  const hasPredictionArc = !!(
    session.initial_instinct || session.quorum_predicted_choice || session.final_decision
  )

  if (hasPredictionArc) {
    doc.addPage()
    fillPage()
    page++
    Y = 52
    drawFooter()

    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(7.5)
    doc.setTextColor(...C.mutedText)
    doc.setCharSpace(1.5)
    doc.text('THE PREDICTION ARC', ML, Y)
    doc.setCharSpace(0)
    Y += 10
    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(9)
    doc.setTextColor(...C.mutedText)
    doc.text('What you started with, what Quorum guessed, and what you actually chose', ML, Y)
    Y += 26

    const INSTINCT_LABEL: Record<string, string> = {
      accept: 'Leaning yes', reject: 'Leaning no', unsure: 'Genuinely unsure',
    }
    const PRIORITY_LABEL: Record<string, string> = {
      career_growth: 'Career growth', security: 'Security', money: 'Money',
      time_freedom: 'Time / freedom', family: 'Family', other: 'Something else',
    }

    // Same eyebrow-label + accent-box pattern as THE DECISION block above,
    // repeated per field so each stage of the arc reads as its own beat
    // rather than one run-on paragraph.
    const arcField = (label: string, value: string, accentColor = C.gold) => {
      ensure(40)
      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(7.5)
      doc.setTextColor(...C.mutedText)
      doc.setCharSpace(0.8)
      doc.text(label, ML, Y)
      doc.setCharSpace(0)
      Y += 12

      const size = 11, lh = size * 1.5, padTop = 9, padBottom = 9, padX = 14
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(size)
      const lines = doc.splitTextToSize(sanitise(value), TW - padX * 2) as string[]
      const boxH = padTop + lines.length * lh + padBottom
      ensure(boxH + 10)

      const boxTop = Y
      doc.setFillColor(...C.decisionBg)
      doc.rect(ML, boxTop, TW, boxH, 'F')
      doc.setFillColor(...accentColor)
      doc.rect(ML, boxTop, 3, boxH, 'F')

      let ty = boxTop + padTop + size * 0.75
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(size)
      doc.setTextColor(...C.bodyText)
      for (const l of lines) { doc.text(l, ML + padX, ty); ty += lh }
      Y = boxTop + boxH + 16
    }

    if (session.initial_instinct) {
      arcField('INITIAL LEAN — LOCKED BEFORE QUORUM SAID ANYTHING', INSTINCT_LABEL[session.initial_instinct] ?? session.initial_instinct)
    }
    if (session.optimization_priority) {
      arcField('WHAT MATTERED MOST', PRIORITY_LABEL[session.optimization_priority] ?? session.optimization_priority)
    }
    if (session.quorum_predicted_choice) {
      const reasoningSuffix = session.quorum_prediction_reasoning ? ` — ${session.quorum_prediction_reasoning}` : ''
      arcField('QUORUM\u2019S HYPOTHESIS', `${session.quorum_predicted_choice}${reasoningSuffix}`)
    }
    if (session.final_decision) {
      arcField('WHAT YOU ACTUALLY CHOSE', session.final_decision, C.gold)
      if (session.prediction_matched_final !== null && session.prediction_matched_final !== undefined) {
        ensure(16)
        doc.setFont('Helvetica', 'normal')
        doc.setFontSize(9.5)
        doc.setTextColor(...C.mutedText)
        doc.text(
          session.prediction_matched_final ? 'Quorum predicted this outcome.' : 'This decision surprised Quorum.',
          ML, Y,
        )
        Y += 20
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // SECTION 1 — Decision Brief
  // ═══════════════════════════════════════════════════════════════════════════════

  // Deduplicate: if synthesis (or any persona) was re-run multiple times,
  // multiple initial assistant messages exist. Keep only the LAST initial assistant
  // per persona (before any user/pushback message), then all pushback exchanges.
  const rawByPersona: Record<string, Array<{ role: string; content: string }>> = {}
  for (const msg of messages) {
    if (!rawByPersona[msg.persona]) rawByPersona[msg.persona] = []
    rawByPersona[msg.persona].push({ role: msg.role, content: msg.content })
  }
  const byPersona: Record<string, Array<{ role: string; content: string }>> = {}
  for (const [key, msgs] of Object.entries(rawByPersona)) {
    const firstUserIdx = msgs.findIndex(m => m.role === 'user')
    const initialBlock = firstUserIdx === -1 ? msgs : msgs.slice(0, firstUserIdx)
    const exchanges    = firstUserIdx === -1 ? []   : msgs.slice(firstUserIdx)
    const latestInitial = initialBlock.filter(m => m.role === 'assistant').slice(-1)
    byPersona[key] = [...latestInitial, ...exchanges]
  }

  const briefMsgs = byPersona['decision_brief']
  if (briefMsgs && briefMsgs.length > 0) {
    // Always start the Decision Brief on its own page — never inline after the cover
    doc.addPage()
    fillPage()
    page++
    Y = ML
    drawFooter()

    const bandH = 44
    doc.setFillColor(...C.briefBg)
    doc.rect(0, Y, PW, bandH, 'F')
    doc.setDrawColor(...C.gold)
    doc.setLineWidth(1)
    doc.line(0, Y, PW, Y)
    doc.setFillColor(...C.gold)
    doc.rect(0, Y, 4, bandH, 'F')

    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(14)
    doc.setTextColor(...C.gold)
    doc.setCharSpace(2)
    doc.text('DECISION BRIEF', ML, Y + 18)
    doc.setCharSpace(0)

    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(8)
    doc.setTextColor(...C.mutedText)
    doc.text('Prepared by Quorum Council  \xB7  Confidential', ML, Y + 33)

    Y += bandH + 16

    for (const msg of briefMsgs) {
      if (msg.role === 'user') {
        ensure(32)
        doc.setFont('Helvetica', 'bold')
        doc.setFontSize(7.5)
        doc.setTextColor(...C.goldLight)
        doc.setCharSpace(0.8)
        doc.text('YOUR PUSHBACK', ML, Y)
        doc.setCharSpace(0)
        Y += 12
        bodyBlock(cleanPushbackText(msg.content), 4, 9.5, C.pushbackText)
      } else {
        // Strip any redundant "DECISION BRIEF" / "THE DECISION BRIEF" first line
        // the AI sometimes echoes it back; we already render it in the header band
        const cleaned = msg.content
          .replace(/^\s*\*{0,2}(THE\s+)?DECISION BRIEF\*{0,2}\s*\n?/i, '')
          .replace(/^\s*#{1,3}\s*(THE\s+)?DECISION BRIEF\s*\n?/i, '')
          .trimStart()
        renderMarkdown(cleaned)
      }
    }

    Y += 10
    rule(C.goldDim, 0.5)
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // SECTION 2 — Appendix
  // ═══════════════════════════════════════════════════════════════════════════════

  const hasAppendix = APPENDIX_ORDER.some(k => byPersona[k]?.length > 0)
  if (hasAppendix) {
    // Appendix divider — new dark page, centred
    doc.addPage()
    fillPage()
    page++
    drawFooter()

    const midY = PH / 2 - 20
    doc.setDrawColor(...C.ruleMid)
    doc.setLineWidth(0.4)
    doc.line(ML, midY, PW - MR, midY)

    doc.setFont('Helvetica', 'bold')
    doc.setFontSize(11)
    doc.setTextColor(...C.mutedText)
    doc.setCharSpace(3)
    doc.text('APPENDIX', ML, midY + 18)
    doc.setCharSpace(0)

    doc.setFont('Helvetica', 'normal')
    doc.setFontSize(8)
    doc.setTextColor(...C.dimText)
    doc.text('Full Council Analysis  \xB7  Synthesis  \xB7  Advisor Responses', ML, midY + 32)

    doc.setDrawColor(...C.ruleMid)
    doc.setLineWidth(0.4)
    doc.line(ML, midY + 44, PW - MR, midY + 44)

    // ── Appendix: Examiner Q&A page ──────────────────────────────────────────
    if (examinerQAs.length > 0) {
      doc.addPage()
      fillPage()
      page++
      Y = 52
      drawFooter()

      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(11)
      doc.setTextColor(...C.gold)
      doc.setCharSpace(2)
      doc.text('EXAMINER', ML, Y)
      doc.setCharSpace(0)
      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(8)
      doc.setTextColor(...C.mutedText)
      doc.text('Questions posed and answers provided before the Council ran', ML, Y + 14)
      Y += 30

      doc.setDrawColor(...C.ruleGold)
      doc.setLineWidth(0.3)
      doc.line(ML, Y, PW - MR, Y)
      Y += 16

      renderExaminerQA(examinerQAs)
    }

    // ── One page per appendix persona ─────────────────────────────────────────
    for (const key of APPENDIX_ORDER) {
      const msgs = byPersona[key]
      if (!msgs || msgs.length === 0) continue

      const persona     = PERSONAS[key as PersonaKey]
      const accentRgb   = PERSONA_ACCENT[key] ?? [11, 16, 32]
      const isSynthesis = key === 'synthesis'

      doc.addPage()
      fillPage()
      page++
      Y = ML
      drawFooter()

      // Guard: if less than 120pt left, start a fresh page for this persona
      if (Y + 120 > PH - BOTTOM_MARGIN) {
        doc.addPage(); fillPage(); page++; Y = ML; drawFooter()
      }

      // Persona header band — height now has enough bottom margin under the
      // tagline baseline so the colored band background fully covers both
      // lines of text (previously the tagline's descenders sat right at, or
      // past, the band's bottom edge, making the fill look like it "cut off"
      // before the text ended).
      const hBg  = isSynthesis ? C.synthBg : accentRgb
      const hH   = isSynthesis ? 30 : 26
      doc.setFillColor(...hBg)
      doc.rect(0, Y - 4, PW, hH, 'F')
      doc.setDrawColor(...C.gold)
      doc.setLineWidth(isSynthesis ? 1.5 : 0.6)
      doc.line(0, Y - 4, PW, Y - 4)

      doc.setFont('Helvetica', 'bold')
      doc.setFontSize(isSynthesis ? 13 : 11)
      doc.setTextColor(...C.gold)
      doc.text(sanitise(persona.label.toUpperCase()), ML, Y + 7)

      doc.setFont('Helvetica', 'normal')
      doc.setFontSize(8)
      doc.setTextColor(...C.mutedText)
      doc.text(sanitise(persona.tagline ?? ''), ML, Y + 17)

      Y += hH + 6

      // Gold rule — drawn AFTER Y is past the header band
      doc.setDrawColor(...C.ruleGold)
      doc.setLineWidth(0.3)
      doc.line(ML, Y, PW - MR, Y)
      Y += 12

      if (!isSynthesis) {
        const assistantMsgs  = msgs.filter(m => m.role === 'assistant')
        const realCost       = extractTag(assistantMsgs[0]?.content ?? '', 'realcost')
        const initialLeanRaw = extractTag(assistantMsgs[0]?.content ?? '', 'lean').toLowerCase()
        const finalLeanRaw   = extractTag(assistantMsgs[assistantMsgs.length - 1]?.content ?? '', 'lean').toLowerCase()
        const initialLean    = LEAN_LABELS[initialLeanRaw] ? initialLeanRaw : ''
        const finalLean      = LEAN_LABELS[finalLeanRaw]   ? finalLeanRaw   : ''

        if (initialLean) {
          ensure(14)
          doc.setFont('Helvetica', 'bold')
          doc.setFontSize(8.5)
          doc.setTextColor(...C.mutedText)
          const label = finalLean && finalLean !== initialLean
            ? `SHIFTED AFTER PUSHBACK -> NOW LEANING ${LEAN_LABELS[finalLean].toUpperCase()}`
            : `LEANING: ${LEAN_LABELS[initialLean].toUpperCase()}`
          doc.text(sanitise(label), ML, Y)
          Y += 14
        }

        if (realCost) {
          ensure(20)
          doc.setFont('Helvetica', 'bold')
          doc.setFontSize(7.5)
          doc.setTextColor(...C.goldLight)
          doc.setCharSpace(0.8)
          doc.text('REAL COST', ML, Y)
          doc.setCharSpace(0)
          Y += 10
          bodyBlock(realCost, 0, 9.5, C.mutedText)
          Y += 4
        }
      }

      for (const msg of msgs) {
        if (msg.role === 'user') {
          ensure(28)
          Y += 4
          doc.setFont('Helvetica', 'bold')
          doc.setFontSize(7.5)
          doc.setTextColor(...C.goldLight)
          doc.setCharSpace(0.8)
          doc.text('YOUR PUSHBACK', ML, Y)
          doc.setCharSpace(0)
          Y += 10
          bodyBlock(cleanPushbackText(msg.content), 0, 9.5, C.pushbackText)
        } else if (isSynthesis) {
          const { verdict, conditions, counterfactual, keyQuestion, actionPlan, confidenceToAct, rest } = parseVerdictTension(msg.content)
          if (verdict) renderVerdictBoxPdf(verdict, conditions, counterfactual)
          renderSynthesisBody(rest)
          renderWorthConfirmingPdf(keyQuestion)
          renderActionPlanBoxPdf(actionPlan, confidenceToAct)
        } else {
          bodyBlock(stripAdvisorTags(msg.content))
        }
      }
    }
  }

  // ── Closing line ──────────────────────────────────────────────────────────────
  ensure(28)
  Y += 6
  doc.setFont('Helvetica', 'italic')
  doc.setFontSize(8.5)
  doc.setTextColor(...C.dimText)
  const closingText = sanitise('This record is private. The views expressed represent structured analysis, not professional advice.')
  const closingLines = doc.splitTextToSize(closingText, TW) as string[]
  for (const line of closingLines) { doc.text(line, ML, Y); Y += 13 }

  return Buffer.from(doc.output('arraybuffer'))
}


// ── Route handler ─────────────────────────────────────────────────────────────

interface Params { params: Promise<{ id: string }> }

export async function GET(req: Request, { params }: Params) {
  // No auth on this route (token gate was intentionally removed for the
  // freemium brief), and no caching before the LLM call below — every GET
  // regenerates the brief fresh. Rate limiting is the only cost control left.
  const rlResult = checkLimit(getClientIP(req), LIMITS.briefGenerate)
  if (!rlResult.allowed) return tooManyRequests(rlResult, 'brief generation requests')

  const { id }  = await params
  const url     = new URL(req.url)
  const theme   = url.searchParams.get('theme') === 'light' ? 'light' : 'dark'

  // ── Token gate removed (Sprint: Brief freemium) ───────────────────────────
  // Brief is now free for all users. BRIEF_ACCESS_TOKEN env var is no longer
  // checked here. The /api/brief-access route can be decommissioned separately.

  const supabase = createServiceClient()

  const [sessionResult, messagesResult, examinerResult] = await Promise.all([
    supabase.from('sessions').select('*').eq('id', id).single(),
    supabase
      .from('messages')
      .select('persona, role, content, created_at')
      .eq('session_id', id)
      .order('created_at', { ascending: true }),
    supabase
      .from('examiner_responses')
      .select('question_text, response_text, question_order')
      .eq('session_id', id)
      .order('question_order', { ascending: true }),
  ])

  if (sessionResult.error || !sessionResult.data) {
    return NextResponse.json({ error: 'Session not found' }, { status: 404 })
  }

  // Decrypt raw user input fields before any use (AI prompt, PDF rendering)
  const session = {
    ...sessionResult.data,
    decision_text: decrypt(sessionResult.data.decision_text) ?? '',
    context_text:  decrypt(sessionResult.data.context_text)  ?? null,
    // Unified session, point 7: final_decision is encrypted the same way
    // decision_text is (raw user input) — see sprint_prediction_layer.sql.
    final_decision: sessionResult.data.final_decision ? (decrypt(sessionResult.data.final_decision) ?? null) : null,
  }
  let messages = (messagesResult.data ?? []).map(m => ({
    ...m,
    content: decrypt(m.content) ?? '',
  }))

  // ── Auto-generate Decision Brief if missing or stale ────────────────────────
  // Bug fix: this previously only checked `hasBrief` (does ANY decision_brief
  // row exist at all) — once one existed, whether from this same
  // auto-generation path or the live "Generate Decision Brief" button on the
  // session page, it was never regenerated no matter how much newer content
  // (pushbacks, "Share to All Advisors" updates) arrived afterward.
  // Downloading the PDF after challenging an advisor post-brief-generation
  // silently kept serving the STALE brief — picked from whatever the council
  // looked like at generation time, not the latest synthesis/pushback state.
  // Now regenerates whenever any advisor message is newer than the most
  // recent decision_brief message, not just when none exists at all.
  // byPersona's existing "take the last assistant message" logic (see the
  // .slice(-1) above) already means the newest row wins automatically, so
  // inserting a fresh row here is sufficient — no need to delete the stale
  // one(s); they simply stop being the one that renders.
  const briefRows       = messages.filter(m => m.persona === 'decision_brief' && m.role === 'assistant')
  const latestBriefTime = briefRows.length ? briefRows[briefRows.length - 1].created_at : null
  const latestOtherTime = messages
    .filter(m => m.persona !== 'decision_brief' && m.role === 'assistant')
    .reduce((max: string, m) => (m.created_at > max ? m.created_at : max), '')
  const briefIsStale = !latestBriefTime || (!!latestOtherTime && latestOtherTime > latestBriefTime)
  if (briefIsStale) {
    // Build context string from all existing persona assistant messages
    const personaContext = APPENDIX_ORDER
      .map(key => {
        const persona = PERSONAS[key as PersonaKey]
        const msgs = messages.filter(m => m.persona === key && m.role === 'assistant')
        if (!msgs.length) return null
        return `=== ${persona.label.toUpperCase()} ===\n${msgs.map(m => m.content).join('\n')}`
      })
      .filter(Boolean)
      .join('\n\n')

    if (personaContext) {
      const briefPrompt = `${DECISION_BRIEF}

THE DECISION:
${session.decision_text}

COUNCIL ANALYSIS:
${personaContext}

Generate the Decision Brief now.`

      try {
        // Provider migration (2026-08): was `provider: 'deepseek'`, now
        // `provider: 'openai'` (GPT-5-mini, unconditional direct target —
        // see resolveProvider's doc comment in lib/ai-client.ts). No
        // explicit temperature was set on this call before, so nothing
        // changes there; GPT-5-family models silently ignore any
        // temperature option regardless (see completeOpenAICompatible's
        // doc comment in lib/ai-client.ts).
        const briefContent = await createCompletion(briefPrompt, 1200, { provider: 'openai' })
        if (briefContent) {
          // Save encrypted to DB
          await supabase.from('messages').insert({
            session_id: id,
            persona: 'decision_brief',
            role: 'assistant',
            content: encrypt(briefContent),
          })
          // Use plaintext in-memory for this request
          messages = [...messages, {
            persona: 'decision_brief',
            role: 'assistant',
            content: briefContent,
            created_at: new Date().toISOString(),
          }]
        }
      } catch (err) {
        console.error('[brief/route] Auto-generation error:', err)
        // Continue — PDF will still render without brief section
      }
    }
  }

  const examinerQAs = (examinerResult.data ?? []).map(r => ({
    question_text:  decrypt(r.question_text)  ?? '',
    response_text:  decrypt(r.response_text)  ?? null,
    question_order: r.question_order,
  }))

  let pdfBuffer: Buffer
  try {
    pdfBuffer = await buildPdf(session, messages, examinerQAs, theme)
  } catch (err) {
    console.error('[brief/route] PDF build error:', err)
    return NextResponse.json({ error: 'PDF generation failed' }, { status: 500 })
  }

  const filename = `quorum-brief-${id.slice(0, 8)}.pdf`

  return new Response(new Uint8Array(pdfBuffer), {
    status: 200,
    headers: {
      'Content-Type':        'application/pdf',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Content-Length':      String(pdfBuffer.byteLength),
      'Cache-Control':       'no-store',
    },
  })
}
