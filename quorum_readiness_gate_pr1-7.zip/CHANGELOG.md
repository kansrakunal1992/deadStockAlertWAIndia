# Quorum — Readiness Gate + Quorum's Read (PR1–PR7)

19 files: 7 new, 12 modified. Verified against the real codebase before packaging:
`npx tsc --noEmit` clean (zero errors introduced — the only remaining warnings
are pre-existing `TS2802` downlevelIteration notices in ~15 files this work
never touches, caused by `tsconfig.json` having no explicit `target`; unrelated
to this change and not fixed here since it's out of scope), and the full test
suite passes: **68/68 tests, 8/8 files**, including the 10 new readiness-gate
tests and the golden-suite fixture updated for the new ontology dimension.

## Deploy order

1. **Run the SQL migration first**, before deploying any code:
   `supabase/sprint_readiness_gate_foundation.sql` — Supabase Dashboard → SQL
   Editor → New Query. Additive-only (new nullable columns, one new table),
   safe to run against a live DB with zero downtime. Nothing in this batch
   reads the new columns until the code below is also deployed, so there's no
   window where half-migrated state causes a problem.
2. Deploy the code changes (all 18 non-SQL files below) together, in one
   deploy. They're interdependent (e.g. `SessionView.tsx` imports
   `lib/readiness.ts`; `app/api/persona/route.ts` imports the same) — a
   partial deploy would break the build.
3. No environment variables need to change. The web-search lookup (PR2)
   reuses the existing `ANTHROPIC_API_KEY`; the tier gate for it reads the
   `x-product-tier` header middleware.ts already sets on every request — no
   new config.

## What shipped, one line each

- **PR1** (`supabase/sprint_readiness_gate_foundation.sql`) — adds
  `resolution_state` + `criticality` to `examiner_responses`, and a new
  `examiner_local_context` table. No behavior change by itself.
- **PR2** (`app/api/examiner/route.ts`, `lib/web-context-lookup.ts`,
  `lib/ai-client.ts`) — tags every Examiner question with a criticality tier;
  unifies the skip/submit code paths so a skipped question is actually
  recorded as skipped instead of vanishing; adds the optional local/
  regulatory/market context field with a real web-search-enabled lookup
  (Elite/Private tier only — see cost note below).
- **PR3** (`lib/readiness.ts`, `tests/readiness-gate.test.ts`) — the pure
  `computeReadiness()` function. 10 unit tests.
- **PR4** (`components/SessionView.tsx`, `components/ExaminerPanel.tsx`,
  `components/SynthesisCard.tsx`) — the actual gate: an unresolved critical
  question now blocks the Council from running at all, with a visible "Not
  ready to call" banner and an explicit override.
- **PR5** (`lib/personas.ts`, `lib/rule-engine.ts`, `app/api/persona/route.ts`)
  — `verdict_lean = insufficient` as a real, gated exception in the
  synthesis prompt; unresolved "important" questions are carried forward
  into Council context explicitly instead of silently dropped.
- **PR6** (`lib/ontology-tagger.ts`, `lib/rule-engine.ts`,
  `lib/session-labels.ts`, `tests/examiner-golden-suite.test.ts`) — new
  `non_financial_utility` ontology dimension, evidence-gated the same way
  `decision_discriminating_info` already is.
- **PR7** (`lib/quorum-read.ts`, `components/QuorumReadCard.tsx`,
  `components/OntologyRevealCard.tsx`, `app/api/session/[id]/quorum-read/route.ts`)
  — the "Quorum's Read" pre-Council screen: sessions 1–3 only, shown after
  Examiner completes and only when the Council is actually going to run. A
  plain-English structural summary plus one deterministic, falsifiable
  tension prediction (e.g. "watch for disagreement between the Risk
  Architect and the Elder").

## Model routing — what calls what, and why

This was audited file-by-file against the app's existing "Provider migration
(2026-08)" convention (see the doc comments already in `lib/ai-client.ts`
and at each of the seven existing `provider: 'openai'` call sites) rather
than guessed at:

| Call | Provider flag | Resolves to | Why |
|---|---|---|---|
| Ontology tagging (unchanged, PR6 just adds a field to its output) | `'anthropic'` | Claude (premium role / Elite-Claude target) | Reasoning-quality-critical — unchanged from before this work |
| Synthesis (unchanged, PR5 adds a new prompt branch) | `'anthropic'` | Claude | Same |
| **PR7 structural summary** (`lib/quorum-read.ts`) | `'openai'` | **GPT-5-mini, unconditionally** — not tier-subject | Matches the exact precedent already set for Examiner question generation / Decision Brief / Mirror Fingerprint narrative: reformatting already-computed data into prose is an "internal system/utility call," not the tier-differentiated advisor experience, so it should read the same for every user regardless of tier or A/B test — this is the team's own stated rule for that category, not a new one invented here |
| **PR2 web-search context lookup** (`lib/web-context-lookup.ts`) | N/A — direct Anthropic call, bypasses the role system entirely | Claude, via the `web_search_20250305` tool | The only call in the app that needs live tool use; no other provider wired here has an equivalent tool. **Gated to Elite/Private tier only** in `app/api/examiner/route.ts` — a live Claude web-search call would cost far more than the rest of a Free-tier session combined (~$0.005/session budget from the unit-economics review), so Free-tier users still get their typed local-context answer captured and shown to the Council, just not the web-retrieved enrichment layer on top |
| PR2 criticality tagging | *(no AI call — deterministic mapping from rule_id)* | — | — |

One real bug caught and fixed during this: `lib/quorum-read.ts` was
initially written with `provider: 'deepseek'`, which is a **stale**
convention in this codebase as of the Aug 2026 migration — `'deepseek'` is
still a valid *role* flag (tier-subject, used for the advisor-persona fast
role), but every comparable "utility" call in the app was already migrated
off it to `'openai'` specifically because utility calls shouldn't vary by
tier/A-B-test. Caught by reading the actual migration comments already in
the file, not by assumption — corrected before packaging.

## Known pre-existing issue, not touched

`tsconfig.json` has no `target` set, which is why `tsc --noEmit` throws
`TS2802` (downlevelIteration) on ~15 files across the app that iterate a
`Set`/`Map` — none of which this work modifies. `next build`'s own
type-checking clearly tolerates this in production today (the app runs), so
this is either a benign mismatch between raw `tsc` and Next's actual build
pipeline, or a latent issue worth a separate, deliberate fix — not bundled
into this change since it's unrelated to the readiness-gate work and
touching `tsconfig.json` deserves its own review.

## SDK version note

`lib/ai-client.ts`'s new `createWebSearchCompletion()` needed two documented
type assertions — the installed `@anthropic-ai/sdk` (0.39.0) predates that
SDK's own TypeScript definitions for the `web_search_20250305` tool and the
`server_tool_use` response content block. The API itself supports both today;
the SDK's `.d.ts` files just haven't caught up yet. Both assertions are
commented in place with a note that they're safe to delete once the SDK
package is bumped past whichever version adds native types for this tool.
