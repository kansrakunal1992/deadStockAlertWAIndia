/**
 * QUORUM — Chat Intake Checkpoint Route (Natural Intake v1)
 *
 * Fires when the user confirms "Here's the decision I think you're actually
 * making" (or edits it first). Deliberately does NOT duplicate session
 * creation, ontology tagging, or bias scoring — it assembles
 * decision_text/context_text from the chat and sends them through the
 * EXISTING POST /api/session, exactly as HomeClient.tsx's classic form does
 * today. Everything downstream (ontology tagger, structural match, and —
 * once the person opens the checkpoint screen — the Examiner's
 * derive-and-confirm check) runs unchanged.
 *
 * This is Depth B in the plan (section 4D): runs once per decision, whether
 * or not the person goes on to Convene the Council.
 */

import { NextResponse } from 'next/server'
import { claimCheckpoint, internalSessionHeaders, releaseClaim } from '@/lib/chat-intake-checkpoint-helpers'
import { createServiceClient } from '@/lib/supabase'
import { isNaturalIntakeEnabled } from '@/lib/feature-flags'
import { assembleSessionInput } from '@/lib/chat-intake-state'
import { decrypt } from '@/lib/encryption'
import type { ChatDecisionState, ChatIntakeMessage } from '@/lib/types'

export async function POST(req: Request) {
  if (!isNaturalIntakeEnabled()) {
    return NextResponse.json({ error: 'Not enabled' }, { status: 404 })
  }

  try {
    const { chatIntakeId, editedDecisionText, framingIntent } = (await req.json()) as {
      chatIntakeId?:        string
      // "Edit" on the reflection screen — the user's correction always wins
      // (plan section 4E), so this simply overrides the auto-assembled
      // decision statement rather than re-running extraction.
      editedDecisionText?:  string
      framingIntent?:       'challenge' | 'clarify' | 'right'
    }

    if (!chatIntakeId) {
      return NextResponse.json({ error: 'chatIntakeId is required' }, { status: 400 })
    }

    const supabase = createServiceClient()

    const { data: intakeRow, error: intakeErr } = await supabase
      .from('chat_intakes')
      .select('id, decision_state, status, user_id, user_email, device_id, session_id')
      .eq('id', chatIntakeId)
      .single()

    if (intakeErr || !intakeRow) {
      return NextResponse.json({ error: 'Chat not found' }, { status: 404 })
    }
    if (intakeRow.status === 'checkpointed') {
      // v9: idempotent. A retry after a dropped response (or a second tab) gets the session that already exists
      // instead of an error the client cannot recover from. Only a chat with no session recorded is a real conflict.
      const existing = (intakeRow as { session_id?: string | null }).session_id
      if (existing) {
        const st = (intakeRow.decision_state as ChatDecisionState | null) ?? {}
        return NextResponse.json({ sessionId: existing, leanSaved: !!(st.chosenLean && st.optimizationPriority), resumed: true })
      }
      return NextResponse.json({ error: 'Already checkpointed' }, { status: 409 })
    }

    const { data: msgRows } = await supabase
      .from('chat_intake_messages')
      .select('*')
      .eq('chat_intake_id', chatIntakeId)
      .order('turn_order', { ascending: true })

    const transcript: ChatIntakeMessage[] = (msgRows ?? []).map(m => ({
      ...m, content: decrypt(m.content) ?? '',
    }))

    const state = (intakeRow.decision_state as ChatDecisionState | null) ?? {}
    // v9: the person's own rewrite of the decision is authoritative — it goes into the session context with a note
    // that it supersedes Quorum's earlier framing, and is remembered on the chat (so a retry/resume keeps it).
    const edited = editedDecisionText?.trim().slice(0, 600) || ''
    const { decisionText, contextText } = assembleSessionInput(state, transcript, { editedDecision: edited || null })

    const finalDecisionText = edited || decisionText
    if (!finalDecisionText) {
      return NextResponse.json({ error: 'Nothing to checkpoint yet' }, { status: 400 })
    }

    // ── v9: claim this checkpoint so two concurrent requests can't each create a session ───────────────────────
    // Conditional write on chat_intakes.checkpoint_claimed_at (supabase/sprint_intake_v9_claim.sql). A claim older than
    // CLAIM_STALE_MS is treated as abandoned. If the column has not been migrated yet the claim is skipped (logged), so
    // deploying this file before the migration cannot break launches — it just leaves the old (unclaimed) behaviour.
    const claim = await claimCheckpoint(supabase as never, chatIntakeId)
    if (claim === 'held') {
      return NextResponse.json({ error: 'This decision is already being set up — one moment.', inProgress: true }, { status: 409 })
    }

    // ── Create the session through the EXISTING route ───────────────────────────
    // Same-origin server-to-server call, forwarding the caller's own auth —
    // identical to how a signed-in user's browser would call this route
    // directly. No internal secret needed (unlike fireOntologyTagger's
    // fire-and-forget sub-call in app/api/session/route.ts) since this is a
    // normal, awaited request the checkpoint response depends on.
    //
    // v9 fix (code-verified): /api/session rate-limits by client IP (20 per 15 min, lib/rate-limit.ts getClientIP).
    // This internal call used to forward only Authorization, so the limiter saw the SERVER's address (or "unknown")
    // for every launch — one shared bucket for all users, so the 21st launch in 15 minutes got a 429 whatever
    // person it was. Forward the real client's address so the limit applies per person, as intended.
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'
    const fwdFor  = req.headers.get('x-forwarded-for')
    const realIp  = req.headers.get('x-real-ip')
    const sessionRes = await fetch(`${baseUrl}/api/session`, {
      method:  'POST',
      headers: internalSessionHeaders({ authorization: req.headers.get('Authorization'), forwardedFor: fwdFor, realIp }),
      body: JSON.stringify({
        decision_text:  finalDecisionText,
        context_text:   contextText,
        framing_intent: framingIntent ?? null,
        user_email:     intakeRow.user_email ?? null,
        device_id:      intakeRow.device_id ?? null,
        intake_mode:    'chat',
        chat_intake_id: chatIntakeId,
      }),
    })

    const sessionJson = await sessionRes.json().catch(() => null)
    if (!sessionRes.ok || !sessionJson?.id) {
      console.error('[ChatIntake Checkpoint] session creation failed:', sessionRes.status, sessionJson)
      await releaseClaim(supabase as never, chatIntakeId)
      // A rate limit is not "something broke": say so, so the screen can ask the person to wait instead of retrying blindly.
      if (sessionRes.status === 429) {
        return NextResponse.json({ error: sessionJson?.error ?? 'Too many requests — please wait a moment and try again.', rateLimited: true }, { status: 429 })
      }
      return NextResponse.json({ error: 'Failed to create session' }, { status: 500 })
    }
    const sessionId = sessionJson.id as string

    // session_depth: 'checkpoint' — see supabase/sprint_natural_intake_v1.sql's
    // comment on this column. Not read by any v1 Mirror code yet; set here
    // so the deferred fast-follow has correct historical data once it ships.
    // It flips to 'council' when the first synthesis completes (see
    // app/api/session/[id]/synthesis-version/route.ts).
    //
    // v4: the end-of-chat lean + priority chips (POST /api/chat-intake/lean)
    // are copied onto the session here, in the same write, so the prediction
    // can start the instant the person confirms — it needs both set
    // (app/api/persona/predict/route.ts returns 409 otherwise). Both or
    // neither: a half-set pair would just trip that 409 later.
    const sessionPatch: Record<string, unknown> = { session_depth: 'checkpoint' }
    if (state.chosenLean && state.optimizationPriority) {
      sessionPatch.initial_instinct      = state.chosenLean
      sessionPatch.optimization_priority = state.optimizationPriority
    }
    await supabase.from('sessions').update(sessionPatch).eq('id', sessionId)

    await supabase
      .from('chat_intakes')
      .update({
        status: 'checkpointed', session_id: sessionId,
        ...(edited ? { decision_state: { ...state, userEditedDecision: edited } } : {}),
      })
      .eq('id', chatIntakeId)

    // leanSaved tells the client whether the prediction can start right away
    // (false = an older in-flight chat that never saw the chips).
    return NextResponse.json({
      sessionId,
      leanSaved: !!(state.chosenLean && state.optimizationPriority),
    })
  } catch (err) {
    console.error('[ChatIntake Checkpoint] error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
