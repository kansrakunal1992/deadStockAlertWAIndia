# Round 9 — screenshot fixes + mobile audit findings

6 files. `SessionView.tsx`'s patch is against round7; the other five are new
touches this round, diffed against their true original.

## From your screenshot

**Duplicate Save Record button.** There are two — one in the page header
(`data-tour-id="council-save"`, the one the tour actually points at) and one
in the bottom action tray. I'd only gated the bottom one three rounds ago.
The header one — the gold, clickable one in your screenshot — now has the
identical `disabled` condition and tooltip.

**"Unlocks your six-advisor Decision PDF"** — updated under the flag to
"Unlocks your Decision PDF — synthesis, prediction, and outcome," matching
what's actually in the PDF now.

**The race condition, found and fixed.** The tour fired on a blind 800ms
timer once synthesis finished generating. Under the flag specifically,
Synthesis's wrapper stays `display:none` until the user clicks past
Quorum's hypothesis card (the progressive-reveal from a few rounds back) —
so synthesis could be fully "run" while still invisible, exactly matching
what you saw. Fixed properly: the effect now also depends on
`predictionAcknowledged`, so it only fires once the element it's about to
spotlight is actually visible. (First attempt at this fix used a polling
interval with a stale-closure bug that would never have worked correctly —
caught it before shipping, fixed by using React's dependency array instead.)

**Four new tour steps added**, none of which existed before: Quorum's
hypothesis card, the "See how Quorum got here" toggle, "Disagree / ask a
follow-up," and "Make your decision." All gated to the flag, inserted in
the order they actually appear on screen.

## Mobile audit

Led with a genuine surprise: this codebase already has real mobile
investment — a properly configured PWA manifest (standalone display,
maskable icons, correct theme color), existing safe-area-inset handling,
and a responsive Save-button label swap at 480px. This isn't a
mobile-neglected app.

**The one foundational thing worth verifying yourself, not just trusting my
read of the code:** I could not find an explicit viewport configuration
anywhere — no `<meta name="viewport">`, no Next.js `viewport` export. Next
usually handles this by default, and the existing safe-area-inset CSS
strongly implies someone already set this up correctly somewhere I
haven't found — but I'd rather you confirm by actually loading the site on
a phone than have me assert a framework default I can't fully verify from
here. If it does look zoomed out on a real device, that's the fix to make
first, before anything else in this section.

**Fixed:** the app's global input/textarea font-size is 15px (one pixel
under the threshold that stops iOS Safari auto-zooming the whole page on
focus) — this affects the *main decision box on the home page*, not just my
own components. Scoped the fix to the flag via a `data-unified-session`
attribute on `<html>` rather than changing it globally, consistent with how
everything else in this work has been gated — worth reconsidering later,
since this bug isn't specific to the new experience at all.

**Also fixed:** touch target sizing on the smaller interactive chips I
added across this work (decision-starter categories, structured-challenge
reason tags) — bumped from ~25-31px tall to a more comfortable range,
closer to the 44px thumb-friendly guideline.

**Not done — genuinely needs a real device, not more code reading:**
whether the mobile experience *feels* as simple as ChatGPT/Claude is a
judgment call about layout rhythm, scroll behavior, and keyboard
interaction that I can't make confidently from source code alone. My
honest recommendation: load the unified-session flow on an actual phone
once this round is applied, and tell me specifically where it feels
heavier than a chat app — that will be a much sharper punch list than
anything more I could infer from reading component code blind.

## Before merging

Same caveat as every round.
