# Quorum — Install Guide + How Quorum Works Copy

3 files touched (1 new page, 2 edited). Builds on top of
quorum-legal-pages-fixes.zip — no overlap with prior batches.

## 7. New page: app/install/page.tsx (route: /install)

Confirmed the app is a genuinely installable PWA before writing this
— manifest.json (name "Quorum", display: standalone, icons) and the
apple-mobile-web-app meta tags in app/layout.tsx are both already in
place, so these are real steps, not aspirational ones.

New page has:
- iPhone (Safari) steps — Share icon → Add to Home Screen, with a
  note that it only works in Safari (Apple restriction, not a Quorum
  limitation).
- Android (Chrome) steps — three-dot menu → Add to Home screen /
  Install app, with a note about the automatic install prompt some
  phones show.
- A short "what you get" section clarifying it's the same app/data,
  just opening full-screen without browser chrome.

Styled to match the existing terms/privacy/security/cookies page
pattern (same header, back link, section styling) so it feels like
part of the same site rather than a bolted-on page.

**Linked from the FAQ:** the "Can I use Quorum on my phone?" answer
now has a "See Android / iPhone steps →" link under it. This
required a small structural change to FAQSection.tsx — added an
optional `link` field to the FAQItem type (previously answers were
plain text only) and render logic for it. Reusable for any future FAQ
entry that should point somewhere.

**Not added:** a footer link. The footer's link list is explicitly
scoped to legal pages (`LEGAL_LINKS`), and a how-to guide doesn't
really belong there — the FAQ link should cover discoverability. Easy
to add if you'd rather have it in the footer too.

## 9. app/methodology/page.tsx — Context Ingestion description

The "You don't have to start from zero" paragraph undersold the
feature. Checked ContextIngestionPanel.tsx directly for what it
actually supports today:

Before: "...a description of yourself, or a ChatGPT/Claude export..."

After: "...a description of yourself, a ChatGPT/Claude export, or a
Markdown, HTML, or Word file..." — plus one clause added at the end
noting older insights get a "still true?" freshness check, which ties
the paragraph back into this page's own "confidence compounds, it
doesn't appear instantly" theme instead of reading like a one-time
import.

"Raw content is never stored" was already accurate — left as-is.

## Verification
All three files run clean through `tsc --noEmit` in isolation (JSX
preserve, esModuleInterop, skipLibCheck) — no syntax errors. Same
caveat as prior batches: no node_modules here, so this isn't a full
project type-check.
